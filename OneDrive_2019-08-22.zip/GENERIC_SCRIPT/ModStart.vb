Option Explicit On

Imports SRV_SUP_GENERIC_SCRIPT.Helpers

Module ModStart
    Sub Main()
        ''Get the user information and security check'''
        'UserName()


        ''''''''''''''''''''''''''''''''''''''''''''''''
        MsgBox("Please be sure you are signed into your 3270 Director tool")
        ''''''''''''''''''''''''''''''''''''''''''''''''

        ''used to avg the count times ran per record
        ''ReadLCount()

        '''''Send Script Start Information to Database'''''
        ''LogScriptStart()
        '''''''''''''''''''''''''''''''''''''''''''''''

        ''Run process''

        '''''Send Last Run Information to Database'''''
        ''LogScriptLastRun()
        '''''''''''''''''''''''''''''''''''''''''''''''

        DirIndicators(True)   'Loan indicators on
    End Sub

    Public Sub XLBase(ByVal strExcelFileName As String)
        Dim Erow, Ecol, Lcount, Tcount As Integer

        WrkConnXL(strExcelFileName, 1) ''open selected file
        Erow = 2
        Ecol = 1


        Lcount = 1
        Tcount = 1
        LoanNum = objXlSht.cells(Erow, Ecol).Value
        Do Until LoanNum = ""
            If objXlSht.cells(Erow, Ecol + 7).Value <> "DONE" Then


                objXlSht.cells(Erow, Ecol + 7).Value = "DONE"
                'objExcelWrkBk.save()
            End If
            Erow = Erow + 1
            Ecol = 1
            Lcount = Lcount + 1
            Tcount = Tcount + 1
            'If Lcount = RLC Then
            '    '''''Send Last Run Information to Database'''''
            '    '' LogScriptLastRunNoMsg()
            '    '''''''''''''''''''''''''''''''''''''''''''''''
            '    '''''Send Script Start Information to Database'''''
            '    '' LogScriptStart()
            '    ''''''''''''''''''''''''''''''''''''''''''''''
            '    Lcount = 1
            'End If
            LoanNum = objXlSht.cells(Erow, Ecol).Value
        Loop
        MessageBox.Show("You Processed " & Tcount & " Loans.")
        XLConnClose()
    End Sub
End Module
