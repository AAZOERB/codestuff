﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using SRV_SUP_GENERIC_SCRIPT;
using System.Windows.Forms;


namespace GenericScriptConsoleApp
{
    public static class GenericScript
    {
        public static string FileName;
        public static frmFileSelction FileSectionForm = new frmFileSelction();
        public static void Run()
        {
           LoadConfigurationFile();
            
            Application.Run(new Main());
        }



        public static void LoadConfigurationFile()
        {

            
            
            var fileInfo = new DirectoryInfo(AssemblyDirectory);
            var configFile = fileInfo.GetFiles("*.txt").ToList();

            if (configFile.Count == 0) throw new Exception("No Config file is present");

            
            FileSectionForm.LoadConfigurationFile(configFile.First().FullName);
        }
        private static string AssemblyDirectory
        {
            get
            {
                var codeBase = Assembly.GetExecutingAssembly().CodeBase;
                var uri = new Uri(codeBase);
                var path = uri.LocalPath;
                return Path.GetDirectoryName(path);
            }
        }


        
    }
}
