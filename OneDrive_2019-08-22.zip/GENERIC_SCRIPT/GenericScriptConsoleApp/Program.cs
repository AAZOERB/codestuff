﻿using System;

namespace GenericScriptConsoleApp
{
 public static  class Program
 {
     public static bool ValidateLoans;
     [STAThread]
       public static void Main(string[] args)
     {
         
         if (args.Length != 0)
         {

             ValidateLoans = Convert.ToBoolean(args[0]);
         }
         GenericScript.Run();

     }
    }
}
