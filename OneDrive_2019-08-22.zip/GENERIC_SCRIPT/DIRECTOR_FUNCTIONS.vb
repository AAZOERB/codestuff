Option Strict Off
Option Explicit On
Module DIRECTOR_FUNCTIONS
    Public Stmt, Stmt2 As String
    Public HolidayList, PendingTask, TaskQueue As New ArrayList
    Public LoanNum As String
    Public rc As Object
    Private User_id As String
    Public rtText As String
    Const S_OK As Short = 0
    Dim row As Short
    Dim Col As Short
    Dim Length As Short
    Public Hllapi As String
    Private strTestRegion As String
    Public OLLWID, OLLWDT, CFID, CFTran1, CFTran2, CFTran3, CFTran4, CFTran5 As New ArrayList

    Dim _
        ScreenString,
        atl3270Tool,
        DirObject,
        atlTaskTracking,
        DirTskObject,
        atlEmailTool,
        atlSnapShotTool,
        xmlDoc,
        Tool,
        CTool,
        atlActivity As Object

    Public CurNotes, CompNotice As String
    Public ScriptError As Boolean
    Public PL05LetterDate, ActualStepDate As Date
    Public PL05Preceding, strProperty, strCity, strState, strZip As String
    Public strMailProp, strMailCity, strMailState, strMailZip As String
    Public getTaskID, ErrMsg As String
    Public IsStepInvaid As Boolean
    'Navigates to the requested screen after insuring that you have a good connection to MSP
    'If MSP has timed out, the sub will log the user back into MSP

    Public Function GoToScreen(ByRef ScreenName As String, Optional ByRef LoanNumber As String = "") As Short
        If LoanNumber = "" Then
            DirLoanNo("Read")
            DirShowScreen(ScreenName, "", LoanNum)
        Else
            DirShowScreen(ScreenName, "", LoanNumber)
        End If
    End Function

    'Sends an enter command to MSP
    Public Sub Enter()
        DirSendKeystrokes("", "", "@Enter")
    End Sub

    Public Sub DirEnter()
        DirSendKeystrokes("", "", "@Enter")
    End Sub


    Public Sub CheckStatus()

        If DirPrimarySession = False Then
            DirSessionConnect()
            Login()
        End If
    End Sub

    Public Function AreWeConnected() As Boolean
        Try
            AreWeConnected = DirPrimarySession()
            Exit Function
        Catch exp As Exception
            MsgBox("Error on AreWeConnected : " & Err.Description)
        End Try
    End Function

    Public Function GetLoanNumber() As String
        Return (DirLoanNo("Read"))
    End Function

    Public Function getAgePhrase(ByVal age As Integer) As String
        If age > 60 Then Return "Senior"
        If age > 40 Then Return "Middle-aged"
        If age > 20 Then Return "Adult"
        If age > 12 Then Return "Teen-aged"
        If age > 4 Then Return "School-aged"
        If age > 1 Then Return "Toddler"
        Return "Infant"
    End Function


    Public Function SH(ByVal StringToSend As String) As Short
        Try
            DirSendKeystrokes("", "", StringToSend)
        Catch exp As Exception
            MsgBox("Error on SH: " & exp.Message)
        End Try
    End Function

    Public WriteOnly Property Password() As Object
        Set(ByVal Value As Object)
            Value = DirSendKeystrokes("", "", "%PASSWORD%")
        End Set
    End Property

    Public WriteOnly Property Userid() As Object
        Set(ByVal Value As Object)
            Value = DirSendKeystrokes("", "", "%USERID%")
        End Set
    End Property

    Public ReadOnly Property GetUserid() As Object
        Get
            GetUserid = DirSendKeystrokes("", "", "%USERID%")
        End Get
    End Property

    Public WriteOnly Property hllapishort() As String
        Set(ByVal Value As String)
            Hllapi = Value
        End Set
    End Property

    Public WriteOnly Property OK() As Object
        Set(ByVal Value As Object)
            'OK = atl3270Tool.ShowMessageOK
        End Set
    End Property

    Public WriteOnly Property YourNavObject() As Object
        Set(ByVal Value As Object)
            On Error Resume Next
            DirSessionConnect()
            Value = atl3270Tool
        End Set
    End Property

    Public Property TestRegion() As String
        Get
            'Allows you to test whether or not the test region is active
            TestRegion = strTestRegion
        End Get
        Set(ByVal Value As String)
            'Alows you to turn on or off the test region.  Default is off.
            strTestRegion = Value
        End Set
    End Property

    'SynchronizeLoanNoChange is a Boolean property that can be used to control how changes to the current loan number
    'within the 3270 errlorer tool synchronize with Director�s LoanBar. By default this property is True, meaning that
    'any changes to the current loan number within the 3270 errlorer will be reflected in the LoanBar. While generally
    'desirable, this will cause some performance slowdown, and also result in retrieval of Loan Indicators (if enabled)
    'for each loan number.

    Public Property DirSynchronizeLoanNoChange() As Object
        Get
            Return atl3270Tool.SynchronizeLoanNoChange()
        End Get
        Set(ByVal Value As Object)
            Value = atl3270Tool.SynchronizeLoanNoChange
        End Set
    End Property

    Public Function TextFormat(ByVal row As Short, ByVal Col As Short) As Object
        TextFormat = DirIsFieldUnprotected(row, Col, "")
    End Function


    'Can be  ed by any program if we are kicked off on MSP.  It does not raise a login screen
    ', and cannot be  ed unless the person has already logged in once since opening the program
    Public Sub RELOGIN()
        Try
            DirSessionConnect()
            DirClearScreen()
            DirClearScreen()
            DirSendKeystrokes(1, 1, "CSSF" & "@Enter")
            If DirReadScreen(1, 2, 4) = "CSSF" Then
                DirClearScreen()
            End If
            DirClearScreen()
            DirSendKeystrokes(1, 2, "C@Enter")
            DirWaitForString(CStr(13), CStr(29), "CICS")
            DirSendKeystrokes(15, 30, "%USERID%")
            DirSendKeystrokes(16, 32, "%PASSWORD%" & "@Enter")
        Catch exp As Exception
            MsgBox("Error on Relogin: " & exp.Message)
        End Try
    End Sub

    'Returns the column position of the cursor

    Public Function ColPosit() As Short
        Try
            DirGetCursorPos()
        Catch exp As Exception
            MsgBox("Error on col position: " & exp.Message)
        End Try
    End Function

    'Returns the Row number of the Cursor
    Public Function RowPosit() As Short
        Try
            DirGetCursorPos()
            RowPosit = row
        Catch exp As Exception
            MsgBox("Error on row position: " & exp.Message)
        End Try
    End Function

    'Not needed in Director because it will only process one function at a time
    Public Function WFHQ() As Short
        frmWait.ShowDialog()
    End Function

    'Changed to include specific row and col settings in Director. Go to DirWaitForString. Use it for future coding.

    Public Function WFS(ByVal StringToWaitFor As String, Optional ByRef NextScreen As String = "") As Short
        Try
            DirWaitForString("", "", StringToWaitFor)

        Catch exp As Exception
            MsgBox("Error on Wait for string: " & exp.Message)
        End Try
    End Function

    Public Function QuitIt() As Boolean
        QuitIt = False
    End Function

    Public Sub Login()
        Try
            'DirSessionConnect
            DirClearScreen()
            If UCase(TestRegion) <> "" Then
                DirSendKeystrokes(1, 2, strTestRegion & "@Enter")
            Else
                DirSendKeystrokes(1, 2, "C@Enter")
            End If
            If DirReadScreen(23, 2, 4) = "DFHA" Then
                DirSendKeystrokes(1, 2, "CSSF" & "@Enter")
                If UCase(TestRegion) <> "" Then
                    DirSendKeystrokes(24, 21, strTestRegion & "@Enter")
                    DirWaitForString(CStr(13), CStr(29), "CICS")
                    DirSendKeystrokes(15, 30, InputBox("Enter Test User ID"))
                    DirSendKeystrokes(16, 32, InputBox("Enter Test User Password") & "@Enter")

                Else
                    DirSendKeystrokes(24, 21, "C@Enter")
                    DirWaitForString(CStr(13), CStr(29), "CICS")
                    DirSendKeystrokes(15, 30, "%USERID%")
                    DirSendKeystrokes(16, 32, "%PASSWORD%" & "@Enter")

                End If
            End If
        Catch exp As Exception
            MsgBox("Error on Login: " & exp.Message)
        End Try
    End Sub


    Public Function CloseCPI() As Integer
        Try
            DirCloseSession()
            Exit Function
        Catch exp As Exception
            MsgBox("Error on CloseCPI: " & exp.Message)
        End Try
    End Function

    Public Function SessionOff() As Short
        Try
            DirClearScreen()
            Exit Function
        Catch exp As Exception
            MsgBox("Error on SessionOff: " & exp.Message)
        End Try
    End Function

    Public Function SessionOn() As Short
        Try
            RELOGIN()
            Exit Function
        Catch exp As Exception
            MsgBox("Error on SessionOn: " & exp.Message)
        End Try
    End Function

    Public Function SendString(ByRef row As Short, ByRef Col As Short, ByRef StringToSend As String) As Short
        Return DirSendKeystrokes(row, Col, StringToSend)
    End Function


    Public Function FindString(ByRef StringToFind As String) As Short
        Dim SysString As String
        row = 1
        Do Until row = 24
            SysString = DirReadScreen(row, 1, 80)
            rc = InStr(1, SysString, StringToFind, CompareMethod.Text)
            If rc > 0 Then
                FindString = rc
                Exit Function
            Else
                row = row + 1
            End If
        Loop
        Return rc
    End Function

    Public Function SendKey(ByRef KeyCode As String) As Short
        Try
            rc = DirSendKeystrokes("", "", KeyCode)
        Catch exp As Exception
            MsgBox("Error on SendKey : " & exp.Message)
        End Try
    End Function

    Public Function Scrape(ByRef row As Short, ByRef Col As Short, ByRef Length As Byte) As String
        Scrape = (DirReadScreen(row, Col, Length))
    End Function


    Public Function GetString(ByRef row As Short, ByRef Col As Short, ByRef Length As Short) As String
        GetString = DirReadScreen(row, Col, Length)
    End Function

    'Function not needed
    Private Function IsLoaded(ByRef FrmName As String) As Boolean
    End Function

    'Connects to a Director session. Reuses the the read/write session if it is available.
    Public Sub DirSessionConnect()
        ErrMsg = Nothing
        atl3270Tool = Nothing
        DirObject = CreateObject("atlDirectorObject.atlDirector")
        'If DeterminTool("3270") = True Then
        If DirObject.CreateTool("3270", 1, True, True, 0, atl3270Tool, ErrMsg) <> S_OK Then
            MsgBox("Unable to create 3270 tool: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If

        DirIndicators(False) 'Loan indicators off
        ' Else
        ' atl3270Tool = Tool
        ' End If
    End Sub
    ' ''This will allow for connection to the Tasktracking portion of Director'
    ''Public Sub DirTaskTrackingConnect()
    ''    ErrMsg = Nothing
    ''    atlTaskTracking = Nothing
    ''    DirTskObject = CreateObject("atlDirectorObject.Tasktracking")
    ''End Sub
    'This method  s internal functions to determine if there are any queued tasks for 
    'the current user, and if so then launches the 3270 Explorer tool and displays the 
    'MSP screen TSK1 for the relevant task
    Public Sub DirNextTask()
        ErrMsg = Nothing
        DirObject.Tasktracking.NextTask(ErrMsg)
    End Sub
    'This method will return the pending tasks
    Public Sub DirPendingTask()
        Try
            Dim TaskList, i

            ErrMsg = Nothing
            PendingTask.Clear()
            TaskList = DirObject.TaskTracking.PendedTasks()
            Debug.Print(TaskList.count)
            For i = 0 To TaskList.count - 1
                PendingTask.Add(Trim(TaskList(i).Loanno) & ";" & TaskList(i).taskid & ";" & TaskList(i).Status)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    'This method will return the Queue Summary for tasks
    Public Sub DirTaskQueue(ByVal strQueue)
        Try


            Dim Queue, QueueList, TaskList, i
            Queue = Nothing
            DirObject.TaskTracking.clientid = DirObject.clientid
            QueueList = DirObject.TaskTracking.QueueSummary
            For i = 0 To QueueList.count - 1
                Queue = QueueList.Item(i)
                If Queue.QueueName = strQueue Then Exit For
            Next
            If Queue.QueueName <> strQueue Then
                MsgBox("Queue " & strQueue & " Not Found.", "Queue Not Found.")
            Else
                TaskList = Queue
                For i = 0 To TaskList.count - 1
                    'MsgBox(TaskList(i).Loanno & ";" & TaskList(i).taskid & ";" & TaskList(i).Status)
                    TaskQueue.Add(Trim(TaskList(i).Loanno) & ";" & TaskList(i).taskid & ";" & TaskList(i).Status)
                Next
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    'GetNextTask  s internal functions to determine if there are any queued tasks 
    'for the current user, and if so then returns the loan number and task identifier 
    'of the user�s next task in the TaskID and LoanNo output parameters.
    Public Sub DirGetNextTask()
        ErrMsg = Nothing
        getTaskID = Nothing
        LoanNum = Nothing
        DirObject.TaskTracking.GetNextTask(getTaskID, LoanNum, ErrMsg)
    End Sub

    'The GotoTask method launches the 3270 Explorer tool and displays the MSP screen '
    'specified by the TaskAction string input parameter (which should have one of '
    'the reserved values �TSK1� or �TSKN�) for the task identifier and loan number '
    'specified by LoanNo and TaskID. This method is  ed internally by the NextTask method'
    Public Sub DirGoToTask(ByVal TaskID As String, ByVal TaskAction As String)
        If DirObject = Nothing Then DirSessionConnect()
        DirObject.Tasktracking.GotoTask(LoanNum, TaskID, TaskAction, ErrMsg)
    End Sub


    'The ClearScreen method clears the screen by sending one or more �clear� commands to the 3270 errlorer.
    'If the screen cannot be cleared with the normal �clear� command, the function will look up the required
    'steps in an internal data table and those steps will be performed. A screen is considered clear
    'if it is blank or if the standard MSP prompt �ENTER NEXT TRANSACTION:� is displayed.
    'If the Boolean input parameter AbsoluteClear is True, the function will proceed until a blank screen
    'is reached; if False the function may stop at a screen displaying the �ENTER NEXT TRANSACTION:�
    'prompt if this is encountered first. Because not all MSP screens can be cleared by standard �clear�
    'command keystrokes (some require custom logic that is known internally to the 3270 errlorer tool), '
    'it is recommended that the ClearScreen method be used rather than sending �clear� command keystroke strings.
    Public Sub DirClearScreen()
        ErrMsg = Nothing
        If atl3270Tool.ClearScreen(True, ErrMsg) <> S_OK Then
            MsgBox("ClearScreen failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If
    End Sub

    'This method will log off from the current MSP session, but will not close the 3270 errlorer tool
    'or disconnect the Telnet connection to the host computer. This method is provided for backward compatibility
    'with previous versions of Director. Since logging off and all associated resource clean-up is handled
    'automati y by the 3270 errlorer tool when it shuts down, it is unlikely that there would ever
    'be a need to   CloseSession from a script.
    Public Sub DirCloseSession()
        ErrMsg = Nothing
        If atl3270Tool.CloseSession(ErrMsg) <> S_OK Then
            MsgBox("CloseSession failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If
    End Sub

    'This method copies the contents of the selection rectangle to the Windows� clipboard.
    'If the is no selected block then the entire screen will be copied instead.
    Public Sub DirCopyToClipboard()
        ErrMsg = Nothing
        If atl3270Tool.CopyToClipboard(ErrMsg) <> S_OK Then
            MsgBox("CopyToClipboard failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If
    End Sub

    'This method behaves the same as CopyToClipboard.
    Public Sub DirCutToClipboard()
        ErrMsg = Nothing
        If atl3270Tool.CutToClipboard(ErrMsg) <> S_OK Then
            MsgBox("CutToClipboard failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If
    End Sub

    'This method returns the current row and column position of the text insertion cursor on the 3270 screen
    'in the integer output parameters Row and Col.
    Public Sub DirGetCursorPos()
        ErrMsg = Nothing
        If atl3270Tool.GetCursorPos(row, Col, ErrMsg) <> S_OK Then
            MsgBox("GetCursorPos failed: " & ErrMsg, CDbl("ERROR!!"), CStr(MsgBoxStyle.OkOnly))
        End If
    End Sub

    'This method is used to determine whether a portion of a currently displayed 3270 screen is unprotected.
    'The position and size of the field to check is specified in the Row, Col and Length input parameters.
    'If all character positions in this range are in the same field and writable then the Unprotected output
    'parameter will return a value of True; any other conditions will set this parameter to False.
    Public Function DirIsFieldUnprotected(ByVal row As Object, ByVal Col As Object, ByVal Length As Object) As Boolean
        Dim Unprotected As String = Nothing
        ErrMsg = Nothing
        If atl3270Tool.IsFieldUnprotected(row, Col, Length, Unprotected, ErrMsg) <> S_OK Then
            MsgBox("IsFieldUnprotected failed: " & "ERROR!!", MsgBoxStyle.OkOnly)
        Else
            DirIsFieldUnprotected = Unprotected
        End If
    End Function

    'The LoanNo property is used to read and write the loan number associated with the current MSP screen.
    'If a loan-level screen is displayed then the new loan number will be automati y entered at the correct
    'position on the screen and data retrieved. If the current screen is unrecognized or not an MSP screen,
    'then this property will have the value of the most recently recognized valid loan number.
    'The loan number represented by the LoanNo property will normally be synchronized with Director�s LoanBar,
    'but this can be controlled by setting the SynchronizeLoanNoChange property.
    Public Function DirLoanNo(ByVal ReadorWrite As String) As String
        LoanNum = atl3270Tool.loanno
        Return atl3270Tool.loanno
    End Function

    'The MoveCursor method repositions the 3270 screen�s text cursor to the position specified in the input
    'parameters Row and Col.
    Public Sub DirMoveCursor()
        ErrMsg = Nothing
        If atl3270Tool.MoveCursor(row, Col, ErrMsg) <> S_OK Then
            MsgBox("DirMoveCursor failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If
    End Sub

    'This method pastes the contents of the Windows� clipboard into the current field on the 3270 screen.
    'If the text cursor is not currently in an editable field then no action is taken. Only sufficient characters
    'to fill the current field are copied.

    Public Sub DirPasteFromClipboard()
        ErrMsg = Nothing
        If atl3270Tool.PasteFromClipboard(ErrMsg) <> S_OK Then
            MsgBox("PasteFromClipboard failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If
    End Sub

    'This method is used to pause a script that is executing while the user examines or fills out a particular screen.
    'The duration of the pause is specified in the WaitTime input parameter and may be from 1 to 300 seconds (5 minutes).
    'Values outside of this range will be defaulted to the closest upper or lower limit. If this function is used then a
    '�Resume� button appears on the 3270 errlorer�s tool bar (or pop-up menu if the tool bar is not currently displayed)
    'with a �countdown� display of the pause time remaining as shown in the partial screen image below.
    'Execution of the script resumes when the button is clicked or the timeout period errires. Set the
    'AllowScriptsWhilePaused parameter to True to allow other actions such as SmartButtons while scripts are running.
    'It is recommended that AllowScriptsWhilePaused be set to False. If this is set to True, other actions taken by the
    'user while the script is paused (such as SmartButton navigation) may cause further logic in the script to fail.

    Public Sub DirPauseOnScreen(ByVal WaitTime As Short, ByVal AllowScriptsWhilePaused As Boolean)
        ErrMsg = Nothing
        If atl3270Tool.PauseOnScreen(WaitTime, AllowScriptsWhilePaused, ErrMsg) <> S_OK Then
            MsgBox("PauseOnScreen failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If
    End Sub

    'MSP workstation security frequently restricts update capability to only the first session for a given RACF sign-on;
    'all other sessions using this same RACF user name are given read-only access. Because Director provides the ability
    'to launch more than one 3270 errlorer session, it may be important for a script to identify the primary RACF session
    ' with full update capabilities. This read-only Boolean property will return a value of True if the tool instance
    'can be identified as containing a primary RACF session. PrimarySession for all other tool instances will be False.

    Function DirPrimarySession() As Boolean
        DirPrimarySession = atl3270Tool.PrimarySession
    End Function

    Public Sub DirStrictFieldCheck(ByVal CheckOnOFf As Boolean)
        atl3270Tool.StrictFieldCheck = CheckOnOFf
    End Sub


    'The ReadScreen method reads a character string from the current 3270 screen starting at the position specified
    'in the Row and Col input parameters, up to the length specified by the Length input parameter. If a value of zero (0)
    'is specified for Length, then ReadScreen will return the entire contents of the CICS screen field that the specified
    'Row and Column position is contained in. This can be useful because you do not need to know the exact length of the
    'field, but may not always return errected values and should be used with caution for the following reasons:
    '*  The start postion of the field may be before the specified Row and Column positon.
    '*  MSP screens frequently display read-only information as a single physical field even though multiple
    '   logical fields are represented.
    'The string read is returned in the ScreenString output parameter.

    Public Function DirReadScreen(ByVal row As String, ByVal Col As String, ByVal Length As String) As String
        ScreenString = Nothing
        ErrMsg = Nothing
        If atl3270Tool.readscreen(row, Col, Length, ScreenString, ErrMsg) <> S_OK Then
            MsgBox("readscreen failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
            ScriptError = True
        Else
            DirReadScreen = ScreenString
            ScriptError = False
        End If
        Return ScreenString
    End Function

    'This function sets the selected text rectangle on the 3270 emulator, usually to be used with 
    'a subsequent CopyToClipboard command. The ULRow, ULCol, LRRow, and LRCol input parameters specify 
    'the upper left and lower right co-ordinates of the desired rectangle. Setting all values to zero 
    'will clear the current selection.'

    Public Function DirSetSelectionRectangle(ByVal ULRow As String, ByVal ULCol As String, ByVal LRRow As String,
                                             ByVal LRCol As String) As String
        ErrMsg = Nothing
        If atl3270Tool.SetSelectionRectangle(ULRow, ULCol, LRRow, LRCol, ErrMsg) <> S_OK Then
            MsgBox("SetSelectionRectangle failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        Else
        End If
        Return ScreenString
    End Function

    'The GetSelectionRectangle method is used to obtain the boundaries of any current 
    'selection rectangle. The rectangle�s upper left and lower right row/column coordinates 
    'are returned in the ULRow, ULCol, LRRow and LRCol output parameters

    Public Function DirGetSelectionRectangle(ByVal ULRow As String, ByVal ULCol As String, ByVal LRRow As String,
                                             ByVal LRCol As String) As String
        ErrMsg = Nothing
        If atl3270Tool.SetSelectionRectangle(ULRow, ULCol, LRRow, LRCol, ErrMsg) <> S_OK Then
            MsgBox("GetSelectionRectangle failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        Else
        End If
        Return ScreenString
    End Function

    'This function is used to send keystrokes to the screen, simulating user input. The input parameter DataString
    'is the string of characters to be sent. Keystrokes may be either text strings or special HLLAPI command symbols
    'representing functions of the emulator (for example, navigational commands). The set of special commands supported
    'is detailed in the Supported HLLAPI and Extended Command Strings topic and is identical to those supported by previous
    'versions of Director. HLLAPI command symbols are designated by �@� (the �at� sign) which is treated as a special character. If the text
    'you are sending includes a literal �@� that is not part of an HLLAPI command then it will need to be �escaped�
    'by substituting it with �@@� (two consecutive �at� signs).For example, if you wish to update the borrower�s
    'email address on the ADD1 window of the MAS1 workstation instead of sending the text string
    '"subscriber@service.provider.com", you would need to send "subscriber@@service.provider.com". It might not always
    'be known when text might include one or more �@� that are not representing special commands. In these cases, the
    'following generic function can be used to ensure that these characters are correctly escaped:

    Public Function DirSendKeystrokes(ByVal row As String, ByVal Col As String, ByVal SendString As String) As Integer
        ScreenString = Nothing
        ErrMsg = Nothing
        Try
            If row = "" Then
                If atl3270Tool.SendKeystrokes(SendString, ErrMsg) = S_OK Then
                    ' .. Success ..
                    ScriptError = False
                    'If TrackClicks = True Then
                    '    If Left(SendString, 1) = "@" Then ReportClick(My.Application.Info.AssemblyName, "", "", SendString)
                    'End If

                Else
                    MsgBox(ErrMsg)
                    ScriptError = True
                End If
            Else
                If atl3270Tool.MoveCursor(row, Col, ErrMsg) = S_OK Then
                    If atl3270Tool.SendKeystrokes(SendString, ErrMsg) = S_OK Then
                        ' .. Success ..
                        'If Left(SendString, 1) = "@" Then
                        '    ReportClick(My.Application.Info.AssemblyName, "", "", SendString)
                        'End If
                    Else
                        If Trim(ErrMsg) = "SendKeystrokes was not successful. Field is protected." Then
                        Else
                            MsgBox(ErrMsg)
                        End If
                    End If
                Else
                    MsgBox(ErrMsg)
                End If
            End If

        Catch exp As Exception
            MsgBox(exp.Message)
        End Try
    End Function

    'This method displays a specified MSP screen and window, and optionally changes the current LoanNo property.
    'The desired screen, window and new loan number are supplied in the input parameters Screen, Window and LoanNo.
    'The default window for a given screen can be specified either as a blank string or as eight asterisks (�********�).
    'If the LoanNo parameter is left blank then the current value of the LoanNo property will be used. If there is no
    'current loan number and the requested screen is a loan-level screen then a dialog box will appear, prompting the
    'user to enter a valid loan number.

    Public Sub DirShowScreen(ByVal Screen As String, ByVal Window As String, ByVal LoanNumber As String)
        If UCase(Screen) = "P103" Then
            Screen = "PL03"
        End If
        ErrMsg = Nothing
        If atl3270Tool.ShowScreen(Screen, Window, LoanNumber, ErrMsg) <> S_OK Then
            'MsgBox("ShowScreen failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
            ScriptError = True
        Else
            ScriptError = False
            ''If TrackClicks = True Then ReportClick(My.Application.Info.AssemblyName, Screen, Window, "Scrn")
        End If
    End Sub

    'This method causes script execution to pause until a specified screen is displayed, or until a timeout occurs.
    ' This is useful for ensuring that a previous command completed successfully. The desired screen and window are
    'specified in the input parameters Screen and Window, and the interval to wait before timing out in the input parameter
    'WaitTime. The delay interval is specified as a number of seconds between 1 and 60. If a number outside of this range
    'is specified, WaitTime will default to 60 seconds.

    Public Sub DirWaitForDefinedScreen(ByVal Screen As String, ByVal Window As String, ByVal WaitTime As Short)
        ErrMsg = Nothing
        If atl3270Tool.WaitForDefinedScreen(Screen, Window, WaitTime, ErrMsg) <> S_OK Then
            MsgBox("WaitForDefinedScreen failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If
    End Sub

    'This method causes the script execution to pause until a specified string is displayed at a specified location
    'on the screen, or until a timeout occurs. The desired string and its location are specified in the String,
    'Row and Col input parameters, and the interval to wait before timing out in the input parameter WaitTime. The delay
    'interval is specified as a number of seconds between 1 and 60. If a number outside of this range is specified,
    'WaitTime will default to 60 seconds.
    Public Sub DirWaitForString(ByVal row As String, ByVal Col As String, ByVal ScreenString As String)
        ScreenString = Nothing
        ErrMsg = Nothing
        If row <> "" Then
            If atl3270Tool.WaitForString(row, Col, 60, ScreenString, ErrMsg) <> S_OK Then
                MsgBox("WaitForString failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
            End If
        Else

        End If
    End Sub

    'This method returns the current screen that is active in MSP
    Public Function DirCurrentScreen() As String
        ErrMsg = Nothing
        If atl3270Tool.CurrentScreen <> S_OK Then
            MsgBox("Check Current Screen failed: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        Else
            DirCurrentScreen = atl3270Tool.CurrentScreen
        End If
        Return atl3270Tool.CurrentScreen()
    End Function

    'Connects to Email tool. Reuses the the tool if it is available. ''Prepares an email in Director
    '''''''Change due to the Lotus Notes Migration''''''''
    '' ''Public Sub DirEmailTool(ByRef strEMessage As String, ByRef strERecipient As String, ByRef strESubject As String, ByRef strECC As String, ByRef strAttatchment As String, ByVal SendIt As Boolean)
    '' ''    ErrMsg = Nothing
    '' ''    atlEmailTool = Nothing
    '' ''    If DirObject.CreateTool("Email", 1, True, True, 0, atlEmailTool, ErrMsg) <> S_OK Then
    '' ''        MsgBox("Unable to create Email tool: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
    '' ''    Else
    '' ''        WFHQ()
    '' ''        atlEmailTool.Recipient = strERecipient
    '' ''        atlEmailTool.Subject = strESubject
    '' ''        atlEmailTool.EMailMessageText = strEMessage
    '' ''        atlEmailTool.CC = strECC
    '' ''        If strAttatchment <> Nothing Then
    '' ''            atlEmailTool.Attachment = strAttatchment
    '' ''        End If
    '' ''        If SendIt = True Then
    '' ''            atlEmailTool.SendMail()
    '' ''        End If
    '' ''    End If
    '' ''End Sub

    ''''''New Lotus Notes SMTP Email   using FHBusEmail DLL''''''
    ''Public Sub DirEmailTool(ByRef strEMessage As String, ByRef strERecipient As String, ByRef strESubject As String, ByRef strECC As String, ByRef strAttachment As String, ByVal SendIt As Boolean)
    ''    If SendIt = False Then
    ''        Dim frmEmail As New frmEmail
    ''        frmEmail.txtBody.Text = strEMessage
    ''        frmEmail.txtCC.Text = strECC
    ''        frmEmail.txtSubject.Text = strESubject
    ''        frmEmail.txtTo.Text = strERecipient
    ''        frmEmail.txtAttachments.Text = strAttachment
    ''        frmEmail.txtFrom.Text = GetConfigSetting("EmailFrom")
    ''        frmEmail.ShowDialog()
    ''    Else
    ''        Dim SmtpEmail As New FHBusEmail.clsMessage
    ''        SmtpEmail.AddRecipient(strERecipient)
    ''        SmtpEmail.AddCC(strECC)
    ''        If strAttachment <> Nothing Then
    ''            SmtpEmail.AddAttachment(strAttachment)
    ''        End If
    ''        If SmtpEmail.Send(EmailParser(""), strESubject, strEMessage) = True Then
    ''            MessageBox.Show("Email Sent Successfully")
    ''        Else
    ''            MessageBox.Show("Error: Email Not Sent.")
    ''        End If
    ''    End If
    ''End Sub

        Public Function EmailParser(ByVal EmailName As String)
        If Right(EmailName, 14) = "metcommapp.com" Then
            Return EmailName
        End If
        Return ParseText(EmailName, "@", ".", "F")
    End Function


    'Connects to snapshoot tool. Reuses the the tool if it is available. Retrieves loan information without incurring click cost
    Public Sub DirSnapShotTool(ByVal SnapShotName As String, ByVal vVisible As Boolean, ByVal fFocus As Boolean)
        ErrMsg = Nothing
        atlSnapShotTool = Nothing

        If DirObject.CreateTool("SnapShot", 1, vVisible, fFocus, 0, atlSnapShotTool, ErrMsg) <> S_OK Then
            MsgBox("Unable to create Snapshot tool: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        Else
            GetSnapShotToolData(SnapShotName)
        End If
    End Sub

    Public Function DirSnapShotToolNoData(ByVal SnapShotName As String, ByVal vVisible As Boolean,
                                          ByVal fFocus As Boolean) As Boolean
        ErrMsg = Nothing
        atlSnapShotTool = Nothing

        If DirObject.CreateTool("SnapShot", 1, vVisible, fFocus, 0, atlSnapShotTool, ErrMsg) <> S_OK Then
            MsgBox("Unable to create Snapshot tool: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If
        atlSnapShotTool.SnapshotName = SnapShotName
        If atlSnapShotTool.SnapshotName <> SnapShotName Then
            Return False
        Else
            Return True
        End If
    End Function

    Public Function RetrieveSnapShot() As Boolean
        Dim Data As String
        Data = Nothing
        Try
            atlSnapShotTool.LoanNo = LoanNum
            If atlSnapShotTool.Retrieve(ErrMsg) = S_OK Then
                atlSnapShotTool.GetSnapshotData(2, Data, ErrMsg)
                Debug.Print(Data)
                LoadXMLString(Data)
                ''ReportClick(My.Application.Info.AssemblyName, atlSnapShotTool.SnapshotName, "", "Snap")
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Function

    Public Function DirLoanActivityTool(ByVal ActivityType As String, ByVal vVisible As Boolean, ByVal fFocus As Boolean,
                                        ByVal StartDate As Date, ByVal StopDate As Date) As Boolean
        ErrMsg = Nothing
        atlActivity = Nothing

        If DirObject.CreateTool("Activity", 1, vVisible, fFocus, 0, atlActivity, ErrMsg) <> S_OK Then
            MsgBox("Unable to create Snapshot tool: " & ErrMsg & "ERROR!!", MsgBoxStyle.OkOnly)
        End If
        atlActivity.ClientID = "481"
        atlActivity.LoanNo = LoanNum
        atlActivity.ActivityType = ActivityType
        atlActivity.FromDate = StartDate
        atlActivity.ToDate = StopDate

        If atlActivity.ActivityType <> ActivityType Then
            Return False
        Else
            Return True
        End If
    End Function

    Public Function RetrieveActivityData() As Boolean
        Dim Data As String
        Data = Nothing
        Try
            atlActivity.LoanNo = LoanNum
            If atlActivity.Retrieve(ErrMsg) = S_OK Then
                atlActivity.GetActivityData(2, Data, ErrMsg)
                Debug.Print(Data)
                LoadXMLString(Data)
                'ReportClick(My.Application.Info.AssemblyName, atlSnapShotTool.SnapshotName, "", "Activ")
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Function

    Public Sub GetCompNum()
        Try
            ''''CompNotice is used to hold the value''''
            atl3270Tool.LoanNo = LoanNum
            CompNotice = Nothing
            DirSnapShotTool("CompInd", True, False)
            If CompNotice = "900 - COMPANY NUMBER" Then CompNotice = "FH"
            If CompNotice = "301 - COMPANY NUMBER" Then CompNotice = "ML"
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
    End Sub

    Public Sub GetSnapShotToolData(ByVal sSnapshotName As String)
        Dim Data, OldSnapShot As String
        Data = Nothing
        OldSnapShot = atlSnapShotTool.SnapshotName
        atlSnapShotTool.SnapshotName = sSnapshotName
        atlSnapShotTool.ClientId = "481"
        ' Ensure that snapshot loan number is synchronized with 3270
        atlSnapShotTool.LoanNo = atl3270Tool.LoanNo
        If atlSnapShotTool.Retrieve(ErrMsg) = S_OK Then
            ''ReportClick(My.Application.Info.AssemblyName, atlSnapShotTool.SnapshotName, "", "Snap")
            ' bValidLoan = True
            atlSnapShotTool.GetSnapshotData(2, Data, ErrMsg)
            LoadXMLString(Data)
            Select Case sSnapshotName
                Case "PendingInvestor"
                    Dim InvId As String
                    Dim USR38A As String
                    InvId = GetFieldValue("IV_ID")
                    USR38A = GetFieldValue("USR3_3_PFld_8A")
                    If USR38A = "" Then USR38A = InvId
                    If USR38A <> InvId Then _
                        MessageBox.Show("THERE IS A PENDING INVESTOR CHANGE!", "", MessageBoxButtons.OK,
                                        MessageBoxIcon.Exclamation)
                    MessageBox.Show("It ran" & USR38A)
                Case "CompInd"
                    CompNotice = GetFieldValue("3_POS_FLD_1")
            End Select
            If atlSnapShotTool.SnapshotName <> OldSnapShot Then
                atlSnapShotTool.SnapshotName = OldSnapShot
                atlSnapShotTool.Retrieve(ErrMsg)
            End If
        Else
            MessageBox.Show(ErrMsg)
        End If
    End Sub

    '' Load XML data into XML parser and validate 
    Public Sub LoadXMLString(ByVal Data As String)

        Dim Node As Object
        xmlDoc = CreateObject("Microsoft.XMLDOM")
        xmlDoc.async = False
        xmlDoc.LoadXML(Data)

        Node = xmlDoc.SelectSingleNode("RpcData")
        If Node.xml = "" Then
            MessageBox.Show("Unable to parse snapshot data. Data is not valid XML.")
        ElseIf Node.Attributes.GetNamedItem("RsltCd").nodeValue <> 0 Then
            MessageBox.Show(Node.Attributes.GetNamedItem("ErrMsg").nodeValue)
        End If
        Node = Nothing
    End Sub

    '*************************************************************************************
    '-- Obtain the value of a named field from the snapshot XML --
    '*************************************************************************************
    Function GetFieldValue(ByVal FldName)

        Dim FldList, FldNode, Found
        Found = False
        GetFieldValue = ""
        FldList = xmlDoc.SelectSingleNode("RpcData").SelectNodes("Fld")
        For Each FldNode In FldList
            Debug.Print(FldNode.Attributes.GetNamedItem("Nm").nodeValue)
            If FldNode.Attributes.GetNamedItem("Nm").nodeValue = FldName Then
                GetFieldValue = FldNode.Text
                Found = True
                Exit For
            End If
        Next
        If Not Found Then
            MsgBox("Field " & FldName & " not found.", vbOKOnly + vbCritical, "XML Error")
        End If
    End Function

    '***************************************************************************************
    '-- Use XML parser to get field value for Director 4.0 --
    '***************************************************************************************
    Function GetFieldValue40(ByVal FldName)

        Dim FldList, FldNode, Found
        Found = False
        GetFieldValue40 = ""
        FldList = xmlDoc.SelectSingleNode("RpcData").SelectNodes("Fld")
        For Each FldNode In FldList
            If FldNode.Attributes.GetNamedItem("Nm").nodeValue = FldName Then
                GetFieldValue40 = FldNode.Text
                Found = True
                Exit For
            End If
        Next
        If Not Found Then
            MsgBox("Field " & FldName & " not found.", vbOKOnly + vbCritical, "XML Error")
        End If
    End Function


    ''''''''Set Loan Indicators''''''''
    Public Sub DirIndicators(ByRef IndStatus As Boolean)
        DirObject.LoanIndicatorsVisible = IndStatus
    End Sub


    '**** send comments to workstation notes screen
    Public Sub SNotes(ByVal SERLCd As String, ByRef strNoteType As String)
        Dim LenC As Short
        If Left(Stmt, 6) = "SELECT" Then Stmt = ""
        If Stmt.Trim = "" Then Exit Sub
        Select Case strNoteType
            Case "BK", "BNK", "FC", "LN", "LM"
                DirSendKeystrokes("", "", "@5")
                ''Send Log Code''
                If SERLCd <> Nothing Then DirSendKeystrokes(11, 3, SERLCd)
                ''Send First Line of comments up to 50 Chr per line''
                DirSendKeystrokes(12, 24, Left(Stmt, 50))
                If Trim(Mid(Stmt, 51, 50)) <> "" Then
                    DirSendKeystrokes(13, 24, Mid(Stmt, 51, 50))
                End If
                If Trim(Mid(Stmt, 101, 50)) <> "" Then
                    DirSendKeystrokes(14, 24, Mid(Stmt, 101, 50))
                End If
                If Trim(Mid(Stmt, 151, 50)) <> "" Then
                    DirSendKeystrokes(15, 24, Mid(Stmt, 151, 50))
                End If
                If Trim(Mid(Stmt, 201, 50)) <> "" Then
                    DirSendKeystrokes(16, 24, Mid(Stmt, 201, 50))
                End If
                If Trim(Mid(Stmt, 251, 50)) <> "" Then
                    DirSendKeystrokes(17, 24, Mid(Stmt, 251, 50))
                End If
                If Trim(Mid(Stmt, 301, 50)) <> "" Then
                    DirSendKeystrokes(18, 24, Mid(Stmt, 301, 50))
                End If
                If Trim(Mid(Stmt, 351, 50)) <> "" Then
                    DirSendKeystrokes(19, 24, Mid(Stmt, 351, 50))
                End If
                If Trim(Mid(Stmt, 401, 50)) <> "" Then
                    DirSendKeystrokes(20, 24, Mid(Stmt, 401, 50))
                End If
                DirEnter()
            Case "DLQ"
                LenC = Len(Trim(Stmt))
                Do Until LenC < 1
                    DirSendKeystrokes("", "", "@3")
                    DirSendKeystrokes(19, 20, Left(Stmt, 50))
                    LenC = LenC - 50
                    If Trim(Mid(Stmt, 51, 50)) <> "" Then
                        DirSendKeystrokes(20, 20, Mid(Stmt, 51, 50))
                        LenC = LenC - 50
                    End If
                    If Trim(Mid(Stmt, 101, 50)) <> "" Then
                        DirSendKeystrokes(21, 20, Mid(Stmt, 101, 50))
                        LenC = LenC - 50
                    End If
                    DirEnter()
                Loop
            Case "SER", "TSK"
                DirSendKeystrokes("", "", "@5")

                ''Send First Line of comments up to 50 Chr per line''
                DirSendKeystrokes(12, 13, Left(Stmt, 50))
                If Trim(Mid(Stmt, 51, 50)) <> "" Then
                    DirSendKeystrokes(13, 13, Mid(Stmt, 51, 50))
                End If
                If Trim(Mid(Stmt, 101, 50)) <> "" Then
                    DirSendKeystrokes(14, 13, Mid(Stmt, 101, 50))
                End If
                If Trim(Mid(Stmt, 151, 50)) <> "" Then
                    DirSendKeystrokes(15, 13, Mid(Stmt, 151, 50))
                End If
                If Trim(Mid(Stmt, 201, 50)) <> "" Then
                    DirSendKeystrokes(16, 13, Mid(Stmt, 201, 50))
                End If
                If Trim(Mid(Stmt, 251, 50)) <> "" Then
                    DirSendKeystrokes(17, 13, Mid(Stmt, 251, 50))
                End If
                If Trim(Mid(Stmt, 301, 50)) <> "" Then
                    DirSendKeystrokes(18, 13, Mid(Stmt, 301, 50))
                End If
                If Trim(Mid(Stmt, 351, 50)) <> "" Then
                    DirSendKeystrokes(19, 13, Mid(Stmt, 351, 50))
                End If
                If Trim(Mid(Stmt, 401, 50)) <> "" Then
                    DirSendKeystrokes(20, 13, Mid(Stmt, 401, 50))
                End If
                DirEnter()
            Case "TSK1"
                ''Send Log Code''
                DirSendKeystrokes(5, 3, SERLCd)
                ''Send First Line of comments up to 50 Chr per line''
                DirSendKeystrokes(5, 20, Left(Stmt, 50))
                If Trim(Mid(Stmt, 51, 50)) <> "" Then
                    DirSendKeystrokes(6, 20, Mid(Stmt, 51, 50))
                End If
                If Trim(Mid(Stmt, 101, 50)) <> "" Then
                    DirSendKeystrokes(7, 20, Mid(Stmt, 101, 50))
                End If
                If Trim(Mid(Stmt, 151, 50)) <> "" Then
                    DirSendKeystrokes(8, 20, Mid(Stmt, 151, 50))
                End If
                If Trim(Mid(Stmt, 201, 50)) <> "" Then
                    DirSendKeystrokes(9, 20, Mid(Stmt, 201, 50))
                End If
                If Trim(Mid(Stmt, 251, 50)) <> "" Then
                    DirSendKeystrokes(10, 20, Mid(Stmt, 251, 50))
                End If
                If Trim(Mid(Stmt, 301, 50)) <> "" Then
                    DirSendKeystrokes(11, 20, Mid(Stmt, 301, 50))
                End If
                DirSendKeystrokes("", "", "@Enter")

                If Trim(Mid(Stmt, 351, 50)) <> "" Then
                    DirSendKeystrokes(5, 20, Mid(Stmt, 351, 50))
                Else
                    GoTo EndIt
                End If
                If Trim(Mid(Stmt, 401, 50)) <> "" Then
                    DirSendKeystrokes(6, 20, Mid(Stmt, 401, 50))
                End If
                If Trim(Mid(Stmt, 451, 50)) <> "" Then
                    DirSendKeystrokes(7, 20, Mid(Stmt, 101, 50))
                End If
                If Trim(Mid(Stmt, 501, 50)) <> "" Then
                    DirSendKeystrokes(8, 20, Mid(Stmt, 151, 50))
                End If
                If Trim(Mid(Stmt, 551, 50)) <> "" Then
                    DirSendKeystrokes(9, 20, Mid(Stmt, 201, 50))
                End If
                If Trim(Mid(Stmt, 601, 50)) <> "" Then
                    DirSendKeystrokes(10, 20, Mid(Stmt, 251, 50))
                End If
                If Trim(Mid(Stmt, 651, 50)) <> "" Then
                    DirSendKeystrokes(11, 20, Mid(Stmt, 301, 50))
                End If
                DirSendKeystrokes("", "", "@Enter")
                EndIt:
                DirSendKeystrokes("", "", "@1")
        End Select
    End Sub


    ''''This will determin if a specified tool is active'''
    Public Function DeterminTool(ByVal sToolName As String) As Boolean
        Dim sss As String
        Dim x As Integer
        Dim t
        x = 0
        DeterminTool = False

        For Each Tool In DirObject.Workspaces(0).Tools
            If sToolName <> "" Then
                If Tool.ToolName = sToolName Then
                    DeterminTool = True
                ElseIf Tool.toolname = "CompTool" Then
                    sss = Tool.toolcount
                    For x = 0 To Tool.ToolCount - 1
                        t = Tool.tools(x).toolname
                    Next
                End If
            Else
                If Tool.loanno <> Nothing Then
                    DeterminTool = True
                    Exit For
                End If

            End If
        Next
        Return DeterminTool
    End Function

    '    Public Function LocatePL05Letter(ByVal LetterID As String) As String
    '        Dim st As Short
    '        Dim STORE As Short
    '        Dim HitErr As Boolean
    '        Dim PL05Prec As Boolean
    '        Try
    '            PL05Prec = False
    '            STORE = 1
    '            HitErr = False
    '            DirShowScreen("PL05", "", LoanNum)
    '            st = 7

    '            If PL05Preceding <> Nothing Then
    '                '''''Find the Letter'''''''''''''''''''
    '                Do Until DirReadScreen(st, 18, 5).Trim = LetterID And DirReadScreen(st, 15, 2).Trim = PL05Preceding
    'TryAgain:
    '                    If DirReadScreen(st, 18, 5).Trim = "" Then
    '                        'MsgBox("Letter NOT FOUND")
    '                        HitErr = True
    '                        st = 0
    '                        PL05Preceding = "N/A"
    '                        Exit Try
    '                    End If

    '                    If st = 23 Then
    '                        DirSendKeystrokes("", "", "@1")
    '                        STORE = STORE + 1
    '                        If STORE > 4 Then
    '                            'MsgBox("Letter not found on first 4 pages")
    '                            HitErr = True
    '                            st = 0
    '                            PL05Preceding = "N/A"
    '                            Exit Try
    '                        End If
    '                        st = 7
    '                        If DirReadScreen(23, 6, 1) = " " Then
    '                            'MsgBox("Letter NOT FOUND")
    '                            HitErr = True
    '                            st = 0
    '                            PL05Preceding = "N/A"
    '                            Exit Try
    '                        End If
    '                    End If
    '                    st = st + 1
    '                Loop
    '                If CDate(DirReadScreen(st, 6, 8)) < DateAdd(DateInterval.Day, -45, Today) Then
    '                    If DirReadScreen(st, 18, 5).Trim <> PL05Preceding Then
    '                        PL05Preceding = "N/A"
    '                        Exit Try
    '                    End If
    '                Else
    '                    GoTo TryAgain
    '                End If
    '            Else
    '                Do Until DirReadScreen(st, 18, 5).Trim = LetterID
    '                    If st = 23 Then
    '                        DirSendKeystrokes("", "", "@1")
    '                        STORE = STORE + 1
    '                        If STORE > 4 Then
    '                            MsgBox("Letter not found on first 4 pages")
    '                            HitErr = True
    '                            st = 0
    '                            Exit Do
    '                        End If
    '                        st = 7
    '                        If DirReadScreen(23, 6, 1) = " " Then
    '                            'MsgBox("Letter NOT FOUND")
    '                            HitErr = True
    '                            st = 0
    '                            Exit Do
    '                        End If
    '                    End If
    '                    st = st + 1
    '                Loop
    '            End If
    '            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '        Catch exp As Exception
    '            MessageBox.Show(exp.Message)
    '        End Try
    '        If st <> 0 Then
    '            If Len(DirReadScreen(st, 6, 8).Trim) = 8 Then
    '                PL05LetterDate = CDate(DirReadScreen(st, 6, 8))
    '            End If
    '        End If
    '        LocatePL05Letter = st
    '    End Function
    Public Function LocatePL05Letter(ByVal LetterID As String) As String
        Dim st As Short
        Dim STORE As Short
        Dim HitErr As Boolean
        Dim PL05Prec As Boolean
        Try
            PL05Prec = False
            STORE = 1
            HitErr = False
            DirShowScreen("PL05", "", LoanNum)
            st = 7
            PL05LetterDate = Nothing
            If PL05Preceding <> Nothing Then
                '''''Find the Letter'''''''''''''''''''
                Do Until DirReadScreen(st, 18, 5).Trim = LetterID And DirReadScreen(st, 15, 2).Trim = PL05Preceding
                    TryAgain:
                    If DirReadScreen(st, 18, 5).Trim = "" Then
                        'MsgBox("Letter NOT FOUND")
                        HitErr = True
                        st = 0
                        PL05Preceding = "N/A"
                        Exit Try
                    End If

                    If st = 23 Then
                        DirSendKeystrokes("", "", "@1")
                        STORE = STORE + 1
                        If STORE > 4 Then
                            'MsgBox("Letter not found on first 4 pages")
                            HitErr = True
                            st = 0
                            PL05Preceding = "N/A"
                            Exit Try
                        End If
                        st = 7
                        If DirReadScreen(23, 6, 1) = " " Then
                            'MsgBox("Letter NOT FOUND")
                            HitErr = True
                            st = 0
                            PL05Preceding = "N/A"
                            Exit Try
                        End If
                    End If
                    st = st + 1
                Loop
                If CDate(DirReadScreen(st, 6, 8)) > DateAdd(DateInterval.Day, - 45, Today) Then
                    If DirReadScreen(st, 15, 2).Trim <> PL05Preceding Then
                        GoTo TryAgain
                    Else
                        Exit Try
                    End If
                Else
                    GoTo TryAgain
                End If
            Else
                Do Until DirReadScreen(st, 18, 5).Trim = LetterID
                    If st = 23 Then
                        DirSendKeystrokes("", "", "@1")
                        STORE = STORE + 1
                        If STORE > 4 Then
                            'MsgBox("Letter not found on first 4 pages")
                            HitErr = True
                            st = 0
                            Exit Do
                        End If
                        st = 7
                        If DirReadScreen(23, 6, 1) = " " Then
                            'MsgBox("Letter NOT FOUND")
                            HitErr = True
                            st = 0
                            Exit Do
                        End If
                    End If
                    st = st + 1
                Loop
            End If
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
        If st <> 0 Then
            If Len(DirReadScreen(st, 6, 8).Trim) = 8 Then
                PL05LetterDate = CDate(DirReadScreen(st, 6, 8))
            End If
        End If
        LocatePL05Letter = st
    End Function

    Public Sub GetPL05Letters(ByVal Left2LetterChr As String)
        Dim st As Short
        Dim STORE As Short
        Dim HitErr As Boolean
        Dim LetterDate As Date
        Dim LID As String
        Dim LastPage As Boolean
        Try
            LastPage = False
            STORE = 1
            HitErr = False
            DirShowScreen("PL05", "", LoanNum)
            st = 7
            LetterDate = CDate(DirReadScreen(st, 6, 8))
            CFID.Clear()
            Do Until LetterDate < DateAdd(DateInterval.Year, - 1, Today)
                If Trim(DirReadScreen(st, 6, 8)) = "" Then Exit Do
                LetterDate = CDate(DirReadScreen(st, 6, 8))
                'Do Until DirReadScreen(st, 18, 2) = Left2LetterChr
                If DirReadScreen(st, 18, 2) = Left2LetterChr Then
                    LID = DirReadScreen(st, 18, 5)
                    CFID.Add(LID & "        " & LetterDate)
                End If
                st = st + 1
                If st = 23 Then
                    DirSendKeystrokes("", "", "@1")
                    If LastPage = True Then Exit Do
                    If DirReadScreen(23, 6, 1) = " " Then
                        LastPage = True
                    End If
                    STORE = STORE + 1
                    If STORE > 4 Then
                        MsgBox("Letter not found on first 4 pages")
                        HitErr = True
                        st = 0
                        Exit Do
                    End If
                    st = 7
                End If
                'Loop
            Loop
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
    End Sub

    Public Sub LoadPL05Letters(ByVal NumMnthsBk As Integer)
        Dim st As Short
        Dim STORE As Short
        Dim HitErr As Boolean
        Dim LetterDate As Date
        Dim LastPage As Boolean
        Try
            LastPage = False
            STORE = 1
            HitErr = False
            DirShowScreen("PL05", "", LoanNum)
            st = 7
            LetterDate = CDate(DirReadScreen(st, 6, 8))

            Do Until LetterDate < DateAdd(DateInterval.Month, - (NumMnthsBk + 1), Today)
                If Trim(DirReadScreen(st, 6, 8)) = "" Then Exit Do
                LetterDate = CDate(DirReadScreen(st, 6, 8))
                'Do Until DirReadScreen(st, 18, 2) = Left2LetterChr
                ''If DirReadScreen(st, 18, 2) = Left2LetterChr Then
                OLLWID.Add(DirReadScreen(st, 18, 5).Trim.ToString)
                OLLWDT.Add(LetterDate)
                ''End If
                st = st + 1
                If st = 23 Then
                    DirSendKeystrokes("", "", "@1")
                    If LastPage = True Then Exit Do
                    If DirReadScreen(23, 6, 1) = " " Then
                        LastPage = True
                    End If
                    STORE = STORE + 1
                    If STORE > 4 Then
                        'MsgBox("Letter not found on first 4 pages")
                        HitErr = True
                        st = 0
                        Exit Do
                    End If
                    st = 7
                End If
                'Loop
            Loop
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
    End Sub

    Public Sub LoadSnapShot()
        DirObject = CreateObject("atlDirectorObject.atlDirector")
        ''Find an active tool with a loannumber''
        If DeterminTool("") = False Then Exit Sub
        ''''''''''''''''''''''''''''''''
        DirSnapShotTool("PendingInvestor", False, False)
    End Sub
    ''Will retrieve the last 5 70 series transactions from p309 ''
    Public Sub GetLastTrans()
        Dim STORE As Short
        Dim TranCode As Integer
        Dim LastPage As Boolean

        CFTran1.Clear()
        CFTran2.Clear()
        CFTran3.Clear()
        CFTran4.Clear()
        CFTran5.Clear()


        LastPage = False
        STORE = 1

        DirShowScreen("P309", "", LoanNum)
        DirSendKeystrokes("", "", "@5")
        Do Until Trim(DirReadScreen(6, 75, 5)) <> ""
            STORE = STORE + 1
            DirSendKeystrokes("", "", "@6")
            If STORE > 6 Then Exit Do
        Loop

        STORE = 1
        Col = 78
        Do Until LastPage = True
            If DirReadScreen(23, 6, 3) = "001" Then LastPage = True
            TranCode = DirReadScreen(8, Col, 2)
            Do Until TranCode > 69 And TranCode < 80
                If Col = 22 Then
                    DirSendKeystrokes("", "", "@7")
                    Col = 92
                End If
                Col = Col - 14
                TranCode = DirReadScreen(8, Col, 2)
            Loop
            CaptureTran(STORE)
            If Col = 22 Then
                DirSendKeystrokes("", "", "@7")
                Col = 92
            End If
            Col = Col - 14
            STORE = STORE + 1
            If STORE = 6 Then Exit Do
        Loop
    End Sub

    ''Capture the p309 Tran Data''
    Public Sub CaptureTran(ByVal CurrList As Short)
        Dim ColHold As Integer
        rtText = Nothing
        ColHold = Col
        row = 6
        Col = Col - 10
        Do Until row = 21
            rtText = DirReadScreen(row, Col, 12).Trim
            Select Case CurrList
                Case 1
                    CFTran1.Add(rtText)
                Case 2
                    CFTran2.Add(rtText)
                Case 3
                    CFTran3.Add(rtText)
                Case 4
                    CFTran4.Add(rtText)
                Case 5
                    CFTran5.Add(rtText)
            End Select
            row = row + 1
        Loop
        Col = ColHold
    End Sub

    ''Check to see if a task is open'''
    Public Function IsTaskOpen(ByVal strTask As String) As Boolean
        Dim IsOpen As String
        Try
            IsTaskOpen = False
            DirShowScreen("TSK2", "", LoanNum)
            row = 6
            IsOpen = Trim(DirReadScreen(row, 2, 5))
            If IsOpen = "" Then
                IsTaskOpen = False
                Exit Function
            End If
            Do Until IsOpen = "CLOSED"
                If DirReadScreen(row, 10, 5) = strTask Then
                    IsTaskOpen = True
                    Exit Function
                End If
                row = row + 1
                IsOpen = DirReadScreen(row, 2, 6)
            Loop
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
    End Function
    ''close task''
    Public Sub CloseTask(ByVal TskToClose As String)
        Dim TskNote As String
        Dim Trys As Integer
        DirClearScreen()
        DirShowScreen("TSK1", "", LoanNum)
        DirSendKeystrokes(5, 9, TskToClose & "@Enter")
        If DirReadScreen(13, 21, 3) = "ADD" Then
            DirClearScreen()
            Exit Sub
        End If
        DirSendKeystrokes("", "", "@b")
        If DirReadScreen(13, 28, 7).Trim = "RE-OPEN" Then
            DirClearScreen()
            Exit Sub
        End If
        If DirReadScreen(13, 12, 4) = "PF11" Then
            DirSendKeystrokes("", "", "@b")
        End If
        TskNote = ""
        If DirReadScreen(4, 3, 4) = "TSKN" Then
            Select Case TskToClose
                Case "CSHDEL"
                    TskNote = "Deleted ACH Drafting"
                Case "CSHDFT"
                    TskNote = "Request completed"
                Case "CSHCHG"
                    TskNote = "Request Completed"
                Case "CSHDUP"
                    TskNote = "Request Completed"
            End Select
            DirSendKeystrokes(5, 20, TskNote & "@Enter")
            DirClearScreen()
            DirShowScreen("TSK1", "", LoanNum)
            DirSendKeystrokes(5, 9, TskToClose & "@Enter")
            WFHQ()
            DirSendKeystrokes("", "", "@b")
            If DirReadScreen(13, 28, 7).Trim = "RE-OPEN" Then
                DirClearScreen()
                Exit Sub
            Else
                DirSendKeystrokes("", "", "@b")
            End If
        End If
        WFHQ()
        WFHQ()
        Trys = 0
        frmWait.ShowDialog()
        Do Until Trys = 10
            'Do Until DirReadScreen(13, 6, 5) = "PRESS"
            If DirReadScreen(13, 6, 5) = "ENTER" Then
                DirClearScreen()
                Exit Sub
            End If
            Trys = Trys + 1
        Loop
        ''DirSendKeystrokes("", "", "@b")
        ''If DirReadScreen(11, 6, 10) = "PRESS PF11" Then DirSendKeystrokes("", "", "@b")
        ''If DirReadScreen(12, 6, 10) = "PRESS PF11" Then DirSendKeystrokes("", "", "@b")
        ''If DirReadScreen(13, 6, 10) = "PRESS PF11" Then DirSendKeystrokes("", "", "@b")
        ''If DirReadScreen(14, 6, 10) = "PRESS PF11" Then DirSendKeystrokes("", "", "@b")
        DirClearScreen()
    End Sub
    ''Open Task''''
    Public Sub OpenTask(ByVal TskToOpen As String, ByVal strMessage As String, ByVal strSRC As String,
                        ByVal strSRCmsg As String, ByVal strFollowUp As String)
        DirShowScreen("TSK1", "", LoanNum)
        DirSendKeystrokes(5, 9, TskToOpen & "@Enter")
        DirSendKeystrokes(7, 6, strSRC)
        DirSendKeystrokes(7, 9, strSRCmsg)
        DirSendKeystrokes(6, 10, strMessage)
        DirSendKeystrokes(9, 28, strFollowUp)
        'DirSendKeystrokes("", "", "@Enter")
    End Sub

    ''Look for a transaction requested
    Public Function LookForTran(ByVal CurrType As Integer, ByVal CurrTran As Integer) As Boolean
        Dim STORE As Short
        Dim TranCode As Integer
        Dim TranType As Integer
        Dim LastPage As Boolean


        LastPage = False
        STORE = 1
        LookForTran = False

        DirShowScreen("P309", "", LoanNum)
        DirSendKeystrokes("", "", "@5")
        Do Until Trim(DirReadScreen(6, 75, 5)) <> ""
            STORE = STORE + 1
            DirSendKeystrokes("", "", "@6")
            If STORE > 6 Then Exit Do
        Loop

        STORE = 1
        Col = 78
        Do Until LastPage = True
            If DirReadScreen(23, 6, 3) = "001" Then LastPage = True
            TranCode = DirReadScreen(8, Col, 2)
            TranType = DirReadScreen(8, Col - 3, 1)
            Do Until TranCode = CurrTran And TranType = CurrType
                If Col = 22 Then
                    If DirReadScreen(23, 6, 3) = "001" Then
                        LastPage = True
                        MessageBox.Show("Tran code not found.")
                        LookForTran = False
                        Exit Function
                    End If

                    DirSendKeystrokes("", "", "@7")
                    Col = 92
                End If
                Col = Col - 14
                TranCode = DirReadScreen(8, Col, 2)
                TranType = DirReadScreen(8, Col - 3, 1)
            Loop
            If TranCode = CurrTran And TranType = CurrType Then
                LookForTran = True
                Exit Function
            End If

            If Col = 22 Then
                DirSendKeystrokes("", "", "@7")
                Col = 92
            End If
            Col = Col - 14
            STORE = STORE + 1
            If STORE = 6 Then Exit Do
        Loop
    End Function

    Function DirASSISTFile(ByVal Filter As String, ByVal Title As String) As String
        Dim strFilePath As String
        strFilePath = Nothing
        If atl3270Tool.ASSISTFile("Please select a file:", Filter, "", "", strFilePath, ErrMsg) <> 0 Then
            MsgBox("Unable to get file path.", vbOKOnly + vbCritical + vbSystemModal, Title)
        End If
        DirASSISTFile = strFilePath
        If Len(strFilePath) = 0 Then
            MsgBox("File not selected. Script execution canceled.", vbOKOnly + vbCritical + vbSystemModal, Title)
        End If
        Return DirASSISTFile
    End Function

    Public Sub Cash_Ftb_Login()
        Try
            DirSessionConnect()
            DirClearScreen()
            DirSendKeystrokes(1, 1, "CSSF" & "@Enter")
            If DirReadScreen(1, 2, 4) = "CSSF" Then
                DirClearScreen()
            End If
            DirClearScreen()
            DirSendKeystrokes(1, 2, "ftb" & "@Enter")
            If DirReadScreen(23, 2, 3) = "DFH" Then
                DirClearScreen()
                DirSendKeystrokes(1, 1, "CSSF" & "@Enter")
                DirClearScreen()
                DirSendKeystrokes(1, 2, "ftb" & "@Enter")
            End If
            frmWait.ShowDialog()
            WFHQ()
            WFHQ()
            'MessageBox.Show("Wait for command line")
            DirWaitForString(CStr(23), CStr(2), "Command")
            row = 9
            Col = 5
            'MessageBox.Show("Search for report")
            Do Until DirReadScreen(row, Col, 5) = "XPTRP"
                row = row + 1
            Loop
            'MessageBox.Show("Submit S to open report")
            DirSendKeystrokes(row, Col - 3, "s" & "@Enter")
            'MessageBox.Show("Wait for Security line")
            DirWaitForString(CStr(15), CStr(1), "Security")
            'Dim frmLogon As New frmLogon
            'frmLogon.ShowDialog()

        Catch exp As Exception
            MsgBox("Error on ftb login: " & exp.Message)
        End Try
    End Sub
    ''use Director funtion to locate file
    Public Function BrowseForFile() As String
        ''Connect to Director session'''
        DirSessionConnect()
        BrowseForFile = DirASSISTFile("Excel files (*.xls)|*.XLS", "Select File to Load.")
        Return BrowseForFile
    End Function

    Public Function ParseText(ByVal strParse As String, ByVal strPos1 As String, ByVal strPos2 As String,
                              ByVal SendBack As String)
        Dim FirstPar As String
        Dim LastPar As String
        Dim MidPar As String
        Dim posPound1 As Integer
        Dim posPound2 As Integer
        Dim lenFirstPar As Integer
        Dim lenLastPar As Integer
        ParseText = ""
        Try

            posPound1 = InStr(1, strParse, strPos1)
            posPound2 = InStr(posPound1 - 1, Trim(strParse), strPos2)
            FirstPar = Mid(strParse, 1, posPound1 - 1)
            lenFirstPar = Len(Trim(FirstPar))
            If posPound2 = 0 Then
                lenLastPar = Len(Trim(strParse)) - posPound1
                MidPar = " "
            Else
                lenLastPar = posPound2 - (posPound1 + 1)
                MidPar = Mid(strParse, posPound2 + 1)
            End If
            LastPar = ""
            If lenLastPar > 0 Then
                LastPar = Trim(Mid(strParse, posPound1 + 1, lenLastPar))
            End If

            Select Case SendBack
                Case "F"
                    ParseText = Trim(FirstPar)
                Case "M"
                    ParseText = Trim(MidPar)
                Case "E"
                    If Trim(LastPar) = "" Then
                        ParseText = Trim(MidPar)
                    Else
                        ParseText = Trim(LastPar)
                    End If

            End Select
            ParseText = Replace(ParseText, strPos1, "")
            ParseText = Replace(ParseText, strPos2, "")
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
        Return ParseText
    End Function
    ''Split the city, state, zip from DLQ1
    Public Sub ParseAddress(ByVal strParse As String, ByVal PropOrMail As String)
        Dim FirstPar, MidPar, LastPar As String
        Dim strPos2, strPos1 As String
        Dim posPound1 As Integer
        Dim posPound2 As Integer
        Dim lenFirstPar As Integer
        Dim lenLastPar As Integer
        strPos1 = " "
        strPos2 = " "
        Try
            posPound1 = InStr(1, strParse, strPos1)
            posPound2 = InStr(posPound1 + 1, Trim(strParse), strPos2)
            Redo:
            FirstPar = Mid(strParse, 1, posPound1 - 1)

            lenFirstPar = Len(Trim(FirstPar))
            If posPound2 = 0 Then
                lenLastPar = Len(Trim(strParse)) - posPound1
                LastPar = " "
            Else
                lenLastPar = posPound2 - (posPound1 + 1)
                LastPar = Mid(strParse, posPound2 + 1)
            End If
            MidPar = ""
            If lenLastPar > 0 Then
                MidPar = Trim(Mid(strParse, posPound1 + 1, lenLastPar))
            End If
            Select Case MidPar
                Case "AK", "AL", "AR", "AZ", "CA", "CO", "CT", "DC", "DE", "FL", "GA", "HI", "IA", "ID",
                    "IL", "IN", "KS", "KY", "LA", "MA", "MD", "ME", "MI", "MN", "MO", "MS", "MT", "NC", "ND",
                    "NE", "NH", "NJ", "NM", "NV", "NY", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT",
                    "VA", "VT", "WA", "WI", "WV", "WY"
                Case Else
                    posPound1 = posPound2
                    posPound2 = InStr(posPound1 + 1, Trim(strParse), strPos2)
                    GoTo Redo
            End Select

            If PropOrMail = "P" Then
                strCity = FirstPar
                strState = MidPar
                strZip = LastPar
            Else
                strMailCity = FirstPar
                strMailState = MidPar
                strMailZip = LastPar
            End If
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
    End Sub

    ''Obtain Holidays from system''
    Public Sub GetHolidays()
        Dim row, col As Integer
        Try
            HolidayList.Clear()
            DirClearScreen()
            row = 7
            col = 2
            DirSendKeystrokes(1, 1, "RW01" & "@Enter")
            DirSendKeystrokes("", "", "@Enter")
            DirSendKeystrokes(17, 24, "X" & "@Enter")

            Do _
                Until _
                    DirReadScreen(row, col, 6).Trim = "" Or DirReadScreen(row, col, 3).Trim = "SAT" Or
                    DirReadScreen(row, col, 6).Trim = "______"
                HolidayList.Add(
                    DirReadScreen(row, col, 2) & "/" & DirReadScreen(row, col + 2, 2) & "/" &
                    DirReadScreen(row, col + 4, 2))
                row = row + 2
            Loop
            row = 7
            col = 43
            Do _
                Until _
                    DirReadScreen(row, col, 6).Trim = "" Or DirReadScreen(row, col, 3).Trim = "" Or
                    DirReadScreen(row, col, 6).Trim = "______"
                HolidayList.Add(
                    DirReadScreen(row, col, 2) & "/" & DirReadScreen(row, col + 2, 2) & "/" &
                    DirReadScreen(row, col + 4, 2))
                row = row + 2
            Loop
            DirClearScreen()
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
    End Sub

    Public Function GetNextBusinessDay(ByVal NBD As Date)
        Dim i As Integer
        Retry:
        Do While Weekday(NBD) = 1 Or Weekday(NBD) = 7
            NBD = DateAdd(DateInterval.Day, 1, NBD)
        Loop
        For i = 0 To HolidayList.Count - 1
            If NBD = HolidayList(i).ToString Then
                NBD = DateAdd(DateInterval.Day, 1, NBD)
                GoTo Retry
            End If
        Next
        GetNextBusinessDay = NBD
        Return GetNextBusinessDay
    End Function

    Public Function AddBusinessDays(ByVal NBD As Date, ByVal DaysToAdd As Integer)
        Dim i, x As Integer

        For x = 0 To DaysToAdd - 1
            NBD = DateAdd(DateInterval.Day, 1, NBD)
            Retry:
            Do While Weekday(NBD) = 1 Or Weekday(NBD) = 7 '''''Exclude weekends''''''
                NBD = DateAdd(DateInterval.Day, 1, NBD)
            Loop
            For i = 0 To HolidayList.Count - 1
                If NBD = HolidayList(i).ToString Then
                    NBD = DateAdd(DateInterval.Day, 1, NBD)
                    GoTo Retry
                End If
            Next
        Next


        AddBusinessDays = NBD
        Return AddBusinessDays
    End Function


    Public Function DaysInMonth(ByVal Mth As Integer) As Integer
        Select Case Mth
            Case 1, 3, 5, 7, 8, 10, 12
                DaysInMonth = 31
            Case 4, 6, 9, 11
                DaysInMonth = 30
            Case 2
                DaysInMonth = 28
        End Select
        Return DaysInMonth
    End Function

    '**** Inserts and fills in steps
    Public Sub AddSteps(ByVal stLoanNumber As String, ByVal stDept As String, ByVal stStepCode As String,
                        ByVal stPredStepCode As String, ByVal stFloatDays As String, ByVal stStepDesc As String)
        Dim sRow As Integer

        If stLoanNumber = "" Then Exit Sub

        sRow = LocateStep(stDept, stLoanNumber, stPredStepCode)
        If DirIsFieldUnprotected(sRow, 2, 1) = False Then Exit Sub
        DirSendKeystrokes(sRow, 2, "A")
        DirEnter()
        sRow = 7
        DirSendKeystrokes(sRow, 20, stStepCode)
        DirSendKeystrokes(sRow, 50, stPredStepCode)
        DirSendKeystrokes(sRow, 54, stFloatDays)
        sRow = sRow + 1
        DirSendKeystrokes(sRow, 12, stStepDesc)
        DirEnter()
        LoanNum = stLoanNumber
    End Sub

    Public Function ChangePredStep(ByVal Dept As String, ByVal stLoannumber As String, ByVal stPredStepCode As String,
                                   ByVal stChangeTo As String)
        Dim sRow As Integer
        Dim loopit, LastTry As Boolean
        ChangePredStep = Nothing
        ActualStepDate = Nothing
        DirClearScreen()
        If stLoannumber = "" Then Exit Function
        Select Case Dept
            Case "BK", "BNK"
                DirShowScreen("BNK3", "", stLoannumber)
                DirWaitForString(1, 32, "BNK TRACKING")
            Case "FC", "FCL"
                DirShowScreen("FOR3", "", (stLoannumber))
                DirWaitForString(1, 32, "FOR TRACKING")
                DirSendKeystrokes(1, 21, stPredStepCode & "@Enter")
            Case "LM", "LMT"
                DirShowScreen("LMT3", "", (stLoannumber))
                DirWaitForString(1, 32, "LMT TRACKING")
            Case "RE", "CLM"
                DirShowScreen("REO3", "", (stLoannumber))
                DirWaitForString(1, 32, "REO TRACKING")
        End Select
        sRow = 6
        Dim i As Integer
        For i = sRow To 23
            'Do Until GetString(sRow, 50, 3) = stPredStepCode
            sRow = sRow + 1
            If DirReadScreen(sRow, 50, 3) = stPredStepCode Then
                DirSendKeystrokes(sRow, 2, "C")
                DirSendKeystrokes(sRow, 50, stChangeTo)
                DirEnter()
                If DirReadScreen(5, 10, 6) = "REASON" Then
                    DirSendKeystrokes(6, 10, "...")
                    DirEnter()
                End If
            End If
            If sRow > 22 Then
                If loopit = True Then
                    If DirReadScreen(22, 6, 1).Trim <> "" And LastTry <> True Then
                        LastTry = True
                        SendKey("@8")
                        sRow = 6
                        i = sRow
                    Else
                        'MsgBox("Step " & stStepCode & " Not Found.")
                        sRow = 0
                        ChangePredStep = 0
                        Exit Function
                    End If
                End If
                SendKey("@8")
                sRow = 6
                i = sRow
                loopit = True
            End If
            If stPredStepCode.Trim = "" Then Exit Function
            'Loop
        Next
        loopit = False
        ChangePredStep = sRow
    End Function


    Public Function LocatePredStep(ByVal Dept As String, ByVal stLoannumber As String, ByVal stStepCode As String)
        Dim sRow As Integer
        Dim loopit As Boolean
        LocatePredStep = Nothing
        ActualStepDate = Nothing
        If stLoannumber = "" Then Exit Function
        DirClearScreen()
        Select Case Dept
            Case "BK", "BNK"
                DirShowScreen("BNK3", "", stLoannumber)
                DirWaitForString(1, 32, "BNK TRACKING")
            Case "FC", "FCL"
                DirShowScreen("FOR3", "", (stLoannumber))
                DirWaitForString(1, 32, "FOR TRACKING")
                DirSendKeystrokes(1, 21, stStepCode & "@Enter")
            Case "LM", "LMT"
                DirShowScreen("LMT3", "", (stLoannumber))
                DirWaitForString(1, 32, "LMT TRACKING")
            Case "RE", "CLM"
                DirShowScreen("REO3", "", (stLoannumber))
                DirWaitForString(1, 32, "REO TRACKING")
        End Select
        sRow = 6

        Do Until GetString(sRow, 50, 3) = stStepCode
            sRow = sRow + 1
            If sRow > 22 Then
                If loopit = True Then
                    'MsgBox("Step " & stStepCode & " Not Found.")
                    sRow = 0
                    LocatePredStep = 0
                    Exit Function
                End If
                SendKey("@8")
                sRow = 6
                loopit = True
            End If
        Loop
        loopit = False
        LocatePredStep = sRow
        If sRow <> 0 Then
            If DirReadScreen(sRow, 13, 6).Trim <> "" Then
                ActualStepDate =
                    CDate(
                        DirReadScreen(sRow, 13, 2).Trim & "/" & DirReadScreen(sRow, 15, 2).Trim & "/" &
                        DirReadScreen(sRow, 17, 2).Trim)
            Else
                ActualStepDate = Nothing
            End If
        End If

        Return LocatePredStep
    End Function

    Public Function LocateStep(ByVal Dept As String, ByVal stLoannumber As String, ByVal stStepCode As String)
        Dim sRow As Integer
        Dim loopit As Boolean
        LocateStep = Nothing
        ActualStepDate = Nothing
        If stLoannumber = "" Then Exit Function
        DirClearScreen()
        Select Case Dept
            Case "BK", "BNK"
                DirShowScreen("BNK3", "", stLoannumber)
                DirWaitForString(1, 32, "BNK TRACKING")
            Case "FC", "FCL"
                DirShowScreen("FOR3", "", (stLoannumber))
                DirWaitForString(1, 32, "FOR TRACKING")
                DirSendKeystrokes(1, 21, stStepCode & "@Enter")
            Case "LM", "LMT"
                DirShowScreen("LMT3", "", (stLoannumber))
                DirWaitForString(1, 32, "LMT TRACKING")
            Case "RE", "CLM"
                DirShowScreen("REO3", "", (stLoannumber))
                DirWaitForString(1, 32, "REO TRACKING")
        End Select
        DirSendKeystrokes(1, 21, stStepCode)
        DirEnter()

        sRow = 6

        Do Until GetString(sRow, 20, 3) = stStepCode
            sRow = sRow + 1
            If sRow > 22 Then
                If loopit = True Then
                    'MsgBox("Step " & stStepCode & " Not Found.")
                    sRow = 0
                    LocateStep = 0
                    Exit Function
                End If
                SendKey("@8")
                sRow = 6
                loopit = True
            End If
        Loop
        loopit = False
        LocateStep = sRow
        If sRow <> 0 Then
            If DirReadScreen(sRow, 13, 6).Trim <> "" Then
                ActualStepDate =
                    CDate(
                        DirReadScreen(sRow, 13, 2).Trim & "/" & DirReadScreen(sRow, 15, 2).Trim & "/" &
                        DirReadScreen(sRow, 17, 2).Trim)
            Else
                ActualStepDate = Nothing
            End If
        End If

        Return LocateStep
    End Function
    '**** Fill step on workstation templates
    Public Sub FillStep(ByVal stStepCode As String, ByVal stStepDate As String, ByVal Dept As String)
        Dim sRow As Integer
        Dim loopit As Boolean
        sRow = 6
        loopit = False
        DirClearScreen()
        Select Case Dept
            Case "BK", "BNK"
                DirShowScreen("BNK3", "", LoanNum)
                DirWaitForString(1, 32, "BNK TRACKING")
            Case "FC", "FCL"
                DirShowScreen("FOR3", "", (LoanNum))
                DirWaitForString(1, 32, "FOR TRACKING")
            Case "LM", "LMT"
                DirShowScreen("LMT3", "", (LoanNum))
                DirWaitForString(1, 32, "LMT TRACKING")
            Case "RE", "CLM"
                DirShowScreen("REO3", "", (LoanNum))
                DirWaitForString(1, 32, "REO TRACKING")

        End Select
        If Dept <> "BK" Then
            DirSendKeystrokes(1, 21, stStepCode)
            DirEnter()
            If DirReadScreen(24, 6, 7).Trim = "INVALID" Then
                IsStepInvaid = True
                Exit Sub
            End If
        End If
        Do Until DirReadScreen(sRow, 20, 3) = stStepCode
            sRow = sRow + 1
            If sRow > 22 Then
                If loopit = True Then
                    'MsgBox("Step " & stStepCode & " Not Updated. Please Update Step to " & stStepDate)
                    Exit Sub
                End If
                DirSendKeystrokes("", "", "@8")
                sRow = 6
                loopit = True
            End If
        Loop
        loopit = False
        DirSendKeystrokes(sRow, 2, "C")
        DirSendKeystrokes(sRow, 13, stStepDate)
        DirSendKeystrokes("", "", "@Enter")
    End Sub


    '**** Clear Actual Date for step on workstation templates
    Public Sub ClearStep(ByVal stStepCode As String, ByVal Dept As String)
        Dim sRow As Integer
        Dim loopit As Boolean
        sRow = 6
        loopit = False
        DirClearScreen()
        Select Case Dept
            Case "BK", "BNK"
                DirShowScreen("BNK3", "", LoanNum)
                DirWaitForString(1, 32, "BNK TRACKING")
            Case "FC", "FCL"
                DirShowScreen("FOR3", "", (LoanNum))
                DirWaitForString(1, 32, "FOR TRACKING")
            Case "LM", "LMT"
                DirShowScreen("LMT3", "", (LoanNum))
                DirWaitForString(1, 32, "LMT TRACKING")
            Case "RE", "CLM"
                DirShowScreen("REO3", "", (LoanNum))
                DirWaitForString(1, 32, "REO TRACKING")

        End Select
        If Dept <> "BK" Then
            DirSendKeystrokes(1, 21, stStepCode)
            DirEnter()
            If DirReadScreen(24, 6, 7).Trim = "INVALID" Then
                IsStepInvaid = True
                Exit Sub
            End If
        End If
        Do Until DirReadScreen(sRow, 20, 3) = stStepCode
            sRow = sRow + 1
            If sRow > 22 Then
                If loopit = True Then
                    'MsgBox("Step " & stStepCode & " Not Updated. Please Update Step to " & stStepDate)
                    Exit Sub
                End If
                DirSendKeystrokes("", "", "@8")
                sRow = 6
                loopit = True
            End If
        Loop
        loopit = False
        DirSendKeystrokes(sRow, 2, "C")
        DirSendKeystrokes(sRow, 13, "      ")
        DirSendKeystrokes("", "", "@Enter")
    End Sub


    Public Sub FillStepFloat(ByVal stStepCode As String, ByVal st3DigFloat As String, ByVal Dept As String)
        Dim sRow As Integer
        Dim loopit As Boolean
        sRow = 6
        loopit = False
        DirClearScreen()
        Select Case Dept
            Case "BK", "BNK"
                DirShowScreen("BNK3", "", LoanNum)
                DirWaitForString(1, 32, "BNK TRACKING")
            Case "FC", "FCL"
                DirShowScreen("FOR3", "", (LoanNum))
                DirWaitForString(1, 32, "FOR TRACKING")
            Case "LM", "LMT"
                DirShowScreen("LMT3", "", (LoanNum))
                DirWaitForString(1, 32, "LMT TRACKING")
            Case "RE", "CLM"
                DirShowScreen("REO3", "", (LoanNum))
                DirWaitForString(1, 32, "REO TRACKING")

        End Select
        Do Until DirReadScreen(sRow, 20, 3) = stStepCode
            sRow = sRow + 1
            If sRow > 22 Then
                If loopit = True Then
                    'MsgBox("Step " & stStepCode & " Not Updated. Please Update Step to " & stStepDate)
                    Exit Sub
                End If
                DirSendKeystrokes("", "", "@8")
                sRow = 6
                loopit = True
            End If
        Loop
        loopit = False
        DirSendKeystrokes(sRow, 2, "C")
        DirSendKeystrokes(sRow, 54, st3DigFloat)
        DirSendKeystrokes("", "", "@Enter")
    End Sub


    '**** Fill scheduled date for step on workstation templates
    Public Sub RollStep(ByVal stStepCode As String, ByVal stStepDate As String, ByVal Dept As String)
        Dim sRow As Integer
        Dim loopit As Boolean
        sRow = 6
        loopit = False
        DirClearScreen()
        DirClearScreen()
        Select Case Dept
            Case "BK", "BNK"
                DirShowScreen("BNK3", "", LoanNum)
                DirWaitForString(1, 32, "BNK TRACKING")
            Case "FC", "FCL"
                DirShowScreen("FOR3", "", (LoanNum))
                DirWaitForString(1, 32, "FOR TRACKING")
            Case "LM", "LMT"
                DirShowScreen("LMT3", "", (LoanNum))
                DirWaitForString(1, 32, "LMT TRACKING")
            Case "RE", "CLM"
                DirShowScreen("REO3", "", (LoanNum))
                DirWaitForString(1, 32, "REO TRACKING")

        End Select
        DirSendKeystrokes(1, 21, stStepCode)
        DirEnter()
        Do Until DirReadScreen(sRow, 20, 3) = stStepCode
            sRow = sRow + 1
            If sRow > 22 Then
                If loopit = True Then
                    Exit Sub
                End If
                DirSendKeystrokes("", "", "@8")
                sRow = 6
                loopit = True
            End If
        Loop
        loopit = False
        DirSendKeystrokes(sRow, 2, "C")
        DirSendKeystrokes(sRow, 6, stStepDate)
        DirSendKeystrokes("", "", "@Enter")
    End Sub


    '**** Delete step on workstation templates
    Public Sub DeleteStep(ByVal stStepCode As String, ByVal stStepDate As String, ByVal Dept As String)
        Dim sRow As Integer
        Dim loopit As Boolean
        sRow = 6
        loopit = False
        DirClearScreen()
        Select Case Dept
            Case "BK", "BNK"
                DirShowScreen("BNK3", "", LoanNum)
                DirWaitForString(1, 32, "BNK TRACKING")
            Case "FC", "FCL"
                DirShowScreen("FOR3", "", (LoanNum))
                DirWaitForString(1, 32, "FOR TRACKING")
            Case "LM", "LMT"
                DirShowScreen("LMT3", "", (LoanNum))
                DirWaitForString(1, 32, "LMT TRACKING")
        End Select
        DirSendKeystrokes(1, 21, stStepCode)
        DirEnter()
        Do Until DirReadScreen(sRow, 20, 3) = stStepCode
            sRow = sRow + 1
            If sRow > 22 Then
                If loopit = True Then
                    'MsgBox("Step " & stStepCode & " Not Updated. Please Update Step to " & stStepDate)
                    Exit Sub
                End If
                DirSendKeystrokes("", "", "@8")
                sRow = 6
                loopit = True
            End If
        Loop
        loopit = False
        DirSendKeystrokes(sRow, 2, "D")
        DirSendKeystrokes(sRow, 13, stStepDate)
        DirSendKeystrokes("", "", "@Enter")
        If DirReadScreen(5, 10, 6) = "REASON" Then
            DirSendKeystrokes(6, 10, "Step Changes")
            DirEnter()
        End If
    End Sub

    Public Function PrevStepsCmplted(ByVal sStepCode As String, ByVal Dept As String) As Boolean
        Dim sRow As Integer
        Dim loopit As Boolean
        sRow = 6
        loopit = False
        Try
            Select Case Dept
                Case "BK", "BNK"
                    DirShowScreen("BNK3", "", LoanNum)
                    DirWaitForString(1, 32, "BNK TRACKING")
                Case "FC", "FCL"
                    DirShowScreen("FOR3", "", (LoanNum))
                    DirWaitForString(1, 32, "FOR TRACKING")
                Case "LM", "LMT"
                    DirShowScreen("LMT3", "", (LoanNum))
                    DirWaitForString(1, 32, "LMT TRACKING")
            End Select
            sRow = 6
            Do Until DirReadScreen(sRow, 20, 3).ToString = sStepCode
                If DirReadScreen(sRow, 13, 6).Trim = "" Then
                    Return False
                End If
                sRow = sRow + 1
                If sRow > 22 Then
                    If loopit = True Then
                        'MsgBox("Step " & stStepCode & " Not Updated. Please Update Step to " & stStepDate)
                        Exit Function
                    End If
                    DirSendKeystrokes("", "", "@8")
                    sRow = 6
                    loopit = True
                End If
            Loop
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Function

    Public Sub ToMemo1(ByRef InsertString As String, ByVal Mdate As String)
        Dim qc As String

        DirShowScreen("MEM1", "", LoanNum)
        again:
        qc = DirReadScreen(8, 58, 3).Trim

        If Len(qc) = 0 Then
            DirSendKeystrokes(8, 23, Mdate)
            DirSendKeystrokes(9, 17, Trim(Left(InsertString, 58)))
            DirSendKeystrokes(10, 17, Trim(Mid(InsertString, 59, 58)))
            DirSendKeystrokes(11, 17, Trim(Mid(InsertString, 117, 58)))
            DirSendKeystrokes(12, 17, Trim(Mid(InsertString, 175, 58)))
            DirSendKeystrokes(13, 17, Trim(Mid(InsertString, 233, 58)))
        Else
            qc = DirReadScreen(16, 58, 3).Trim
            If Len(qc) = 0 Then
                DirSendKeystrokes(16, 23, Mdate)
                DirSendKeystrokes(17, 17, Trim(Left(InsertString, 58)))
                DirSendKeystrokes(18, 17, Trim(Mid(InsertString, 59, 58)))
                DirSendKeystrokes(19, 17, Trim(Mid(InsertString, 117, 58)))
                DirSendKeystrokes(20, 17, Trim(Mid(InsertString, 175, 58)))
                DirSendKeystrokes(21, 17, Trim(Mid(InsertString, 233, 58)))

            Else
                DirSendKeystrokes("", "", "@8")
                GoTo again
            End If
        End If
        DirSendKeystrokes("", "", "@Enter")
    End Sub

    '    Public Sub ToMemo1WLOL(ByRef InsertString As String, ByVal Mdate As String, ByVal LifeOfLoan As String)
    '        Dim qc As String

    '        DirShowScreen("MEM1", "", LoanNum)
    'again:
    '        qc = DirReadScreen(8, 58, 3).Trim

    '        If Len(qc) = 0 Then
    '            DirSendKeystrokes(8, 23, Mdate)
    '            DirSendKeystrokes(9, 17, Trim(Left(InsertString, 58)))
    '            DirSendKeystrokes(10, 17, Trim(Mid(InsertString, 59, 58)))
    '            DirSendKeystrokes(11, 17, Trim(Mid(InsertString, 117, 58)))
    '            DirSendKeystrokes(12, 17, Trim(Mid(InsertString, 175, 58)))
    '            DirSendKeystrokes(13, 17, Trim(Mid(InsertString, 233, 58)))
    '        Else
    '            qc = DirReadScreen(16, 58, 3).Trim
    '            If Len(qc) = 0 Then
    '                DirSendKeystrokes(16, 23, Mdate)
    '                DirSendKeystrokes(17, 17, Trim(Left(InsertString, 58)))
    '                DirSendKeystrokes(18, 17, Trim(Mid(InsertString, 59, 58)))
    '                DirSendKeystrokes(19, 17, Trim(Mid(InsertString, 117, 58)))
    '                DirSendKeystrokes(20, 17, Trim(Mid(InsertString, 175, 58)))
    '                DirSendKeystrokes(21, 17, Trim(Mid(InsertString, 233, 58)))

    '            Else
    '                DirSendKeystrokes("", "", "@8")
    '                GoTo again
    '            End If
    '        End If
    '        DirSendKeystrokes("", "", "@Enter")

    '    End Sub


    Public Sub ScrnNav(ByVal Screen As String, ByVal LoanNumber As String)
        DirShowScreen(Screen, "", LoanNumber)
    End Sub

    Public Sub SubScrnChng(ByRef sString As String)
        On Error Resume Next
        Select Case sString
            Case "ADD1", "ADD2", "APR1", "BDN1", "COL1", "COL2", "NOT1", "SEC1", "SLH1", "USR1", "USR2"
                DirSendKeystrokes(3, 5, sString)
                DirEnter()
            Case "ANA1"
                DirSendKeystrokes(1, 27, sString)
                DirEnter()

            Case Else
                DirSendKeystrokes(1, 21, sString)
                DirEnter()
        End Select
    End Sub
    'Public Sub ReportClick(ByVal ScriptName As String, ByVal Screen As String, ByVal SubScreen As String, ByVal strAction As String)
    '    Try
    '        If TrackClicks = True Then
    '            ''Set Script Start time''''''
    '            DbConnection()
    '            sStart = Today
    '            ''Log Database with user information
    '            sScriptInsert = "INSERT INTO ClickTracker ( Script_Name, User_Name, Screen, Sub_Screen, [Action], DateIn) " _
    '                & "Values ('" & My.Application.Info.AssemblyName & "','" & Trim(User) & "','" & Screen & "','" & SubScreen _
    '                & "','" & strAction & "',#" & sStart & "#);"
    '            WrkConn.Execute(sScriptInsert)
    '            WrkConn.Close()
    '        End If
    '    Catch ex As Exception
    '        MessageBox.Show(ex.Message)
    '    End Try
    'End Sub
End Module

