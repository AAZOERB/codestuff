Public Class frmLogon
    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        DirSendKeystrokes(15, 23, txtftbId.Text.Trim)
        DirSendKeystrokes(16, 23, Me.txtftbPass.Text.Trim)
        DirSendKeystrokes(17, 23, "/snmc/acctg")
        DirSendKeystrokes("", "", "@E")
        If DirReadScreen(3, 2, 8) = "PASSWORD" Then
            MessageBox.Show("Your Password has expired. Please key in your new password then click OK")
        End If
        DirSendKeystrokes("", "", "@3")
        Me.Close()
    End Sub

    Private Sub txtftbId_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles txtftbId.TextChanged
    End Sub

    Private Sub txtftbPass_MaskInputRejected(ByVal sender As System.Object,
                                             ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs)
    End Sub
End Class