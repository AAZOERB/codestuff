Public Class frmNote
    Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
        Dim counter As Integer
        Dim NoteArray() As String
        Stmt = Nothing
        'Create a string array and store the contents of the Lines property.
        NoteArray = txtNotes.Lines

        For counter = 0 To NoteArray.GetUpperBound(0)
            Stmt = Stmt & (NoteArray(counter)).ToString & " "
        Next

        If Len(Trim(Stmt)) = 0 Then
            MessageBox.Show("No notes to send.")
        End If
        Me.Close()
    End Sub
End Class