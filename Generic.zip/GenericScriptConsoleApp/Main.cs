﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenericScriptConsoleApp
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = @"Excel Files |*.xlsx;*.xls";
            openFileDialog.ShowDialog();

            GenericScript.FileName = openFileDialog.FileName;

            lblFileName.Text = openFileDialog.SafeFileName;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(GenericScript.FileName))
            {
                MessageBox.Show(@"Please select a file before attempting to run the script.");
                return;
            }
                
            GenericScript.FileSectionForm.XLBase(GenericScript.FileName,Program.ValidateLoans);
        }
    }
}
