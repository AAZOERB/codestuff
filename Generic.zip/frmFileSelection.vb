
Option Explicit On
'Option Strict On

Imports VB6 = Microsoft.Visualbasic.Compatibility.VB6
Imports VB = Microsoft.Visualbasic
Imports System.IO
Imports SRV_SUP_GENERIC_SCRIPT.Database
Imports SRV_SUP_GENERIC_SCRIPT.Helpers


Public Class frmFileSelction
    Public SaveFileName As String

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        GetAppSettings()
        txtFileLoc.Text = SelectFile("Excel files (*.xls*)|*.XLS*", "Select File to Load.")
        If txtFileLoc.Text.Trim <> "" Then
            btnSubmit.Enabled = True
        End If
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click

        Stmt = txtFileLoc.Text
        btnCancel.Visible = False
        If _
            txtScreen.Text <> Nothing And cboSubmitType.Text <> Nothing Or
            cboSubmitType.Text = Nothing And cboPFKey.Text <> Nothing Then
            '''''Send Script Start Information to Database'''''
            ' LogScriptStart()
            '''''''''''''''''''''''''''''''''''''''''''''''
            ''Run process''
            XLBase(Stmt, False)
            '''''Send Last Run Information to Database'''''
            'LogScriptLastRunSQL()
            '''''''''''''''''''''''''''''''''''''''''''''''

        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub


    Private Sub frmFileSelction_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) _
        Handles Me.FormClosing
        On Error Resume Next
        XLConnClose()
    End Sub


    Private Sub frmFileSelction_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim CL As New ArrayList
        Try
            ''Get the user information and security check'''
            'UserName()
            ''used to avg the count times ran per record
            ''6ReadLCount()
            btnSubmit.Enabled = True
            ''''Load Columns with default info'''''
            CL.Clear()
            CL.Add("Column A")
            CL.Add("Column B")
            CL.Add("Column C")
            CL.Add("Column D")
            CL.Add("Column E")
            CL.Add("Column F")
            CL.Add("Column G")
            CL.Add("Column H")
            CL.Add("Column I")
            CL.Add("Column J")
            CL.Add("Column K")
            CL.Add("Column L")
            CL.Add("Column M")
            CL.Add("Column N")
            CL.Add("Column O")
            CL.Add("Column P")
            CL.Add("Column Q")
            CL.Add("Column R")
            CL.Add("Column S")
            CL.Add("Column T")
            CL.Add("Column U")
            CL.Add("Column V")
            CL.Add("Column W")
            CL.Add("Column X")
            CL.Add("Column Y")
            CL.Add("Column Z")
            cboSrc1.Items.AddRange(CL.ToArray)
            cboSrc2.Items.AddRange(CL.ToArray)
            cboSrc3.Items.AddRange(CL.ToArray)
            cboSrc4.Items.AddRange(CL.ToArray)
            cboSrc5.Items.AddRange(CL.ToArray)
            cboSrc6.Items.AddRange(CL.ToArray)
            cboSrc7.Items.AddRange(CL.ToArray)
            cboSrc8.Items.AddRange(CL.ToArray)
            cboSrc9.Items.AddRange(CL.ToArray)
            cboSrc10.Items.AddRange(CL.ToArray)
            cboSrc11.Items.AddRange(CL.ToArray)
            cboSrc12.Items.AddRange(CL.ToArray)
            cboSrc13.Items.AddRange(CL.ToArray)
            cboSrc14.Items.AddRange(CL.ToArray)
            cboSrc15.Items.AddRange(CL.ToArray)
            cboSrc16.Items.AddRange(CL.ToArray)
            cboSrc17.Items.AddRange(CL.ToArray)
            cboSrc18.Items.AddRange(CL.ToArray)
            cboSrc19.Items.AddRange(CL.ToArray)
            cboSrc20.Items.AddRange(CL.ToArray)
            cboSrc21.Items.AddRange(CL.ToArray)
            cboSrc22.Items.AddRange(CL.ToArray)
            cboSrc23.Items.AddRange(CL.ToArray)
            cboSrc24.Items.AddRange(CL.ToArray)
            cboSrc25.Items.AddRange(CL.ToArray)
            cboSrc26.Items.AddRange(CL.ToArray)
            cboLoanNumber.Items.Add("NONE")
            cboLoanNumber.Items.AddRange(CL.ToArray)
            cboLoanNumber.Text = Nothing
            cboSSrc1.Items.AddRange(CL.ToArray)
            cboSSrc2.Items.AddRange(CL.ToArray)
            cboSPFKey.Text = "NONE"
            cboPFKey.Text = "NONE"
            cboSubmitType.Text = "Submit"
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Public Sub XLBase(ByVal strExcelFileName As String, ByVal validateLoans As Boolean)
        Dim Erow, Ecol, Lcount, Tcount As Integer
        Dim Test1 As Boolean
        Try
            'Dim tmp As String
            WrkConnXL(strExcelFileName, 1) ''open selected file
            Erow = 2
            Ecol = 1
            Lcount = 1
            Tcount = 1
            Test1 = False
            objExcel.visible = True
            GetAppSettings()
            DirSessionConnect()
            Do Until Trim(CStr(objXlSht.cells(Erow, Ecol).value)) = ""
                'If CStr(objXlSht.cells(Erow, Ecol + 50).Value) = "" Then

                DirClearScreen()
                If cboLoanNumber.Text = "NONE" Then
                    DirSendKeystrokes(1, 1, UCase(txtScreen.Text.Trim))
                    If txtSrow1.Text <> Nothing Then
                        DirSendKeystrokes(txtSrow1.Text, txtSCol1.Text, TmpBuff(CType(Int(txtSLngth1.Text), Integer)))
                        DirSendKeystrokes(txtSrow1.Text, txtSCol1.Text,
                                          CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSSrc1.Text, 1)) - 65) + 1).value, String))
                    End If
                    If txtSrow2.Text <> Nothing Then
                        DirSendKeystrokes(txtSrow2.Text, txtSCol2.Text, TmpBuff(CType(Int(txtSLngth2.Text), Integer)))
                        DirSendKeystrokes(txtSrow2.Text, txtSCol2.Text,
                                          CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSSrc2.Text, 1)) - 65) + 1).value, String))
                    End If
                    DirEnter()
                    If cboSPFKey.Text <> "NONE" Then SendKey("@" & cboSPFKey.Text)
                Else
                    LoanNum = CType(objXlSht.cells(Erow, 1).value, String)

                    If (validateLoans) Then
                        Dim result As Boolean = LoanNumberValidation(CInt(LoanNum))

                        If result = False Then

                            objXlSht.cells(Erow, Ecol + 50).Value = "Invalid Loan Number"
                            Erow = Erow + 1
                            Continue Do
                        End If

                    End If

                    DirShowScreen(Trim(txtScreen.Text), Trim(txtSubWindow.Text), LoanNum)


                End If
                '    End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


                If txtRow1.Text <> Nothing Then
                    DirSendKeystrokes(txtRow1.Text, txtCol1.Text, TmpBuff(CType(Int(txtLngth1.Text), Integer)))
                    DirSendKeystrokes(txtRow1.Text, txtCol1.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc1.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow2.Text <> Nothing Then
                    DirSendKeystrokes(txtRow2.Text, txtCol2.Text, TmpBuff(CType(Int(txtLngth2.Text), Integer)))
                    DirSendKeystrokes(txtRow2.Text, txtCol2.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc2.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow3.Text <> Nothing Then
                    DirSendKeystrokes(txtRow3.Text, txtCol3.Text, TmpBuff(CType(Int(txtLngth3.Text), Integer)))
                    DirSendKeystrokes(txtRow3.Text, txtCol3.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc3.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow4.Text <> Nothing Then
                    DirSendKeystrokes(txtRow4.Text, txtCol4.Text, TmpBuff(CType(Int(txtLngth4.Text), Integer)))
                    DirSendKeystrokes(txtRow4.Text, txtCol4.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc4.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow5.Text <> Nothing Then
                    DirSendKeystrokes(txtRow5.Text, txtCol5.Text, TmpBuff(CType(Int(txtLngth5.Text), Integer)))
                    DirSendKeystrokes(txtRow5.Text, txtCol5.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc5.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow6.Text <> Nothing Then
                    DirSendKeystrokes(txtRow6.Text, txtCol6.Text, TmpBuff(CType(Int(txtLngth6.Text), Integer)))
                    DirSendKeystrokes(txtRow6.Text, txtCol6.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc6.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow7.Text <> Nothing Then
                    DirSendKeystrokes(txtRow7.Text, txtCol7.Text, TmpBuff(CType(Int(txtLngth7.Text), Integer)))
                    DirSendKeystrokes(txtRow7.Text, txtCol7.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc7.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow8.Text <> Nothing Then
                    DirSendKeystrokes(txtRow8.Text, txtCol8.Text, TmpBuff(CType(Int(txtLngth8.Text), Integer)))
                    DirSendKeystrokes(txtRow8.Text, txtCol8.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc8.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow9.Text <> Nothing Then
                    DirSendKeystrokes(txtRow9.Text, txtCol9.Text, TmpBuff(CType(Int(txtLngth9.Text), Integer)))
                    DirSendKeystrokes(txtRow9.Text, txtCol9.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc9.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow10.Text <> Nothing Then
                    DirSendKeystrokes(txtRow10.Text, txtCol10.Text, TmpBuff(CType(Int(txtLngth10.Text), Integer)))
                    DirSendKeystrokes(txtRow10.Text, txtCol10.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc10.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow11.Text <> Nothing Then
                    DirSendKeystrokes(txtRow11.Text, txtCol11.Text, TmpBuff(CType(Int(txtLngth11.Text), Integer)))
                    DirSendKeystrokes(txtRow11.Text, txtCol11.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc11.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow12.Text <> Nothing Then
                    DirSendKeystrokes(txtRow12.Text, txtCol12.Text, TmpBuff(CType(Int(txtLngth12.Text), Integer)))
                    DirSendKeystrokes(txtRow12.Text, txtCol12.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc12.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow13.Text <> Nothing Then
                    DirSendKeystrokes(txtRow13.Text, txtCol13.Text, TmpBuff(CType(Int(txtLngth13.Text), Integer)))
                    DirSendKeystrokes(txtRow13.Text, txtCol13.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc13.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow14.Text <> Nothing Then
                    DirSendKeystrokes(txtRow14.Text, txtCol14.Text, TmpBuff(CType(Int(txtLngth14.Text), Integer)))
                    DirSendKeystrokes(txtRow14.Text, txtCol14.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc14.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow15.Text <> Nothing Then
                    DirSendKeystrokes(txtRow15.Text, txtCol15.Text, TmpBuff(CType(Int(txtLngth15.Text), Integer)))
                    DirSendKeystrokes(txtRow15.Text, txtCol15.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc15.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow16.Text <> Nothing Then
                    DirSendKeystrokes(txtRow16.Text, txtCol16.Text, TmpBuff(CType(Int(txtLngth16.Text), Integer)))
                    DirSendKeystrokes(txtRow16.Text, txtCol16.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc16.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow17.Text <> Nothing Then
                    DirSendKeystrokes(txtRow17.Text, txtCol17.Text, TmpBuff(CType(Int(txtLngth17.Text), Integer)))
                    DirSendKeystrokes(txtRow17.Text, txtCol17.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc17.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow18.Text <> Nothing Then
                    DirSendKeystrokes(txtRow18.Text, txtCol18.Text, TmpBuff(CType(Int(txtLngth18.Text), Integer)))
                    DirSendKeystrokes(txtRow18.Text, txtCol18.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc18.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow19.Text <> Nothing Then
                    DirSendKeystrokes(txtRow19.Text, txtCol19.Text, TmpBuff(CType(Int(txtLngth19.Text), Integer)))
                    DirSendKeystrokes(txtRow19.Text, txtCol19.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc19.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow20.Text <> Nothing Then
                    DirSendKeystrokes(txtRow20.Text, txtCol20.Text, TmpBuff(CType(Int(txtLngth20.Text), Integer)))
                    DirSendKeystrokes(txtRow20.Text, txtCol20.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc20.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow21.Text <> Nothing Then
                    DirSendKeystrokes(txtRow21.Text, txtCol21.Text, TmpBuff(CType(Int(txtLngth21.Text), Integer)))
                    DirSendKeystrokes(txtRow21.Text, txtCol21.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc21.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow22.Text <> Nothing Then
                    DirSendKeystrokes(txtRow22.Text, txtCol22.Text, TmpBuff(CType(Int(txtLngth22.Text), Integer)))
                    DirSendKeystrokes(txtRow22.Text, txtCol22.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc22.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow23.Text <> Nothing Then
                    DirSendKeystrokes(txtRow23.Text, txtCol23.Text, TmpBuff(CType(Int(txtLngth23.Text), Integer)))
                    DirSendKeystrokes(txtRow23.Text, txtCol23.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc23.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow24.Text <> Nothing Then
                    DirSendKeystrokes(txtRow24.Text, txtCol24.Text, TmpBuff(CType(Int(txtLngth24.Text), Integer)))
                    DirSendKeystrokes(txtRow24.Text, txtCol24.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc24.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow25.Text <> Nothing Then
                    DirSendKeystrokes(txtRow25.Text, txtCol25.Text, TmpBuff(CType(Int(txtLngth25.Text), Integer)))
                    DirSendKeystrokes(txtRow25.Text, txtCol25.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc25.Text, 1)) - 65) + 1).value, String))
                End If
                If txtRow26.Text <> Nothing Then
                    DirSendKeystrokes(txtRow26.Text, txtCol26.Text, TmpBuff(CType(Int(txtLngth26.Text), Integer)))
                    DirSendKeystrokes(txtRow26.Text, txtCol26.Text,
                                      CType(objXlSht.cells(Erow, (Asc(VB.Right(cboSrc26.Text, 1)) - 65) + 1).value, String))
                End If

                Dim i As Integer
                If cboSubmitType.Text = "Type:" Then cboSubmitType.Text = "Submit"
                If cboSubmitType.Text = "Submit" Then
                    For i = 0 To Int(txtTimesEnter.Text) - 1
                        DirEnter()
                    Next
                Else
                    For i = 0 To Int(txtTimesToSubmit.Text) - 1
                        SendKey("@" & cboPFKey.Text)
                    Next
                End If

                objXlSht.cells(Erow, Ecol + 50).Value = CStr(CStr(Today) + " " + TimeOfDay)
                'objExcelWrkBk.save()


                Erow = Erow + 1
                Ecol = 1
                Lcount = Lcount + 1
                Tcount = Tcount + 1
                'If Lcount = RLC Then
                '    '''''Send Last Run Information to Database'''''
                '    'LogScriptLastRunNoMsgSQL()
                '    '''''''''''''''''''''''''''''''''''''''''''''''
                '    '''''Send Script Start Information to Database'''''
                '    'LogScriptStart()
                '    ''''''''''''''''''''''''''''''''''''''''''''''
                '    Lcount = 1
                'End If
                'LoanNum = objXlSht.cells(Erow, Int(66 - (Asc(VB.Right(cboLoanNumber.Text, 1))))).value
                'DirShowScreen(txtScreen.Text.Trim, "", LoanNum)
                'DirClearScreen()
                If Test1 = False Then
                    Test1 = True
                    If _
                        MessageBox.Show("Did the first record process correctly?", "PROCESS VALIDATION",
                                        MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.No Then
                        MessageBox.Show("Please make the necessary corrections and restart the script.")
                        Exit Sub
                    End If
                End If
            Loop
            MessageBox.Show("You Processed " & Tcount - 1 & " Loans. Completion time " & Now)
            XLConnClose()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub


    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        sdlgFile.AddExtension = True
        sdlgFile.Filter = "Text files (*.txt)|*.TXT|Text files (*.txt)|*.TXT"
        If Me.sdlgFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            SaveFileName = sdlgFile.FileName
            CreateFile()
        End If
    End Sub

    ' This subrouting uses a StreamWriter object to create a new file
    '   and fill it with the text in txtFileText. It first checks to see
    '   if the file already exists and prompts to overwrite it.

    Public Sub CreateFile()
        Dim strTextFile As String

        ' Check to see if the user is writing over an existing file.
        If File.Exists(SaveFileName) Then
            If MsgBox("That file exists. Would you like to overwrite it?",
                      MsgBoxStyle.YesNo) <> MsgBoxResult.Yes Then
                ' Leave the subroutine
                Return
            End If
        End If

        Dim myStreamWriter As StreamWriter
        Try
            ' Create a StreamWriter using a Shared (static) File class.
            myStreamWriter = File.CreateText(SaveFileName)

            ' Write the entire contents of the txtFileText text box
            '   to the StreamWriter in one shot.

            strTextFile = "Screen Name: " & UCase(txtScreen.Text)
            strTextFile = strTextFile + vbCrLf + "Loan Src:" & cboLoanNumber.Text
            If txtRow1.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow1.Text, "00") & " Col:" &
                              VB6.Format(txtCol1.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth1.Text, "00") & " SrcColumn:" & cboSrc1.Text
            End If
            If txtRow2.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow2.Text, "00") & " Col:" &
                              VB6.Format(txtCol2.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth2.Text, "00") & " SrcColumn:" & cboSrc2.Text
            End If
            If txtRow3.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow3.Text, "00") & " Col:" &
                              VB6.Format(txtCol3.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth3.Text, "00") & " SrcColumn:" & cboSrc3.Text
            End If
            If txtRow4.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow4.Text, "00") & " Col:" &
                              VB6.Format(txtCol4.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth4.Text, "00") & " SrcColumn:" & cboSrc4.Text
            End If
            If txtRow5.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow5.Text, "00") & " Col:" &
                              VB6.Format(txtCol5.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth5.Text, "00") & " SrcColumn:" & cboSrc5.Text
            End If
            If txtRow6.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow6.Text, "00") & " Col:" &
                              VB6.Format(txtCol6.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth6.Text, "00") & " SrcColumn:" & cboSrc6.Text
            End If
            If txtRow7.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow7.Text, "00") & " Col:" &
                              VB6.Format(txtCol7.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth7.Text, "00") & " SrcColumn:" & cboSrc7.Text
            End If
            If txtRow8.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow8.Text, "00") & " Col:" &
                              VB6.Format(txtCol8.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth8.Text, "00") & " SrcColumn:" & cboSrc8.Text
            End If
            If txtRow9.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow9.Text, "00") & " Col:" &
                              VB6.Format(txtCol9.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth9.Text, "00") & " SrcColumn:" & cboSrc9.Text
            End If
            If txtRow10.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow10.Text, "00") & " Col:" &
                              VB6.Format(txtCol10.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth10.Text, "00") & " SrcColumn:" & cboSrc10.Text
            End If
            If txtRow11.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow11.Text, "00") & " Col:" &
                              VB6.Format(txtCol11.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth11.Text, "00") & " SrcColumn:" & cboSrc11.Text
            End If
            If txtRow12.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow12.Text, "00") & " Col:" &
                              VB6.Format(txtCol12.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth12.Text, "00") & " SrcColumn:" & cboSrc12.Text
            End If
            strTextFile = strTextFile + vbCrLf + "Submit Type:" & cboSubmitType.Text
            strTextFile = strTextFile + vbCrLf + "PF Key:" & cboPFKey.Text
            strTextFile = strTextFile + vbCrLf + "PF Times:" & txtTimesToSubmit.Text
            strTextFile = strTextFile + vbCrLf + "Enter Times:" & txtTimesEnter.Text

            If txtSrow1.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtSrow1.Text, "00") & " Col:" &
                              VB6.Format(txtSCol1.Text, "00") _
                              & " Lngth:" & VB6.Format(txtSLngth1.Text, "00") & " SrcColumn:" & cboSSrc1.Text
            End If
            If txtSrow2.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtSrow2.Text, "00") & " Col:" &
                              VB6.Format(txtSCol2.Text, "00") _
                              & " Lngth:" & VB6.Format(txtSLngth2.Text, "00") & " SrcColumn:" & cboSSrc2.Text
            End If
            strTextFile = strTextFile + vbCrLf + "PF Key:" & cboSPFKey.Text
            strTextFile = strTextFile + vbCrLf + "Sub Window:" & txtSubWindow.Text

            If txtRow13.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow13.Text, "00") & " Col:" &
                              VB6.Format(txtCol13.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth13.Text, "00") & " SrcColumn:" & cboSrc13.Text

            End If
            If txtRow14.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow14.Text, "00") & " Col:" &
                              VB6.Format(txtCol14.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth14.Text, "00") & " SrcColumn:" & cboSrc14.Text

            End If
            If txtRow15.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow15.Text, "00") & " Col:" &
                              VB6.Format(txtCol15.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth15.Text, "00") & " SrcColumn:" & cboSrc15.Text

            End If
            If txtRow16.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow16.Text, "00") & " Col:" &
                              VB6.Format(txtCol16.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth16.Text, "00") & " SrcColumn:" & cboSrc16.Text

            End If
            If txtRow17.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow17.Text, "00") & " Col:" &
                              VB6.Format(txtCol17.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth17.Text, "00") & " SrcColumn:" & cboSrc17.Text

            End If
            If txtRow18.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow18.Text, "00") & " Col:" &
                              VB6.Format(txtCol18.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth18.Text, "00") & " SrcColumn:" & cboSrc18.Text

            End If
            If txtRow19.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow19.Text, "00") & " Col:" &
                              VB6.Format(txtCol19.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth19.Text, "00") & " SrcColumn:" & cboSrc19.Text

            End If
            If txtRow20.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow20.Text, "00") & " Col:" &
                              VB6.Format(txtCol20.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth20.Text, "00") & " SrcColumn:" & cboSrc20.Text

            End If
            If txtRow21.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow21.Text, "00") & " Col:" &
                              VB6.Format(txtCol21.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth21.Text, "00") & " SrcColumn:" & cboSrc21.Text

            End If
            If txtRow22.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow22.Text, "00") & " Col:" &
                              VB6.Format(txtCol22.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth22.Text, "00") & " SrcColumn:" & cboSrc22.Text

            End If
            If txtRow23.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow23.Text, "00") & " Col:" &
                              VB6.Format(txtCol23.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth23.Text, "00") & " SrcColumn:" & cboSrc23.Text

            End If
            If txtRow24.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow24.Text, "00") & " Col:" &
                              VB6.Format(txtCol24.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth24.Text, "00") & " SrcColumn:" & cboSrc24.Text

            End If
            If txtRow25.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow25.Text, "00") & " Col:" &
                              VB6.Format(txtCol25.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth25.Text, "00") & " SrcColumn:" & cboSrc25.Text

            End If
            If txtRow26.Text <> Nothing Then
                strTextFile = strTextFile + vbCrLf + "Row:" & VB6.Format(txtRow26.Text, "00") & " Col:" &
                              VB6.Format(txtCol26.Text, "00") _
                              & " Lngth:" & VB6.Format(txtLngth26.Text, "00") & " SrcColumn:" & cboSrc26.Text

            End If

            myStreamWriter.Write(strTextFile)
            myStreamWriter.Flush()
        Catch exc As Exception
            ' Show the error to the user.
            MsgBox("File could not be created or written to." + vbCrLf +
                   "Please verify that the filename is correct, " +
                   "and that you have write permissions for the desired " +
                   "directory." + vbCrLf + vbCrLf + "Exception: " + exc.Message)
        Finally
            ' Close the object if it has been created.
            If Not myStreamWriter Is Nothing Then
                myStreamWriter.Close()
            End If
        End Try
    End Sub


    Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
        
        Try
            btnReset_Click(sender, e)
            Dim fdlg As OpenFileDialog = New OpenFileDialog()
            fdlg.Title = "Load File"
            'fdlg.InitialDirectory = My.Application.Info.DirectoryPath
            fdlg.Filter = "Text files (*.txt)|*.TXT|Text files (*.txt)|*.TXT"
            fdlg.FilterIndex = 2
            fdlg.RestoreDirectory = True
            fdlg.ShowDialog()

            LoadConfigurationFile(fdlg.FileName)
            
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click

        'Set an integer to loop through the controls
        Dim x As Integer
        For x = 0 To Me.Controls.Count - 1
            'if it is a text box then clear it 
            Debug.Print(Me.Controls.Item(x).Name)
            If TypeOf Me.Controls.Item(x) Is TextBox Then
                Me.Controls.Item(x).Text = Nothing
            End If
            'if it is a Combo box then clear it 
            If TypeOf Me.Controls.Item(x) Is ComboBox Then
                Me.Controls.Item(x).Text = Nothing
            End If

        Next
        For x = 0 To Me.TabPage1.Controls.Count - 1
            'if it is a text box then clear it 
            Debug.Print(Me.TabPage1.Controls.Item(x).Name)
            If TypeOf Me.TabPage1.Controls.Item(x) Is TextBox Then
                Me.TabPage1.Controls.Item(x).Text = Nothing
            End If
            'if it is a Combo box then clear it 
            If TypeOf Me.TabPage1.Controls.Item(x) Is ComboBox Then
                Me.TabPage1.Controls.Item(x).Text = Nothing
            End If
        Next
        For x = 0 To Me.TabPage2.Controls.Count - 1
            'if it is a text box then clear it 
            Debug.Print(Me.TabPage2.Controls.Item(x).Name)
            If TypeOf Me.TabPage2.Controls.Item(x) Is TextBox Then
                Me.TabPage2.Controls.Item(x).Text = Nothing
            End If
            'if it is a Combo box then clear it 
            If TypeOf Me.TabPage2.Controls.Item(x) Is ComboBox Then
                Me.TabPage2.Controls.Item(x).Text = Nothing
            End If
        Next
        txtTimesEnter.Text = 1
        txtTimesToSubmit.Text = 1
        cboSubmitType.Text = "Submit"
        cboSPFKey.Text = "NONE"
        cboPFKey.Text = "NONE"
        'txtSubWindow.Text = Nothing
    End Sub

    Public Function TmpBuff(ByVal Length As Integer) As String
        Dim i As Integer
        TmpBuff = Nothing
        For i = 0 To Length - 1
            TmpBuff = TmpBuff & " "
        Next
        Return TmpBuff
    End Function

    Private Sub btnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelp.Click
        Dim Proc As New System.Diagnostics.Process
        Proc.StartInfo.WorkingDirectory = My.Application.Info.DirectoryPath & "\"
        Proc.StartInfo.FileName = "Help.doc"
        Proc.Start()
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Private Sub cboLoanNumber_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) _
        Handles cboLoanNumber.SelectedValueChanged
        If cboLoanNumber.Text = "NONE" Then
            GroupBox1.Visible = True
        Else
            GroupBox1.Visible = False
        End If
    End Sub

    Private Sub cboSrc13_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSrc13.LostFocus
        TabControl1.SelectTab(1)
        txtRow14.Focus()
    End Sub

    Private Sub txtCol1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol1.GotFocus
        txtCol1.SelectAll()
    End Sub

    Private Sub txtLngth1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth1.GotFocus
        txtLngth1.SelectAll()
    End Sub

    Private Sub txtRow1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow1.GotFocus
        txtRow1.SelectAll()
    End Sub

    Private Sub txtCol2_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol2.GotFocus
        txtCol2.SelectAll()
    End Sub

    Private Sub txtLngth2_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth2.GotFocus
        txtLngth2.SelectAll()
    End Sub

    Private Sub txtRow2_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow2.GotFocus
        txtRow2.SelectAll()
    End Sub

    Private Sub txtCol3_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol3.GotFocus
        txtCol3.SelectAll()
    End Sub

    Private Sub txtLngth3_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth3.GotFocus
        txtLngth3.SelectAll()
    End Sub

    Private Sub txtRow3_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow3.GotFocus
        txtRow3.SelectAll()
    End Sub

    Private Sub txtCol4_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol4.GotFocus
        txtCol4.SelectAll()
    End Sub

    Private Sub txtLngth4_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth4.GotFocus
        txtLngth4.SelectAll()
    End Sub

    Private Sub txtRow4_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow4.GotFocus
        txtRow4.SelectAll()
    End Sub

    Private Sub txtCol5_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol5.GotFocus
        txtCol5.SelectAll()
    End Sub

    Private Sub txtLngth5_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth5.GotFocus
        txtLngth5.SelectAll()
    End Sub

    Private Sub txtRow5_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow5.GotFocus
        txtRow5.SelectAll()
    End Sub

    Private Sub txtCol6_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol6.GotFocus
        txtCol6.SelectAll()
    End Sub

    Private Sub txtLngth6_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth6.GotFocus
        txtLngth6.SelectAll()
    End Sub

    Private Sub txtRow6_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow6.GotFocus
        txtRow6.SelectAll()
    End Sub

    Private Sub txtCol7_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol7.GotFocus
        txtCol7.SelectAll()
    End Sub

    Private Sub txtLngth7_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth7.GotFocus
        txtLngth7.SelectAll()
    End Sub

    Private Sub txtRow7_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow7.GotFocus
        txtRow7.SelectAll()
    End Sub

    Private Sub txtCol8_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol8.GotFocus
        txtCol8.SelectAll()
    End Sub

    Private Sub txtLngth8_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth8.GotFocus
        txtLngth8.SelectAll()
    End Sub

    Private Sub txtRow8_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow8.GotFocus
        txtRow8.SelectAll()
    End Sub

    Private Sub txtCol9_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol9.GotFocus
        txtCol9.SelectAll()
    End Sub

    Private Sub txtLngth9_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth9.GotFocus
        txtLngth9.SelectAll()
    End Sub

    Private Sub txtRow9_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow9.GotFocus
        txtRow9.SelectAll()
    End Sub

    Private Sub txtCol10_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol10.GotFocus
        txtCol10.SelectAll()
    End Sub

    Private Sub txtLngth10_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth10.GotFocus
        txtLngth10.SelectAll()
    End Sub

    Private Sub txtRow10_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow10.GotFocus
        txtRow10.SelectAll()
    End Sub

    Private Sub txtCol11_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol11.GotFocus
        txtCol11.SelectAll()
    End Sub

    Private Sub txtLngth11_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth11.GotFocus
        txtLngth11.SelectAll()
    End Sub

    Private Sub txtRow11_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow11.GotFocus
        txtRow11.SelectAll()
    End Sub

    Private Sub txtCol12_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol12.GotFocus
        txtCol12.SelectAll()
    End Sub

    Private Sub txtLngth12_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth12.GotFocus
        txtLngth12.SelectAll()
    End Sub

    Private Sub txtRow12_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow12.GotFocus
        txtRow12.SelectAll()
    End Sub

    Private Sub txtCol13_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol13.GotFocus
        txtCol13.SelectAll()
    End Sub

    Private Sub txtLngth13_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth13.GotFocus
        txtLngth13.SelectAll()
    End Sub

    Private Sub txtRow13_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow13.GotFocus
        txtRow13.SelectAll()
    End Sub

    Private Sub txtCol14_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol14.GotFocus
        txtCol14.SelectAll()
    End Sub

    Private Sub txtLngth14_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth14.GotFocus
        txtLngth14.SelectAll()
    End Sub

    Private Sub txtRow14_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow14.GotFocus
        txtRow14.SelectAll()
    End Sub

    Private Sub txtCol15_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol15.GotFocus
        txtCol15.SelectAll()
    End Sub

    Private Sub txtLngth15_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth15.GotFocus
        txtLngth15.SelectAll()
    End Sub

    Private Sub txtRow15_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow15.GotFocus
        txtRow15.SelectAll()
    End Sub

    Private Sub txtCol16_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol16.GotFocus
        txtCol16.SelectAll()
    End Sub

    Private Sub txtLngth16_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth16.GotFocus
        txtLngth16.SelectAll()
    End Sub

    Private Sub txtRow16_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow16.GotFocus
        txtRow16.SelectAll()
    End Sub

    Private Sub txtCol17_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol17.GotFocus
        txtCol17.SelectAll()
    End Sub

    Private Sub txtLngth17_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth17.GotFocus
        txtLngth17.SelectAll()
    End Sub

    Private Sub txtRow17_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow17.GotFocus
        txtRow17.SelectAll()
    End Sub

    Private Sub txtCol18_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol18.GotFocus
        txtCol18.SelectAll()
    End Sub

    Private Sub txtLngth18_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth18.GotFocus
        txtLngth18.SelectAll()
    End Sub

    Private Sub txtRow18_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow18.GotFocus
        txtRow18.SelectAll()
    End Sub

    Private Sub txtCol19_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol19.GotFocus
        txtCol19.SelectAll()
    End Sub

    Private Sub txtLngth19_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth19.GotFocus
        txtLngth19.SelectAll()
    End Sub

    Private Sub txtRow19_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow19.GotFocus
        txtRow19.SelectAll()
    End Sub

    Private Sub txtCol20_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol20.GotFocus
        txtCol20.SelectAll()
    End Sub

    Private Sub txtLngth20_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth20.GotFocus
        txtLngth20.SelectAll()
    End Sub

    Private Sub txtRow20_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow20.GotFocus
        txtRow20.SelectAll()
    End Sub

    Private Sub txtCol21_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol21.GotFocus
        txtCol21.SelectAll()
    End Sub

    Private Sub txtLngth21_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth21.GotFocus
        txtLngth21.SelectAll()
    End Sub

    Private Sub txtRow21_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow21.GotFocus
        txtRow21.SelectAll()
    End Sub

    Private Sub txtCol22_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol22.GotFocus
        txtCol22.SelectAll()
    End Sub

    Private Sub txtLngth22_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth22.GotFocus
        txtLngth22.SelectAll()
    End Sub

    Private Sub txtRow22_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow22.GotFocus
        txtRow22.SelectAll()
    End Sub

    Private Sub txtCol23_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol23.GotFocus
        txtCol23.SelectAll()
    End Sub

    Private Sub txtLngth23_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth23.GotFocus
        txtLngth23.SelectAll()
    End Sub

    Private Sub txtRow23_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow23.GotFocus
        txtRow23.SelectAll()
    End Sub

    Private Sub txtCol24_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol24.GotFocus
        txtCol24.SelectAll()
    End Sub

    Private Sub txtLngth24_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth24.GotFocus
        txtLngth24.SelectAll()
    End Sub

    Private Sub txtRow24_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow24.GotFocus
        txtRow24.SelectAll()
    End Sub

    Private Sub txtCol25_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol25.GotFocus
        txtCol25.SelectAll()
    End Sub

    Private Sub txtLngth25_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth25.GotFocus
        txtLngth25.SelectAll()
    End Sub

    Private Sub txtRow25_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow25.GotFocus
        txtRow25.SelectAll()
    End Sub

    Private Sub txtCol26_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCol26.GotFocus
        txtCol26.SelectAll()
    End Sub

    Private Sub txtLngth26_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLngth26.GotFocus
        txtLngth26.SelectAll()
    End Sub

    Private Sub txtRow26_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRow26.GotFocus
        txtRow26.SelectAll()
    End Sub


    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
    End Sub

    Public Sub LoadConfigurationFile(fileName As String)
        Dim fileReader As System.IO.StreamReader
        Dim TR As String
        Dim r, c, l As Integer
        Try

            TR = " "
            fileReader =
                My.Computer.FileSystem.OpenTextFileReader(fileName)
            r = 5
            c = 12
            l = 21

            TR = fileReader.ReadLine
            txtScreen.Text = VB.Right(TR, 4).ToString
            TR = fileReader.ReadLine
            cboLoanNumber.Text = VB.Right(TR, VB.Len(TR) - 9).Trim.ToString
            TR = fileReader.ReadLine
            If VB.Left(TR, 3) = "Row" Then
                txtRow1.Text = Mid(TR, r, 2)
                txtCol1.Text = Mid(TR, c, 2)
                txtLngth1.Text = Mid(TR, l, 2)
                cboSrc1.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow2.Text = Mid(TR, r, 2)
                txtCol2.Text = Mid(TR, c, 2)
                txtLngth2.Text = Mid(TR, l, 2)
                cboSrc2.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow3.Text = Mid(TR, r, 2)
                txtCol3.Text = Mid(TR, c, 2)
                txtLngth3.Text = Mid(TR, l, 2)
                cboSrc3.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow4.Text = Mid(TR, r, 2)
                txtCol4.Text = Mid(TR, c, 2)
                txtLngth4.Text = Mid(TR, l, 2)
                cboSrc4.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow5.Text = Mid(TR, r, 2)
                txtCol5.Text = Mid(TR, c, 2)
                txtLngth5.Text = Mid(TR, l, 2)
                cboSrc5.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow6.Text = Mid(TR, r, 2)
                txtCol6.Text = Mid(TR, c, 2)
                txtLngth6.Text = Mid(TR, l, 2)
                cboSrc6.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow7.Text = Mid(TR, r, 2)
                txtCol7.Text = Mid(TR, c, 2)
                txtLngth7.Text = Mid(TR, l, 2)
                cboSrc7.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow8.Text = Mid(TR, r, 2)
                txtCol8.Text = Mid(TR, c, 2)
                txtLngth8.Text = Mid(TR, l, 2)
                cboSrc8.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow9.Text = Mid(TR, r, 2)
                txtCol9.Text = Mid(TR, c, 2)
                txtLngth9.Text = Mid(TR, l, 2)
                cboSrc9.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow10.Text = Mid(TR, r, 2)
                txtCol10.Text = Mid(TR, c, 2)
                txtLngth10.Text = Mid(TR, l, 2)
                cboSrc10.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow11.Text = Mid(TR, r, 2)
                txtCol11.Text = Mid(TR, c, 2)
                txtLngth11.Text = Mid(TR, l, 2)
                cboSrc11.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow12.Text = Mid(TR, r, 2)
                txtCol12.Text = Mid(TR, c, 2)
                txtLngth12.Text = Mid(TR, l, 2)
                cboSrc12.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If

            cboSubmitType.Text = VB.Right(TR, 6).Trim.ToString
            TR = fileReader.ReadLine
            If cboSubmitType.Text <> "Submit" Then
                cboPFKey.Text = VB.Right(TR, VB.Len(TR) - 7).Trim.ToString
            End If
            TR = fileReader.ReadLine
            If cboSubmitType.Text <> "Submit" Then
                txtTimesToSubmit.Text = VB.Right(TR, 1).Trim.ToString
            End If
            TR = fileReader.ReadLine
            If cboSubmitType.Text = "Submit" Then
                txtTimesEnter.Text = VB.Right(TR, 1).Trim.ToString
            End If
            TR = fileReader.ReadLine
            If VB.Left(TR, 3) = "Row" Then
                txtSrow1.Text = Mid(TR, r, 2)
                txtSCol1.Text = Mid(TR, c, 2)
                txtSLngth1.Text = Mid(TR, l, 2)
                cboSSrc1.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtSrow2.Text = Mid(TR, r, 2)
                txtSCol2.Text = Mid(TR, c, 2)
                txtSLngth2.Text = Mid(TR, l, 2)
                cboSSrc2.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "PF " Then
                cboSPFKey.Text = VB.Right(TR, VB.Len(TR) - 7).Trim.ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Sub" Then
                txtSubWindow.Text = VB.Right(TR, VB.Len(TR) - 11).Trim.ToString
                TR = fileReader.ReadLine
            End If

            If VB.Left(TR, 3) = "Row" Then
                txtRow13.Text = Mid(TR, r, 2)
                txtCol13.Text = Mid(TR, c, 2)
                txtLngth13.Text = Mid(TR, l, 2)
                cboSrc13.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow14.Text = Mid(TR, r, 2)
                txtCol14.Text = Mid(TR, c, 2)
                txtLngth14.Text = Mid(TR, l, 2)
                cboSrc14.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow15.Text = Mid(TR, r, 2)
                txtCol15.Text = Mid(TR, c, 2)
                txtLngth15.Text = Mid(TR, l, 2)
                cboSrc15.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow16.Text = Mid(TR, r, 2)
                txtCol16.Text = Mid(TR, c, 2)
                txtLngth16.Text = Mid(TR, l, 2)
                cboSrc16.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow17.Text = Mid(TR, r, 2)
                txtCol17.Text = Mid(TR, c, 2)
                txtLngth17.Text = Mid(TR, l, 2)
                cboSrc17.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow18.Text = Mid(TR, r, 2)
                txtCol18.Text = Mid(TR, c, 2)
                txtLngth18.Text = Mid(TR, l, 2)
                cboSrc18.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow19.Text = Mid(TR, r, 2)
                txtCol19.Text = Mid(TR, c, 2)
                txtLngth19.Text = Mid(TR, l, 2)
                cboSrc19.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow20.Text = Mid(TR, r, 2)
                txtCol20.Text = Mid(TR, c, 2)
                txtLngth20.Text = Mid(TR, l, 2)
                cboSrc20.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow21.Text = Mid(TR, r, 2)
                txtCol21.Text = Mid(TR, c, 2)
                txtLngth21.Text = Mid(TR, l, 2)
                cboSrc21.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow22.Text = Mid(TR, r, 2)
                txtCol22.Text = Mid(TR, c, 2)
                txtLngth22.Text = Mid(TR, l, 2)
                cboSrc22.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow23.Text = Mid(TR, r, 2)
                txtCol23.Text = Mid(TR, c, 2)
                txtLngth23.Text = Mid(TR, l, 2)
                cboSrc23.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow24.Text = Mid(TR, r, 2)
                txtCol24.Text = Mid(TR, c, 2)
                txtLngth24.Text = Mid(TR, l, 2)
                cboSrc24.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow25.Text = Mid(TR, r, 2)
                txtCol25.Text = Mid(TR, c, 2)
                txtLngth25.Text = Mid(TR, l, 2)
                cboSrc25.Text = VB.Right(TR, 8).ToString
                TR = fileReader.ReadLine
            End If
            If VB.Left(TR, 3) = "Row" Then
                txtRow26.Text = Mid(TR, r, 2)
                txtCol26.Text = Mid(TR, c, 2)
                txtLngth26.Text = Mid(TR, l, 2)
                cboSrc26.Text = VB.Right(TR, 8).ToString
            End If


            fileReader.Close()
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
    End Sub
End Class
