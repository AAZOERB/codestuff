﻿Imports System.Collections.Specialized
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Text

Public Class Database
    Shared databaseServer As String
    Shared databaseName As String

    Public Shared Function LoanNumberValidation(loanNumber As Integer) As Boolean


        Dim dataTable As New DataTable

        Using _
            sqlConn As _
                New SqlConnection(String.Format("Server={0};Database={1};Trusted_Connection=true", databaseServer,
                                                databaseName))
            Dim sqlAdapater As SqlDataAdapter
            Dim sqlCmd As New SqlCommand
            Dim stringBuilder As New StringBuilder

            sqlConn.Open()
            sqlCmd.Connection = sqlConn

            stringBuilder.Append(
                String.Format("SELECT loan_number FROM DERIVED.INDICATORS WHERE ACTIVE_LOAN = 1 AND Loan_number = {0}",
                              loanNumber))
            sqlCmd.CommandType = CommandType.Text
            sqlCmd.CommandText = stringBuilder.ToString()

            sqlAdapater = New SqlDataAdapter(sqlCmd)
            sqlAdapater.Fill(dataTable)

        End Using

        If dataTable.Rows.Count = 1 Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Shared Function GetAppSettings()
        Dim appSettings As NameValueCollection = ConfigurationManager.AppSettings

        databaseServer = appSettings.Get("DatabaseServer")
        databaseName = appSettings.Get("DatabaseName")
    End Function
End Class
