Option Explicit On
Imports VB = Microsoft.VisualBasic
Imports VB6 = Microsoft.VisualBasic.Compatibility.VB6
Imports SysConf = System.Configuration.ConfigurationSettings
Imports System.Data.OleDb
Imports System.Data.SqlClient

Public Module DirectorScripSecurity

    'Declare Function GetUserName Lib "advapi32.dll" Alias "GetUserNameA" (ByVal lpbuffer As String, ByRef nSize As Integer) As Integer
    Private Declare Function RegisterDirDLL Lib "CPIproDir.Dll" Alias "DllRegisterServer" () As Integer
    '''''''''''''''''Used to log script activity'''''''''''''''''''''''
    'Public SQLSTConn As New SqlConnection("Data Source=LTCMETPVDB02.corp.mlhl.com\SQLRMPROD2, 2395;Initial Catalog=SRVCPROD;User Id=DIRADMIN;Password=SRVdir2008;")
    'Public SQLSTConnTest As New SqlConnection("Data Source=LTCMETQAVDB02.corp.mlhl.com\SQLRMTEST2, 2395;Initial Catalog=LCPRPROD;User Id=DIRADMIN;Password=SVRdir2008;")
    Public SQLSTConn As New SqlConnection
    Public SQLSTcommand As SqlCommand
    Public SqlSTint As Integer
    Public SqlSTDA As SqlDataAdapter
    Public SqlSTDr As SqlDataReader
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Public WrkConn, WrkRpt, tDB As ADODB.Connection
    Public WrkConnOleDb As System.Data.OleDb.OleDbConnection
    Public Rst As ADODB.Recordset
    Public User As String
    Public AppName As String = My.Application.Info.AssemblyName
    Public AppPath As String = My.Application.Info.DirectoryPath
    Public sScriptInsert As String
    Public ScriptPath As String
    Public StartPath As String = CurrentLoc
    Public sCount As Short
    Public sArr As Short
    Public sStart As Date
    Public sEnd As Date
    Public XLApp As Object
    Public objExcel As Object
    Public objExcelWrkBk As Object
    Public objXlSht As Object
    Public objExcel2 As Object
    Public objExcelWrkBk2 As Object
    Public objXlSht2 As Object
    Public objRange As Object
    Public objRange2 As Object
    Public RLC As Integer
    Public ProgressMax As Integer
    Public ProgressValue As Integer
    Const xlAscending = 1
    Const xlDescending = 2
    Const xlYes = 1
    Public TrackClicks As Boolean = GetConfigSetting("TrackClicks")
    Public mstrSmtpServer = GetConfigSetting("SmtpServer")
    'Public TrackClicks As Boolean = False
    Const ERROR_SUCCESS As Short = &H0S
    Const S_OK As Short = 0


    Public ReadOnly Property CurrentLoc() As String
        Get
            If UCase(GetConfigSetting("CLocation")) = "TEST" Then
                CurrentLoc = "\\Nas02.corp.mlhl.com\shared\AppData\Test\Fidelity_Director_Test\Scripts"
                SQLSTConn.ConnectionString = "Data Source=LTCMETQAVDB02.corp.mlhl.com\SQLRMTEST2, 2395;Initial Catalog=srvctest;User Id=DIRADMIN;Password=SVRdir2008;"
            Else
                ''''' Provider=SQLNCLI10.1;Integrated Security="";Persist Security Info=False;User ID=DIRADMIN;Initial Catalog=SRVCPROD;Data Source=LTCMETPVDB02.corp.mlhl.com\SQLRMPROD2, 2395;Initial File Name="";Server SPN=""    '''''''
                CurrentLoc = "\\Nas02.corp.mlhl.com\shared\AppData\Fidelity_Director\Prod\Scripts"
                SQLSTConn.ConnectionString = "Data Source=LTCMETPVDB02.corp.mlhl.com\SQLRMPROD2, 2395;Initial Catalog=SRVCPROD;User Id=DIRADMIN;Password=SRVdir2008;"
            End If
            Return CurrentLoc

        End Get
    End Property
    Public ReadOnly Property CurrentLocTest() As String
        Get
            'If VB.Left(AppPath.Trim, 7) = "\\Nas02" Then
            CurrentLocTest = "\\Nas02.corp.mlhl.com\shared\AppData\Test\Fidelity_Director_Test\Scripts"
            ' Else
            ' CurrentLocTest = "\\Daisymax\Fidelity_Director_Test\Scripts"
            ' End If
            Return CurrentLocTest

        End Get
    End Property
    'Public Sub UserName()
    '    Dim BufferSize As Integer
    '    Dim WOK As Integer


    '    BufferSize = 256
    '    User = (Space(BufferSize))
    '    WOK = GetUserName(User, BufferSize)
    '    User = Left(Trim(User), Len(Trim(User)) - 1)
    'End Sub

    Public Function LogScriptLastRun() As Boolean
        ''Connect to database
        DbConnection()
        ''set update statement ''
        'sScriptInsert = "UPDATE tblScriptList SET tblScriptList.ScriptEnd = #" & Now & "#" _
        '& "WHERE ScriptName = '" & My.Application.Info.AssemblyName & "' and Ranby = '" & User & "' and ScriptStart = #" & sStart & "#"
        sScriptInsert = "INSERT INTO tblScriptList ( ScriptName, RanBy, ScriptStart, ScriptEnd) " & "Values ('" & My.Application.Info.AssemblyName & "','" & User & "',#" & sStart & "#," & "#" & Now & "#)"
        ''update the databse with the user info
        WrkConn.Execute(sScriptInsert)
        WrkConn.Close()
        MessageBox.Show(My.Application.Info.AssemblyName & " IS DONE.", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Function
    Public Function LogScriptLastRunSQL() As Boolean
        ''set update statement ''
        sScriptInsert = "INSERT INTO DIRADM.T_DST_DAT_LOG ( Script_Name, Ran_By, Script_Start, Script_End) " & "Values ('" & My.Application.Info.AssemblyName & "','" & User & "','" & sStart & "'," & "'" & Now & "')"
        ''update the databse with the user info
        STExcSqlCommd(sScriptInsert, "Write")
        MessageBox.Show(My.Application.Info.AssemblyName & " IS DONE.", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Function

    Public Function LogScriptLastRunNoMsgSQL() As Boolean
        ''set update statement ''
        sScriptInsert = "INSERT INTO DIRADM.T_DST_DAT_LOG ( Script_Name, Ran_By, Script_Start, Script_End) " & "Values ('" & My.Application.Info.AssemblyName & "','" & User & "','" & sStart & "'," & "'" & Now & "')"
        ''update the databse with the user info
        STExcSqlCommd(sScriptInsert, "Write")
    End Function
    Public Function LogScriptLastRunNoMsg() As Boolean
        ''Connect to database
        DbConnection()
        ''set update statement ''
        'sScriptInsert = "UPDATE tblScriptList SET tblScriptList.ScriptEnd = #" & Now & "#" _
        '& "WHERE ScriptName = '" & My.Application.Info.AssemblyName & "' and Ranby = '" & User & "' and ScriptStart = #" & sStart & "#"
        sScriptInsert = "INSERT INTO tblScriptList ( ScriptName, RanBy, ScriptStart, ScriptEnd) " & "Values ('" & My.Application.Info.AssemblyName & "','" & User & "',#" & sStart & "#," & "#" & Now & "#)"

        ''update the databse with the user info
        WrkConn.Execute(sScriptInsert)
        WrkConn.Close()
    End Function

    Public Sub LogScriptStart()
        ''Set Script Start time''''''
        sStart = VB.FormatDateTime(Now, DateFormat.LongDate) & " " & VB.FormatDateTime(Now, DateFormat.LongTime)
    End Sub

    Public Function LogScriptLastRunNoMsgSpec(ByVal ScriptName As String) As Boolean
        ''Connect to database
        DbConnection()
        ''set update statement ''
        sScriptInsert = "INSERT INTO tblScriptList ( ScriptName, RanBy, ScriptStart, ScriptEnd) " & "Values ('" & ScriptName & "','" & User & "',#" & sStart & "#," & "#" & Now & "#)"
        ''update the databse with the user info
        WrkConn.Execute(sScriptInsert)
        WrkConn.Close()
    End Function

    Public Function LogScriptLastRunNoMsgSpecSQL(ByVal ScriptName As String) As Boolean
        ''set update statement ''
        sScriptInsert = "INSERT INTO DIRADM.T_DST_DAT_LOG ( Script_Name, Ran_By, Script_Start, Script_End) " & "Values ('" & ScriptName & "','" & User & "','" & sStart & "'," & "'" & Now & "')"
        ''update the databse with the user info
        STExcSqlCommd(sScriptInsert, "Write")
    End Function

    Public Sub LogScriptStartSpec(ByVal ScriptName As String)
        sStart = VB.FormatDateTime(Now, DateFormat.LongDate) & " " & VB.FormatDateTime(Now, DateFormat.LongTime)
    End Sub

    Public Sub ErrorLogging(ByVal ErrMsg As String)
        On Error GoTo ErrMs
        Dim strLogpath As String
        Dim intFile As Short
        intFile = FreeFile()

        strLogpath = My.Application.Info.DirectoryPath & "\ErrorLog.txt"
        If Dir(strLogpath, FileAttribute.Directory) = vbNullString Then
            FileOpen(intFile, strLogpath, OpenMode.Output)
        ElseIf Len(strLogpath) > 9999999 Then
            Kill(strLogpath)
            FileOpen(intFile, strLogpath, OpenMode.Input)
        Else
            FileOpen(intFile, strLogpath, OpenMode.Append)
        End If
        PrintLine(intFile, VB6.Format(Today, "MM/DD/YYYY") & " " & VB6.Format(TimeOfDay, "HH:MM:SS") & " User: " & User & ", " & ErrMsg)
        FileClose(intFile)
        Exit Sub
ErrMs:
        MsgBox("Error Log problem: Error " & Err.Number & ", " & Err.Description)
        FileClose(intFile)
    End Sub

    'Open and connect to an Excell spreadsheet''''
    Public Sub WrkConnXL(ByVal XLFile As String, ByRef XLSheet As Short)
        'XLApp = CreateObject("Excel.Application")
        objExcel = GetObject("", "Excel.Application")
        objExcelWrkBk = objExcel.Workbooks.Open(XLFile)
        objXlSht = objExcelWrkBk.sheets(XLSheet)
    End Sub
    'Open and connect to an Excell spreadsheet''''
    Public Sub WrkConnXL2(ByVal XLFile As String, ByRef XLSheet As Short)
        'XLApp = CreateObject("Excel.Application")
        objExcel2 = GetObject("", "Excel.Application")
        objExcelWrkBk2 = objExcel2.Workbooks.Open(XLFile)
        objXlSht2 = objExcelWrkBk2.sheets(XLSheet)
    End Sub
    ''Change the working Excel spreadsheet''''''''
    Public Sub XLChangeSht2(ByVal XLSheet As Short)
        objXlSht2 = objExcelWrkBk2.sheets(XLSheet)
    End Sub

    ''Change the working Excel spreadsheet''''''''
    Public Sub XLChangeSht(ByVal XLSheet As Short)
        objXlSht = objExcelWrkBk.sheets(XLSheet)
    End Sub
    '' Close Excel objects
    Public Sub XLConnClose()
        On Error Resume Next
        objExcelWrkBk.save()
        objXlSht.Application.Quit()
        objXlSht = Nothing
        objExcel.Application.Quit()
        objExcelWrkBk = Nothing
        objExcel = Nothing
    End Sub
    ''Cut and paste information
    Public Sub XLCutNPaste(ByVal FromRange As String, ByVal FromSheet As Short, ByVal ToRange As String, ByVal ToSheet As Short)
        Try
            'objExcel.visible = True
            objExcel.Sheets(FromSheet).Select()
            objXlSht.Range(FromRange).Select()
            objExcel.Selection.Cut()
            objExcel.Sheets(ToSheet).Select()
            objExcel.Sheets(ToSheet).Range(ToRange).Select()
            objExcel.ActiveSheet.Paste()
        Catch ex As Exception
            MessageBox.Show(ex.Message & " : Cut and Paste Failed.")
        End Try

    End Sub
    Public Sub XLPrint()
        On Error Resume Next
        objExcel.ActiveWorkbook.PrintOut()
    End Sub
    Public Sub XLConnClose2()
        On Error Resume Next
        objExcelWrkBk2.save()
        objXlSht2.Application.Quit()
        objXlSht2 = Nothing
        objExcel2.Application.Quit()
        objExcelWrkBk2 = Nothing
        objExcel2 = Nothing
    End Sub

    Public Sub XLSort()
        objRange = objXlSht.UsedRange
        objRange2 = objXlSht.Range("A2")
        objRange.Sort(objRange2, xlAscending, , , , , , xlYes)
    End Sub
    Public Sub XLSortSpec(ByVal SortKey As String, ByVal AscOrDsc As String)
        objRange = objXlSht.UsedRange
        objRange2 = objXlSht.Range(SortKey)
        If Left(AscOrDsc, 1) = "A" Then
            AscOrDsc = "xlAscending"
        Else
            AscOrDsc = "xlDescending"
        End If
        objRange.Sort(objRange2, xlAscending, , , , , , xlYes)
        'Sort key1:=Columns("C"), Header:=xlYes
    End Sub
    ' ''Move records from one sheet to another
    'Public Sub MoveToCompletedSpreadsheet(ByVal MRow As Integer, ByVal MCol As Integer, ByVal SheetNum As Integer)
    '    Dim Erow, i As Integer
    '    Dim MoveData As New ArrayList
    '    Try
    '        MoveData.Clear()
    '        For i = 1 To MCol
    '            MoveData.Add(objXlSht.cells(MRow, i).Value)
    '        Next i
    '        XLChangeSht(SheetNum)
    '        Erow = 2
    '        Do Until Len(Trim(objXlSht.cells(Erow, 1).Value)) = 0
    '            Erow = Erow + 1
    '        Loop
    '        objXlSht.cells(Erow, 1).Value = MoveData(0)
    '        For i = 1 To MCol
    '            objXlSht.cells(Erow, i).Value = MoveData(i)
    '        Next
    '    Catch exp As Exception
    '        MessageBox.Show(exp.Message)
    '    End Try
    'End Sub

    Public Function STExcSqlCommd(ByVal Sqlstmt As String, ByVal ReadWrite As String) As Boolean
        STExcSqlCommd = False
        Try
            If SQLSTConn.State = ConnectionState.Closed Then
                SQLSTConn.Open()
            End If
            If Sqlstmt <> Nothing Then
                SQLSTcommand = New SqlCommand(Sqlstmt, SQLSTConn)
                'executing the command and assigning it to connection 
            End If
redo:
            If ReadWrite = "Read" Then
                SqlSTDr = SQLSTcommand.ExecuteReader
            ElseIf ReadWrite = "Write" Then
                SqlSTint = SQLSTcommand.ExecuteNonQuery
            End If
            Return True
        Catch exp As Exception
            If exp.Message = "There is already an open DataReader associated with this Command which must be closed first." Then
                SqlSTDr.Close()
                GoTo redo
            Else
                MessageBox.Show(exp.Message)
            End If
        End Try
        Return STExcSqlCommd
    End Function


    Public Sub DbConnection()
        Dim Dbstring As String
        Try
            Dbstring = StartPath & "\Director_Script_Support\DirectorScriptSupport.MDB"
            'Dbstring = "D:\Code\Director\DirectorScriptSupport.NET\DirectorScriptSupport.MDB"
            ' Initialize Connection object and open db
            WrkConn = New ADODB.Connection
            With WrkConn
                WrkConn.Open("Provider = Microsoft.Jet.OLEDB.4.0;" & _
                "Data Source=" & Dbstring & ";" & _
                "Jet OLEDB:Database Password=!Fidelity!;")
            End With
        Catch exp As Exception
            MessageBox.Show(exp.Message & " :: " & StartPath)
        End Try
    End Sub

    Public Sub CopyMaster(ByVal FrFileName As String, ByVal ToFileName As String)
        FileCopy(My.Application.Info.DirectoryPath & "\" & FrFileName, My.Application.Info.DirectoryPath & "\" & ToFileName)
    End Sub

    ''Select a file to process''
    Public Function SelectFile(ByVal Filter As String, ByVal Title As String) As String
        Dim fdlg As OpenFileDialog = New OpenFileDialog()
        fdlg.Title = Title
        fdlg.InitialDirectory = My.Application.Info.DirectoryPath
        'fdlg.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fdlg.Filter = Filter
        fdlg.FilterIndex = 2
        fdlg.RestoreDirectory = True
        SelectFile = ""
        fdlg.ShowDialog()
        If Len(fdlg.FileName) = 0 Then
            MsgBox("File not selected. Script execution canceled.", vbOKOnly + vbCritical + vbSystemModal, Title)
        Else
            SelectFile = fdlg.FileName
        End If

        Return SelectFile
    End Function

    Function LastBusDay(ByVal D As Date) As Date
        Dim D2 As Object
        D2 = DateSerial(Year(D), Month(D) + 1, 0)
        Do While Weekday(D2) = 1 Or Weekday(D2) = 7
            D2 = DateAdd(DateInterval.Day, -1, D2)
        Loop
        LastBusDay = D2
    End Function

    Public Function SetDates(ByVal pDate As Date) As String
        SetDates = Nothing
        Select Case Month(pDate)
            Case 1, 3, 5, 7, 8, 10, 12
                SetDates = "31"
            Case 4, 6, 9, 11
                SetDates = "30"
            Case 2
                If (Year(pDate) Mod 4) = 0 Then
                    SetDates = "29"
                Else
                    SetDates = "28"
                End If
        End Select
        Return SetDates
    End Function

    Public Sub ReadLCount()
        Dim fileReader As System.IO.StreamReader
        Dim TR As String
        Dim Dcount As Integer
        Dcount = 0
        Try
            TR = " "
            fileReader = _
            My.Computer.FileSystem.OpenTextFileReader(StartPath & "\Director_Script_Support\RLC.avg") '"D:\Code\Director\Cash_Processing\CASH_ACH_PROCESSING.NET\CASH_ACH_PROCESSING\DLD.day")
            Do Until TR = Nothing
                TR = fileReader.ReadLine
                If TR = Nothing Then Exit Do
                RLC = TR
                Dcount = Dcount + 1
            Loop
            fileReader.Close()
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        End Try
    End Sub


    '''''use this for sorting dates''
    '''' Dim x(0 To SomeArray.Count - 1) As Date
    ' '' ''Dim x(0 To SomeArray.Count - 1) As Date
    ' '' ''        For cnt = 0 To SomeArray.Count - 1
    ' '' ''            If SomeArray.Item(cnt) <> "#        #" Then
    ' '' ''                DateFound = False
    ' '' ''                For xint = 0 To cnt
    ' '' ''                    If cnt > SomeArray.Count Then
    ' '' ''                        If x(xint) = SomeArray.Item(cnt) Then
    ' '' ''                            DateFound = True
    ' '' ''                            Exit For
    ' '' ''                        End If
    ' '' ''                    End If
    ' '' ''                Next
    ' '' ''                If DateFound = False Then x(cnt) = SomeArray.Item(cnt)
    ' '' ''            End If
    ' '' ''        Next
    '''' QuickSortDatesAscending(x, LBound(x), UBound(x))


    Public Sub QuickSortDatesDescending(ByVal narray() As Date, ByVal inLow As Long, ByVal inHi As Long)

        Dim pivot As Long
        Dim tmpSwap As Date
        Dim tmpLow As Long
        Dim tmpHi As Long

        tmpLow = inLow
        tmpHi = inHi

        pivot = DateToJulian(narray((inLow + inHi) / 2))

        While (tmpLow <= tmpHi)

            While DateToJulian(narray(tmpLow)) > pivot And (tmpLow < inHi)
                tmpLow = tmpLow + 1
            End While

            While (pivot > DateToJulian(narray(tmpHi))) And (tmpHi > inLow)
                tmpHi = tmpHi - 1
            End While

            If (tmpLow <= tmpHi) Then
                tmpSwap = narray(tmpLow)
                narray(tmpLow) = narray(tmpHi)
                narray(tmpHi) = tmpSwap
                tmpLow = tmpLow + 1
                tmpHi = tmpHi - 1
            End If

        End While

        If (inLow < tmpHi) Then QuickSortDatesDescending(narray, inLow, tmpHi)
        If (tmpLow < inHi) Then QuickSortDatesDescending(narray, tmpLow, inHi)

    End Sub

    Public Sub QuickSortDatesAscending(ByVal narray() As Date, ByVal inLow As Long, ByVal inHi As Long)

        Dim pivot As Long
        Dim tmpSwap As Date
        Dim tmpLow As Long
        Dim tmpHi As Long

        tmpLow = inLow
        tmpHi = inHi

        pivot = DateToJulian(narray((inLow + inHi) / 2))

        While (tmpLow <= tmpHi)

            While (DateToJulian(narray(tmpLow)) < pivot) And (tmpLow < inHi)
                tmpLow = tmpLow + 1
            End While

            While (pivot < DateToJulian(narray(tmpHi))) And (tmpHi > inLow)
                tmpHi = tmpHi - 1
            End While

            If (tmpLow <= tmpHi) Then

                tmpSwap = narray(tmpLow)
                narray(tmpLow) = narray(tmpHi)
                narray(tmpHi) = tmpSwap
                tmpLow = tmpLow + 1
                tmpHi = tmpHi - 1

            End If

        End While

        If (inLow < tmpHi) Then QuickSortDatesAscending(narray, inLow, tmpHi)
        If (tmpLow < inHi) Then QuickSortDatesAscending(narray, tmpLow, inHi)

    End Sub

    Private Function DateToJulian(ByVal MyDate As Date) As Long

        'Return a numeric value representing
        'the passed date

        DateToJulian = CLng(Format(Year(MyDate), "0000") _
                  + Format(DateDiff("d", CDate("01/01/" _
                  + Format(Year(MyDate), "0000")), MyDate) _
                  + 1, "000"))
    End Function

    Public Function GetConfigSetting(ByVal KeyName As String) As String
        Dim strResult As String = ""
        strResult = SysConf.AppSettings.Get(KeyName)
        If strResult.Length > 0 Then
            Return strResult
        Else
            Return ""
        End If

    End Function
End Module
