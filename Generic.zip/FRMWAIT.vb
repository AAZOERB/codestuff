Option Strict Off
Option Explicit On
Friend Class frmWait
    Inherits System.Windows.Forms.Form

    Private Sub frmWait_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) _
        Handles MyBase.Load
        Timer1.Interval = 500
        Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Timer1.Tick
        Me.Close()
    End Sub
End Class