<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFileSelction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmFileSelction))
        Me.btnSubmit = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.btnBrowse = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtFileLoc = New System.Windows.Forms.RichTextBox
        Me.txtScreen = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.btnLoad = New System.Windows.Forms.Button
        Me.cboLoanNumber = New System.Windows.Forms.ComboBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.sdlgFile = New System.Windows.Forms.SaveFileDialog
        Me.btnReset = New System.Windows.Forms.Button
        Me.btnHelp = New System.Windows.Forms.Button
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtSrow1 = New System.Windows.Forms.TextBox
        Me.txtSCol1 = New System.Windows.Forms.TextBox
        Me.txtSLngth1 = New System.Windows.Forms.TextBox
        Me.cboSSrc1 = New System.Windows.Forms.ComboBox
        Me.txtSrow2 = New System.Windows.Forms.TextBox
        Me.txtSCol2 = New System.Windows.Forms.TextBox
        Me.txtSLngth2 = New System.Windows.Forms.TextBox
        Me.cboSSrc2 = New System.Windows.Forms.ComboBox
        Me.cboSPFKey = New System.Windows.Forms.ComboBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnSave = New System.Windows.Forms.Button
        Me.Label23 = New System.Windows.Forms.Label
        Me.txtSubWindow = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.cboSrc13 = New System.Windows.Forms.ComboBox
        Me.txtLngth13 = New System.Windows.Forms.TextBox
        Me.txtCol13 = New System.Windows.Forms.TextBox
        Me.txtRow13 = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.cboSrc12 = New System.Windows.Forms.ComboBox
        Me.txtLngth12 = New System.Windows.Forms.TextBox
        Me.txtCol12 = New System.Windows.Forms.TextBox
        Me.txtRow12 = New System.Windows.Forms.TextBox
        Me.cboSrc11 = New System.Windows.Forms.ComboBox
        Me.txtLngth11 = New System.Windows.Forms.TextBox
        Me.txtCol11 = New System.Windows.Forms.TextBox
        Me.txtRow11 = New System.Windows.Forms.TextBox
        Me.cboSrc10 = New System.Windows.Forms.ComboBox
        Me.txtLngth10 = New System.Windows.Forms.TextBox
        Me.txtCol10 = New System.Windows.Forms.TextBox
        Me.txtRow10 = New System.Windows.Forms.TextBox
        Me.cboSrc9 = New System.Windows.Forms.ComboBox
        Me.txtLngth9 = New System.Windows.Forms.TextBox
        Me.txtCol9 = New System.Windows.Forms.TextBox
        Me.txtRow9 = New System.Windows.Forms.TextBox
        Me.cboSrc8 = New System.Windows.Forms.ComboBox
        Me.txtLngth8 = New System.Windows.Forms.TextBox
        Me.txtCol8 = New System.Windows.Forms.TextBox
        Me.txtRow8 = New System.Windows.Forms.TextBox
        Me.cboSrc7 = New System.Windows.Forms.ComboBox
        Me.txtLngth7 = New System.Windows.Forms.TextBox
        Me.txtCol7 = New System.Windows.Forms.TextBox
        Me.txtRow7 = New System.Windows.Forms.TextBox
        Me.cboSrc6 = New System.Windows.Forms.ComboBox
        Me.txtLngth6 = New System.Windows.Forms.TextBox
        Me.txtCol6 = New System.Windows.Forms.TextBox
        Me.txtRow6 = New System.Windows.Forms.TextBox
        Me.cboSrc5 = New System.Windows.Forms.ComboBox
        Me.txtLngth5 = New System.Windows.Forms.TextBox
        Me.txtCol5 = New System.Windows.Forms.TextBox
        Me.txtRow5 = New System.Windows.Forms.TextBox
        Me.cboSrc4 = New System.Windows.Forms.ComboBox
        Me.txtLngth4 = New System.Windows.Forms.TextBox
        Me.txtCol4 = New System.Windows.Forms.TextBox
        Me.txtRow4 = New System.Windows.Forms.TextBox
        Me.cboSrc3 = New System.Windows.Forms.ComboBox
        Me.txtLngth3 = New System.Windows.Forms.TextBox
        Me.txtCol3 = New System.Windows.Forms.TextBox
        Me.txtRow3 = New System.Windows.Forms.TextBox
        Me.cboSrc2 = New System.Windows.Forms.ComboBox
        Me.txtLngth2 = New System.Windows.Forms.TextBox
        Me.txtCol2 = New System.Windows.Forms.TextBox
        Me.txtRow2 = New System.Windows.Forms.TextBox
        Me.cboSrc1 = New System.Windows.Forms.ComboBox
        Me.txtLngth1 = New System.Windows.Forms.TextBox
        Me.txtCol1 = New System.Windows.Forms.TextBox
        Me.txtRow1 = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.cboSrc26 = New System.Windows.Forms.ComboBox
        Me.txtLngth26 = New System.Windows.Forms.TextBox
        Me.txtCol26 = New System.Windows.Forms.TextBox
        Me.txtRow26 = New System.Windows.Forms.TextBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label46 = New System.Windows.Forms.Label
        Me.Label47 = New System.Windows.Forms.Label
        Me.cboSrc25 = New System.Windows.Forms.ComboBox
        Me.txtLngth25 = New System.Windows.Forms.TextBox
        Me.txtCol25 = New System.Windows.Forms.TextBox
        Me.txtRow25 = New System.Windows.Forms.TextBox
        Me.cboSrc24 = New System.Windows.Forms.ComboBox
        Me.txtLngth24 = New System.Windows.Forms.TextBox
        Me.txtCol24 = New System.Windows.Forms.TextBox
        Me.txtRow24 = New System.Windows.Forms.TextBox
        Me.cboSrc23 = New System.Windows.Forms.ComboBox
        Me.txtLngth23 = New System.Windows.Forms.TextBox
        Me.txtCol23 = New System.Windows.Forms.TextBox
        Me.txtRow23 = New System.Windows.Forms.TextBox
        Me.cboSrc22 = New System.Windows.Forms.ComboBox
        Me.txtLngth22 = New System.Windows.Forms.TextBox
        Me.txtCol22 = New System.Windows.Forms.TextBox
        Me.txtRow22 = New System.Windows.Forms.TextBox
        Me.cboSrc21 = New System.Windows.Forms.ComboBox
        Me.txtLngth21 = New System.Windows.Forms.TextBox
        Me.txtCol21 = New System.Windows.Forms.TextBox
        Me.txtRow21 = New System.Windows.Forms.TextBox
        Me.cboSrc20 = New System.Windows.Forms.ComboBox
        Me.txtLngth20 = New System.Windows.Forms.TextBox
        Me.txtCol20 = New System.Windows.Forms.TextBox
        Me.txtRow20 = New System.Windows.Forms.TextBox
        Me.cboSrc19 = New System.Windows.Forms.ComboBox
        Me.txtLngth19 = New System.Windows.Forms.TextBox
        Me.txtCol19 = New System.Windows.Forms.TextBox
        Me.txtRow19 = New System.Windows.Forms.TextBox
        Me.cboSrc18 = New System.Windows.Forms.ComboBox
        Me.txtLngth18 = New System.Windows.Forms.TextBox
        Me.txtCol18 = New System.Windows.Forms.TextBox
        Me.txtRow18 = New System.Windows.Forms.TextBox
        Me.cboSrc17 = New System.Windows.Forms.ComboBox
        Me.txtLngth17 = New System.Windows.Forms.TextBox
        Me.txtCol17 = New System.Windows.Forms.TextBox
        Me.txtRow17 = New System.Windows.Forms.TextBox
        Me.cboSrc16 = New System.Windows.Forms.ComboBox
        Me.txtLngth16 = New System.Windows.Forms.TextBox
        Me.txtCol16 = New System.Windows.Forms.TextBox
        Me.txtRow16 = New System.Windows.Forms.TextBox
        Me.cboSrc15 = New System.Windows.Forms.ComboBox
        Me.txtLngth15 = New System.Windows.Forms.TextBox
        Me.txtCol15 = New System.Windows.Forms.TextBox
        Me.txtRow15 = New System.Windows.Forms.TextBox
        Me.cboSrc14 = New System.Windows.Forms.ComboBox
        Me.txtLngth14 = New System.Windows.Forms.TextBox
        Me.txtCol14 = New System.Windows.Forms.TextBox
        Me.txtRow14 = New System.Windows.Forms.TextBox
        Me.Label48 = New System.Windows.Forms.Label
        Me.Label49 = New System.Windows.Forms.Label
        Me.Label50 = New System.Windows.Forms.Label
        Me.Label51 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtTimesEnter = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtTimesToSubmit = New System.Windows.Forms.TextBox
        Me.cboPFKey = New System.Windows.Forms.ComboBox
        Me.cboSubmitType = New System.Windows.Forms.ComboBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSubmit
        '
        Me.btnSubmit.Enabled = False
        Me.btnSubmit.Location = New System.Drawing.Point(375, 56)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(79, 19)
        Me.btnSubmit.TabIndex = 0
        Me.btnSubmit.TabStop = False
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(375, 7)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(79, 21)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.TabStop = False
        Me.btnCancel.Text = "Close"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(375, 30)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(79, 21)
        Me.btnBrowse.TabIndex = 2
        Me.btnBrowse.TabStop = False
        Me.btnBrowse.Text = "Browse"
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Source File"
        '
        'txtFileLoc
        '
        Me.txtFileLoc.Location = New System.Drawing.Point(70, 33)
        Me.txtFileLoc.Name = "txtFileLoc"
        Me.txtFileLoc.Size = New System.Drawing.Size(285, 29)
        Me.txtFileLoc.TabIndex = 5
        Me.txtFileLoc.TabStop = False
        Me.txtFileLoc.Text = ""
        '
        'txtScreen
        '
        Me.txtScreen.Location = New System.Drawing.Point(70, 67)
        Me.txtScreen.Name = "txtScreen"
        Me.txtScreen.Size = New System.Drawing.Size(58, 20)
        Me.txtScreen.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 71)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Screen"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(-6, 85)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(477, 15)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "---------------------------------------------------------------------------------" & _
            "-------------"
        '
        'btnLoad
        '
        Me.btnLoad.Location = New System.Drawing.Point(7, 7)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.Size = New System.Drawing.Size(75, 21)
        Me.btnLoad.TabIndex = 118
        Me.btnLoad.TabStop = False
        Me.btnLoad.Text = "Load"
        Me.btnLoad.UseVisualStyleBackColor = True
        '
        'cboLoanNumber
        '
        Me.cboLoanNumber.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z", ""})
        Me.cboLoanNumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboLoanNumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.cboLoanNumber.FormattingEnabled = True
        Me.cboLoanNumber.Location = New System.Drawing.Point(267, 127)
        Me.cboLoanNumber.Name = "cboLoanNumber"
        Me.cboLoanNumber.Size = New System.Drawing.Size(121, 21)
        Me.cboLoanNumber.TabIndex = 66
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.Red
        Me.Label13.Location = New System.Drawing.Point(7, 130)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(219, 13)
        Me.Label13.TabIndex = 120
        Me.Label13.Text = "Select Source Column For The Loan Number"
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(88, 7)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 21)
        Me.btnReset.TabIndex = 121
        Me.btnReset.TabStop = False
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnHelp
        '
        Me.btnHelp.Location = New System.Drawing.Point(191, 7)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(79, 21)
        Me.btnHelp.TabIndex = 124
        Me.btnHelp.TabStop = False
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(-18, 253)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(477, 15)
        Me.Label15.TabIndex = 125
        Me.Label15.Text = "---------------------------------------------------------------------------------" & _
            "-------------"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(7, 111)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(419, 13)
        Me.Label16.TabIndex = 127
        Me.Label16.Text = "If the Loan Number is not the requred data select None and additional fields will" & _
            " appear."
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(7, 97)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(407, 13)
        Me.Label17.TabIndex = 126
        Me.Label17.Text = "This section is used to Identify what needs to be input first before Submit is ex" & _
            "ecuted."
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(130, 7)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(70, 13)
        Me.Label21.TabIndex = 142
        Me.Label21.Text = "Data Position"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(119, 20)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(93, 13)
        Me.Label19.TabIndex = 144
        Me.Label19.Text = "Row / Col / Lngth"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(292, 15)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(79, 13)
        Me.Label18.TabIndex = 145
        Me.Label18.Text = "Source Column"
        '
        'txtSrow1
        '
        Me.txtSrow1.Location = New System.Drawing.Point(118, 35)
        Me.txtSrow1.Name = "txtSrow1"
        Me.txtSrow1.Size = New System.Drawing.Size(29, 20)
        Me.txtSrow1.TabIndex = 146
        '
        'txtSCol1
        '
        Me.txtSCol1.Location = New System.Drawing.Point(149, 35)
        Me.txtSCol1.Name = "txtSCol1"
        Me.txtSCol1.Size = New System.Drawing.Size(29, 20)
        Me.txtSCol1.TabIndex = 147
        '
        'txtSLngth1
        '
        Me.txtSLngth1.Location = New System.Drawing.Point(180, 35)
        Me.txtSLngth1.Name = "txtSLngth1"
        Me.txtSLngth1.Size = New System.Drawing.Size(29, 20)
        Me.txtSLngth1.TabIndex = 148
        '
        'cboSSrc1
        '
        Me.cboSSrc1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSSrc1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSSrc1.FormattingEnabled = True
        Me.cboSSrc1.Location = New System.Drawing.Point(275, 35)
        Me.cboSSrc1.Name = "cboSSrc1"
        Me.cboSSrc1.Size = New System.Drawing.Size(121, 21)
        Me.cboSSrc1.TabIndex = 149
        '
        'txtSrow2
        '
        Me.txtSrow2.Location = New System.Drawing.Point(118, 59)
        Me.txtSrow2.Name = "txtSrow2"
        Me.txtSrow2.Size = New System.Drawing.Size(29, 20)
        Me.txtSrow2.TabIndex = 150
        '
        'txtSCol2
        '
        Me.txtSCol2.Location = New System.Drawing.Point(149, 59)
        Me.txtSCol2.Name = "txtSCol2"
        Me.txtSCol2.Size = New System.Drawing.Size(29, 20)
        Me.txtSCol2.TabIndex = 151
        '
        'txtSLngth2
        '
        Me.txtSLngth2.Location = New System.Drawing.Point(180, 59)
        Me.txtSLngth2.Name = "txtSLngth2"
        Me.txtSLngth2.Size = New System.Drawing.Size(29, 20)
        Me.txtSLngth2.TabIndex = 152
        '
        'cboSSrc2
        '
        Me.cboSSrc2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSSrc2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSSrc2.FormattingEnabled = True
        Me.cboSSrc2.Location = New System.Drawing.Point(275, 59)
        Me.cboSSrc2.Name = "cboSSrc2"
        Me.cboSSrc2.Size = New System.Drawing.Size(121, 21)
        Me.cboSSrc2.TabIndex = 153
        '
        'cboSPFKey
        '
        Me.cboSPFKey.FormattingEnabled = True
        Me.cboSPFKey.Items.AddRange(New Object() {"NONE", "PF1", "PF2", "PF3", "PF4", "PF5", "PF6", "PF7", "PF8", "PF9", "PF10", "PF11", "PF12", "PF13", "PF14", "PF15", "PF16", "PF17", "PF18", "PF19", "PF20", "PF21", "PF22", "PF23", "PF24"})
        Me.cboSPFKey.Location = New System.Drawing.Point(309, 89)
        Me.cboSPFKey.Name = "cboSPFKey"
        Me.cboSPFKey.Size = New System.Drawing.Size(87, 21)
        Me.cboSPFKey.TabIndex = 154
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(22, 92)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(281, 13)
        Me.Label22.TabIndex = 155
        Me.Label22.Text = "If after Submit you need to engage a PF key select it here."
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.cboSPFKey)
        Me.GroupBox1.Controls.Add(Me.cboSSrc2)
        Me.GroupBox1.Controls.Add(Me.txtSLngth2)
        Me.GroupBox1.Controls.Add(Me.txtSCol2)
        Me.GroupBox1.Controls.Add(Me.txtSrow2)
        Me.GroupBox1.Controls.Add(Me.cboSSrc1)
        Me.GroupBox1.Controls.Add(Me.txtSLngth1)
        Me.GroupBox1.Controls.Add(Me.txtSCol1)
        Me.GroupBox1.Controls.Add(Me.txtSrow1)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 148)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(451, 112)
        Me.GroupBox1.TabIndex = 128
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Visible = False
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(278, 7)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(78, 21)
        Me.btnSave.TabIndex = 184
        Me.btnSave.TabStop = False
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(151, 71)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(68, 13)
        Me.Label23.TabIndex = 186
        Me.Label23.Text = "Sub Window"
        '
        'txtSubWindow
        '
        Me.txtSubWindow.Location = New System.Drawing.Point(225, 67)
        Me.txtSubWindow.Name = "txtSubWindow"
        Me.txtSubWindow.Size = New System.Drawing.Size(62, 20)
        Me.txtSubWindow.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(17, 282)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(428, 13)
        Me.Label5.TabIndex = 196
        Me.Label5.Text = "a left to right - top to bottom order.  This will make the script run faster and " & _
            "more efficiently."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 268)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(408, 13)
        Me.Label4.TabIndex = 195
        Me.Label4.Text = "Please arrange all data entries in both the source spread sheet and on the window" & _
            " in "
        '
        'Panel1
        '
        Me.Panel1.AllowDrop = True
        Me.Panel1.AutoScroll = True
        Me.Panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.TabControl1)
        Me.Panel1.Location = New System.Drawing.Point(0, 297)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(462, 155)
        Me.Panel1.TabIndex = 197
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(8, 6)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(422, 357)
        Me.TabControl1.TabIndex = 265
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label36)
        Me.TabPage1.Controls.Add(Me.Label32)
        Me.TabPage1.Controls.Add(Me.Label33)
        Me.TabPage1.Controls.Add(Me.Label34)
        Me.TabPage1.Controls.Add(Me.Label35)
        Me.TabPage1.Controls.Add(Me.cboSrc13)
        Me.TabPage1.Controls.Add(Me.txtLngth13)
        Me.TabPage1.Controls.Add(Me.txtCol13)
        Me.TabPage1.Controls.Add(Me.txtRow13)
        Me.TabPage1.Controls.Add(Me.Label28)
        Me.TabPage1.Controls.Add(Me.Label29)
        Me.TabPage1.Controls.Add(Me.Label30)
        Me.TabPage1.Controls.Add(Me.Label31)
        Me.TabPage1.Controls.Add(Me.Label26)
        Me.TabPage1.Controls.Add(Me.Label27)
        Me.TabPage1.Controls.Add(Me.Label25)
        Me.TabPage1.Controls.Add(Me.Label24)
        Me.TabPage1.Controls.Add(Me.cboSrc12)
        Me.TabPage1.Controls.Add(Me.txtLngth12)
        Me.TabPage1.Controls.Add(Me.txtCol12)
        Me.TabPage1.Controls.Add(Me.txtRow12)
        Me.TabPage1.Controls.Add(Me.cboSrc11)
        Me.TabPage1.Controls.Add(Me.txtLngth11)
        Me.TabPage1.Controls.Add(Me.txtCol11)
        Me.TabPage1.Controls.Add(Me.txtRow11)
        Me.TabPage1.Controls.Add(Me.cboSrc10)
        Me.TabPage1.Controls.Add(Me.txtLngth10)
        Me.TabPage1.Controls.Add(Me.txtCol10)
        Me.TabPage1.Controls.Add(Me.txtRow10)
        Me.TabPage1.Controls.Add(Me.cboSrc9)
        Me.TabPage1.Controls.Add(Me.txtLngth9)
        Me.TabPage1.Controls.Add(Me.txtCol9)
        Me.TabPage1.Controls.Add(Me.txtRow9)
        Me.TabPage1.Controls.Add(Me.cboSrc8)
        Me.TabPage1.Controls.Add(Me.txtLngth8)
        Me.TabPage1.Controls.Add(Me.txtCol8)
        Me.TabPage1.Controls.Add(Me.txtRow8)
        Me.TabPage1.Controls.Add(Me.cboSrc7)
        Me.TabPage1.Controls.Add(Me.txtLngth7)
        Me.TabPage1.Controls.Add(Me.txtCol7)
        Me.TabPage1.Controls.Add(Me.txtRow7)
        Me.TabPage1.Controls.Add(Me.cboSrc6)
        Me.TabPage1.Controls.Add(Me.txtLngth6)
        Me.TabPage1.Controls.Add(Me.txtCol6)
        Me.TabPage1.Controls.Add(Me.txtRow6)
        Me.TabPage1.Controls.Add(Me.cboSrc5)
        Me.TabPage1.Controls.Add(Me.txtLngth5)
        Me.TabPage1.Controls.Add(Me.txtCol5)
        Me.TabPage1.Controls.Add(Me.txtRow5)
        Me.TabPage1.Controls.Add(Me.cboSrc4)
        Me.TabPage1.Controls.Add(Me.txtLngth4)
        Me.TabPage1.Controls.Add(Me.txtCol4)
        Me.TabPage1.Controls.Add(Me.txtRow4)
        Me.TabPage1.Controls.Add(Me.cboSrc3)
        Me.TabPage1.Controls.Add(Me.txtLngth3)
        Me.TabPage1.Controls.Add(Me.txtCol3)
        Me.TabPage1.Controls.Add(Me.txtRow3)
        Me.TabPage1.Controls.Add(Me.cboSrc2)
        Me.TabPage1.Controls.Add(Me.txtLngth2)
        Me.TabPage1.Controls.Add(Me.txtCol2)
        Me.TabPage1.Controls.Add(Me.txtRow2)
        Me.TabPage1.Controls.Add(Me.cboSrc1)
        Me.TabPage1.Controls.Add(Me.txtLngth1)
        Me.TabPage1.Controls.Add(Me.txtCol1)
        Me.TabPage1.Controls.Add(Me.txtRow1)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(414, 331)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Data Page1"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(76, 309)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(45, 13)
        Me.Label36.TabIndex = 343
        Me.Label36.Text = "Item 13:"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(76, 286)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(45, 13)
        Me.Label32.TabIndex = 342
        Me.Label32.Text = "Item 12:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(76, 263)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(45, 13)
        Me.Label33.TabIndex = 341
        Me.Label33.Text = "Item 11:"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(76, 240)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(45, 13)
        Me.Label34.TabIndex = 340
        Me.Label34.Text = "Item 10:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(82, 217)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(39, 13)
        Me.Label35.TabIndex = 339
        Me.Label35.Text = "Item 9:"
        '
        'cboSrc13
        '
        Me.cboSrc13.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc13.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc13.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc13.FormattingEnabled = True
        Me.cboSrc13.Location = New System.Drawing.Point(284, 306)
        Me.cboSrc13.Name = "cboSrc13"
        Me.cboSrc13.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc13.TabIndex = 338
        '
        'txtLngth13
        '
        Me.txtLngth13.Location = New System.Drawing.Point(189, 306)
        Me.txtLngth13.Name = "txtLngth13"
        Me.txtLngth13.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth13.TabIndex = 337
        '
        'txtCol13
        '
        Me.txtCol13.Location = New System.Drawing.Point(158, 306)
        Me.txtCol13.Name = "txtCol13"
        Me.txtCol13.Size = New System.Drawing.Size(29, 20)
        Me.txtCol13.TabIndex = 336
        '
        'txtRow13
        '
        Me.txtRow13.Location = New System.Drawing.Point(127, 306)
        Me.txtRow13.Name = "txtRow13"
        Me.txtRow13.Size = New System.Drawing.Size(29, 20)
        Me.txtRow13.TabIndex = 335
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(82, 193)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(39, 13)
        Me.Label28.TabIndex = 334
        Me.Label28.Text = "Item 8:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(82, 170)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(39, 13)
        Me.Label29.TabIndex = 333
        Me.Label29.Text = "Item 7:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(82, 148)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(39, 13)
        Me.Label30.TabIndex = 332
        Me.Label30.Text = "Item 6:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(82, 125)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(39, 13)
        Me.Label31.TabIndex = 331
        Me.Label31.Text = "Item 5:"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(82, 102)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(39, 13)
        Me.Label26.TabIndex = 330
        Me.Label26.Text = "Item 4:"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(82, 78)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(39, 13)
        Me.Label27.TabIndex = 329
        Me.Label27.Text = "Item 3:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(82, 56)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(39, 13)
        Me.Label25.TabIndex = 328
        Me.Label25.Text = "Item 2:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(82, 33)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(39, 13)
        Me.Label24.TabIndex = 327
        Me.Label24.Text = "Item 1:"
        '
        'cboSrc12
        '
        Me.cboSrc12.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc12.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc12.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc12.FormattingEnabled = True
        Me.cboSrc12.Location = New System.Drawing.Point(284, 283)
        Me.cboSrc12.Name = "cboSrc12"
        Me.cboSrc12.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc12.TabIndex = 326
        '
        'txtLngth12
        '
        Me.txtLngth12.Location = New System.Drawing.Point(189, 283)
        Me.txtLngth12.Name = "txtLngth12"
        Me.txtLngth12.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth12.TabIndex = 325
        '
        'txtCol12
        '
        Me.txtCol12.Location = New System.Drawing.Point(158, 283)
        Me.txtCol12.Name = "txtCol12"
        Me.txtCol12.Size = New System.Drawing.Size(29, 20)
        Me.txtCol12.TabIndex = 324
        '
        'txtRow12
        '
        Me.txtRow12.Location = New System.Drawing.Point(127, 283)
        Me.txtRow12.Name = "txtRow12"
        Me.txtRow12.Size = New System.Drawing.Size(29, 20)
        Me.txtRow12.TabIndex = 323
        '
        'cboSrc11
        '
        Me.cboSrc11.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc11.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc11.FormattingEnabled = True
        Me.cboSrc11.Location = New System.Drawing.Point(284, 260)
        Me.cboSrc11.Name = "cboSrc11"
        Me.cboSrc11.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc11.TabIndex = 322
        '
        'txtLngth11
        '
        Me.txtLngth11.Location = New System.Drawing.Point(189, 260)
        Me.txtLngth11.Name = "txtLngth11"
        Me.txtLngth11.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth11.TabIndex = 321
        '
        'txtCol11
        '
        Me.txtCol11.Location = New System.Drawing.Point(158, 260)
        Me.txtCol11.Name = "txtCol11"
        Me.txtCol11.Size = New System.Drawing.Size(29, 20)
        Me.txtCol11.TabIndex = 320
        '
        'txtRow11
        '
        Me.txtRow11.Location = New System.Drawing.Point(127, 260)
        Me.txtRow11.Name = "txtRow11"
        Me.txtRow11.Size = New System.Drawing.Size(29, 20)
        Me.txtRow11.TabIndex = 319
        '
        'cboSrc10
        '
        Me.cboSrc10.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc10.FormattingEnabled = True
        Me.cboSrc10.Location = New System.Drawing.Point(284, 237)
        Me.cboSrc10.Name = "cboSrc10"
        Me.cboSrc10.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc10.TabIndex = 318
        '
        'txtLngth10
        '
        Me.txtLngth10.Location = New System.Drawing.Point(189, 237)
        Me.txtLngth10.Name = "txtLngth10"
        Me.txtLngth10.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth10.TabIndex = 317
        '
        'txtCol10
        '
        Me.txtCol10.Location = New System.Drawing.Point(158, 237)
        Me.txtCol10.Name = "txtCol10"
        Me.txtCol10.Size = New System.Drawing.Size(29, 20)
        Me.txtCol10.TabIndex = 316
        '
        'txtRow10
        '
        Me.txtRow10.Location = New System.Drawing.Point(127, 237)
        Me.txtRow10.Name = "txtRow10"
        Me.txtRow10.Size = New System.Drawing.Size(29, 20)
        Me.txtRow10.TabIndex = 315
        '
        'cboSrc9
        '
        Me.cboSrc9.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc9.FormattingEnabled = True
        Me.cboSrc9.Location = New System.Drawing.Point(284, 214)
        Me.cboSrc9.Name = "cboSrc9"
        Me.cboSrc9.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc9.TabIndex = 314
        '
        'txtLngth9
        '
        Me.txtLngth9.Location = New System.Drawing.Point(189, 214)
        Me.txtLngth9.Name = "txtLngth9"
        Me.txtLngth9.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth9.TabIndex = 313
        '
        'txtCol9
        '
        Me.txtCol9.Location = New System.Drawing.Point(158, 214)
        Me.txtCol9.Name = "txtCol9"
        Me.txtCol9.Size = New System.Drawing.Size(29, 20)
        Me.txtCol9.TabIndex = 312
        '
        'txtRow9
        '
        Me.txtRow9.Location = New System.Drawing.Point(127, 214)
        Me.txtRow9.Name = "txtRow9"
        Me.txtRow9.Size = New System.Drawing.Size(29, 20)
        Me.txtRow9.TabIndex = 311
        '
        'cboSrc8
        '
        Me.cboSrc8.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc8.FormattingEnabled = True
        Me.cboSrc8.Location = New System.Drawing.Point(284, 191)
        Me.cboSrc8.Name = "cboSrc8"
        Me.cboSrc8.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc8.TabIndex = 310
        '
        'txtLngth8
        '
        Me.txtLngth8.Location = New System.Drawing.Point(189, 191)
        Me.txtLngth8.Name = "txtLngth8"
        Me.txtLngth8.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth8.TabIndex = 309
        '
        'txtCol8
        '
        Me.txtCol8.Location = New System.Drawing.Point(158, 191)
        Me.txtCol8.Name = "txtCol8"
        Me.txtCol8.Size = New System.Drawing.Size(29, 20)
        Me.txtCol8.TabIndex = 308
        '
        'txtRow8
        '
        Me.txtRow8.Location = New System.Drawing.Point(127, 191)
        Me.txtRow8.Name = "txtRow8"
        Me.txtRow8.Size = New System.Drawing.Size(29, 20)
        Me.txtRow8.TabIndex = 307
        '
        'cboSrc7
        '
        Me.cboSrc7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc7.FormattingEnabled = True
        Me.cboSrc7.Location = New System.Drawing.Point(284, 168)
        Me.cboSrc7.Name = "cboSrc7"
        Me.cboSrc7.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc7.TabIndex = 306
        '
        'txtLngth7
        '
        Me.txtLngth7.Location = New System.Drawing.Point(189, 168)
        Me.txtLngth7.Name = "txtLngth7"
        Me.txtLngth7.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth7.TabIndex = 305
        '
        'txtCol7
        '
        Me.txtCol7.Location = New System.Drawing.Point(158, 168)
        Me.txtCol7.Name = "txtCol7"
        Me.txtCol7.Size = New System.Drawing.Size(29, 20)
        Me.txtCol7.TabIndex = 304
        '
        'txtRow7
        '
        Me.txtRow7.Location = New System.Drawing.Point(127, 168)
        Me.txtRow7.Name = "txtRow7"
        Me.txtRow7.Size = New System.Drawing.Size(29, 20)
        Me.txtRow7.TabIndex = 303
        '
        'cboSrc6
        '
        Me.cboSrc6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc6.FormattingEnabled = True
        Me.cboSrc6.Location = New System.Drawing.Point(284, 145)
        Me.cboSrc6.Name = "cboSrc6"
        Me.cboSrc6.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc6.TabIndex = 302
        '
        'txtLngth6
        '
        Me.txtLngth6.Location = New System.Drawing.Point(189, 145)
        Me.txtLngth6.Name = "txtLngth6"
        Me.txtLngth6.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth6.TabIndex = 301
        '
        'txtCol6
        '
        Me.txtCol6.Location = New System.Drawing.Point(158, 145)
        Me.txtCol6.Name = "txtCol6"
        Me.txtCol6.Size = New System.Drawing.Size(29, 20)
        Me.txtCol6.TabIndex = 300
        '
        'txtRow6
        '
        Me.txtRow6.Location = New System.Drawing.Point(127, 145)
        Me.txtRow6.Name = "txtRow6"
        Me.txtRow6.Size = New System.Drawing.Size(29, 20)
        Me.txtRow6.TabIndex = 299
        '
        'cboSrc5
        '
        Me.cboSrc5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc5.FormattingEnabled = True
        Me.cboSrc5.Location = New System.Drawing.Point(284, 122)
        Me.cboSrc5.Name = "cboSrc5"
        Me.cboSrc5.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc5.TabIndex = 298
        '
        'txtLngth5
        '
        Me.txtLngth5.Location = New System.Drawing.Point(189, 122)
        Me.txtLngth5.Name = "txtLngth5"
        Me.txtLngth5.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth5.TabIndex = 297
        '
        'txtCol5
        '
        Me.txtCol5.Location = New System.Drawing.Point(158, 122)
        Me.txtCol5.Name = "txtCol5"
        Me.txtCol5.Size = New System.Drawing.Size(29, 20)
        Me.txtCol5.TabIndex = 296
        '
        'txtRow5
        '
        Me.txtRow5.Location = New System.Drawing.Point(127, 122)
        Me.txtRow5.Name = "txtRow5"
        Me.txtRow5.Size = New System.Drawing.Size(29, 20)
        Me.txtRow5.TabIndex = 295
        '
        'cboSrc4
        '
        Me.cboSrc4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc4.FormattingEnabled = True
        Me.cboSrc4.Location = New System.Drawing.Point(284, 99)
        Me.cboSrc4.Name = "cboSrc4"
        Me.cboSrc4.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc4.TabIndex = 294
        '
        'txtLngth4
        '
        Me.txtLngth4.Location = New System.Drawing.Point(189, 99)
        Me.txtLngth4.Name = "txtLngth4"
        Me.txtLngth4.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth4.TabIndex = 293
        '
        'txtCol4
        '
        Me.txtCol4.Location = New System.Drawing.Point(158, 99)
        Me.txtCol4.Name = "txtCol4"
        Me.txtCol4.Size = New System.Drawing.Size(29, 20)
        Me.txtCol4.TabIndex = 292
        '
        'txtRow4
        '
        Me.txtRow4.Location = New System.Drawing.Point(127, 99)
        Me.txtRow4.Name = "txtRow4"
        Me.txtRow4.Size = New System.Drawing.Size(29, 20)
        Me.txtRow4.TabIndex = 291
        '
        'cboSrc3
        '
        Me.cboSrc3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc3.FormattingEnabled = True
        Me.cboSrc3.Location = New System.Drawing.Point(284, 76)
        Me.cboSrc3.Name = "cboSrc3"
        Me.cboSrc3.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc3.TabIndex = 290
        '
        'txtLngth3
        '
        Me.txtLngth3.Location = New System.Drawing.Point(189, 76)
        Me.txtLngth3.Name = "txtLngth3"
        Me.txtLngth3.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth3.TabIndex = 289
        '
        'txtCol3
        '
        Me.txtCol3.Location = New System.Drawing.Point(158, 76)
        Me.txtCol3.Name = "txtCol3"
        Me.txtCol3.Size = New System.Drawing.Size(29, 20)
        Me.txtCol3.TabIndex = 288
        '
        'txtRow3
        '
        Me.txtRow3.Location = New System.Drawing.Point(127, 76)
        Me.txtRow3.Name = "txtRow3"
        Me.txtRow3.Size = New System.Drawing.Size(29, 20)
        Me.txtRow3.TabIndex = 287
        '
        'cboSrc2
        '
        Me.cboSrc2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc2.FormattingEnabled = True
        Me.cboSrc2.Location = New System.Drawing.Point(284, 53)
        Me.cboSrc2.Name = "cboSrc2"
        Me.cboSrc2.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc2.TabIndex = 286
        '
        'txtLngth2
        '
        Me.txtLngth2.Location = New System.Drawing.Point(189, 53)
        Me.txtLngth2.Name = "txtLngth2"
        Me.txtLngth2.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth2.TabIndex = 285
        '
        'txtCol2
        '
        Me.txtCol2.Location = New System.Drawing.Point(158, 53)
        Me.txtCol2.Name = "txtCol2"
        Me.txtCol2.Size = New System.Drawing.Size(29, 20)
        Me.txtCol2.TabIndex = 284
        '
        'txtRow2
        '
        Me.txtRow2.Location = New System.Drawing.Point(127, 53)
        Me.txtRow2.Name = "txtRow2"
        Me.txtRow2.Size = New System.Drawing.Size(29, 20)
        Me.txtRow2.TabIndex = 283
        '
        'cboSrc1
        '
        Me.cboSrc1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc1.FormattingEnabled = True
        Me.cboSrc1.Location = New System.Drawing.Point(284, 30)
        Me.cboSrc1.Name = "cboSrc1"
        Me.cboSrc1.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc1.TabIndex = 282
        '
        'txtLngth1
        '
        Me.txtLngth1.Location = New System.Drawing.Point(189, 30)
        Me.txtLngth1.Name = "txtLngth1"
        Me.txtLngth1.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth1.TabIndex = 281
        '
        'txtCol1
        '
        Me.txtCol1.Location = New System.Drawing.Point(158, 30)
        Me.txtCol1.Name = "txtCol1"
        Me.txtCol1.Size = New System.Drawing.Size(29, 20)
        Me.txtCol1.TabIndex = 280
        '
        'txtRow1
        '
        Me.txtRow1.Location = New System.Drawing.Point(127, 30)
        Me.txtRow1.Name = "txtRow1"
        Me.txtRow1.Size = New System.Drawing.Size(29, 20)
        Me.txtRow1.TabIndex = 279
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(301, 11)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(79, 13)
        Me.Label10.TabIndex = 278
        Me.Label10.Text = "Source Column"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(128, 15)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(93, 13)
        Me.Label9.TabIndex = 277
        Me.Label9.Text = "Row / Col / Lngth"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(137, 2)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(70, 13)
        Me.Label8.TabIndex = 276
        Me.Label8.Text = "Data Position"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(17, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 13)
        Me.Label6.TabIndex = 274
        Me.Label6.Text = "Data To Input:"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.Label37)
        Me.TabPage2.Controls.Add(Me.Label38)
        Me.TabPage2.Controls.Add(Me.Label39)
        Me.TabPage2.Controls.Add(Me.cboSrc26)
        Me.TabPage2.Controls.Add(Me.txtLngth26)
        Me.TabPage2.Controls.Add(Me.txtCol26)
        Me.TabPage2.Controls.Add(Me.txtRow26)
        Me.TabPage2.Controls.Add(Me.Label40)
        Me.TabPage2.Controls.Add(Me.Label41)
        Me.TabPage2.Controls.Add(Me.Label42)
        Me.TabPage2.Controls.Add(Me.Label43)
        Me.TabPage2.Controls.Add(Me.Label44)
        Me.TabPage2.Controls.Add(Me.Label45)
        Me.TabPage2.Controls.Add(Me.Label46)
        Me.TabPage2.Controls.Add(Me.Label47)
        Me.TabPage2.Controls.Add(Me.cboSrc25)
        Me.TabPage2.Controls.Add(Me.txtLngth25)
        Me.TabPage2.Controls.Add(Me.txtCol25)
        Me.TabPage2.Controls.Add(Me.txtRow25)
        Me.TabPage2.Controls.Add(Me.cboSrc24)
        Me.TabPage2.Controls.Add(Me.txtLngth24)
        Me.TabPage2.Controls.Add(Me.txtCol24)
        Me.TabPage2.Controls.Add(Me.txtRow24)
        Me.TabPage2.Controls.Add(Me.cboSrc23)
        Me.TabPage2.Controls.Add(Me.txtLngth23)
        Me.TabPage2.Controls.Add(Me.txtCol23)
        Me.TabPage2.Controls.Add(Me.txtRow23)
        Me.TabPage2.Controls.Add(Me.cboSrc22)
        Me.TabPage2.Controls.Add(Me.txtLngth22)
        Me.TabPage2.Controls.Add(Me.txtCol22)
        Me.TabPage2.Controls.Add(Me.txtRow22)
        Me.TabPage2.Controls.Add(Me.cboSrc21)
        Me.TabPage2.Controls.Add(Me.txtLngth21)
        Me.TabPage2.Controls.Add(Me.txtCol21)
        Me.TabPage2.Controls.Add(Me.txtRow21)
        Me.TabPage2.Controls.Add(Me.cboSrc20)
        Me.TabPage2.Controls.Add(Me.txtLngth20)
        Me.TabPage2.Controls.Add(Me.txtCol20)
        Me.TabPage2.Controls.Add(Me.txtRow20)
        Me.TabPage2.Controls.Add(Me.cboSrc19)
        Me.TabPage2.Controls.Add(Me.txtLngth19)
        Me.TabPage2.Controls.Add(Me.txtCol19)
        Me.TabPage2.Controls.Add(Me.txtRow19)
        Me.TabPage2.Controls.Add(Me.cboSrc18)
        Me.TabPage2.Controls.Add(Me.txtLngth18)
        Me.TabPage2.Controls.Add(Me.txtCol18)
        Me.TabPage2.Controls.Add(Me.txtRow18)
        Me.TabPage2.Controls.Add(Me.cboSrc17)
        Me.TabPage2.Controls.Add(Me.txtLngth17)
        Me.TabPage2.Controls.Add(Me.txtCol17)
        Me.TabPage2.Controls.Add(Me.txtRow17)
        Me.TabPage2.Controls.Add(Me.cboSrc16)
        Me.TabPage2.Controls.Add(Me.txtLngth16)
        Me.TabPage2.Controls.Add(Me.txtCol16)
        Me.TabPage2.Controls.Add(Me.txtRow16)
        Me.TabPage2.Controls.Add(Me.cboSrc15)
        Me.TabPage2.Controls.Add(Me.txtLngth15)
        Me.TabPage2.Controls.Add(Me.txtCol15)
        Me.TabPage2.Controls.Add(Me.txtRow15)
        Me.TabPage2.Controls.Add(Me.cboSrc14)
        Me.TabPage2.Controls.Add(Me.txtLngth14)
        Me.TabPage2.Controls.Add(Me.txtCol14)
        Me.TabPage2.Controls.Add(Me.txtRow14)
        Me.TabPage2.Controls.Add(Me.Label48)
        Me.TabPage2.Controls.Add(Me.Label49)
        Me.TabPage2.Controls.Add(Me.Label50)
        Me.TabPage2.Controls.Add(Me.Label51)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(414, 331)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Data Page2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(78, 310)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(45, 13)
        Me.Label7.TabIndex = 412
        Me.Label7.Text = "Item 26:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(78, 287)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(45, 13)
        Me.Label20.TabIndex = 411
        Me.Label20.Text = "Item 25:"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(78, 264)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(45, 13)
        Me.Label37.TabIndex = 410
        Me.Label37.Text = "Item 24:"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(78, 241)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(45, 13)
        Me.Label38.TabIndex = 409
        Me.Label38.Text = "Item 23:"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(78, 218)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(45, 13)
        Me.Label39.TabIndex = 408
        Me.Label39.Text = "Item 22:"
        '
        'cboSrc26
        '
        Me.cboSrc26.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc26.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc26.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc26.FormattingEnabled = True
        Me.cboSrc26.Location = New System.Drawing.Point(280, 307)
        Me.cboSrc26.Name = "cboSrc26"
        Me.cboSrc26.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc26.TabIndex = 407
        '
        'txtLngth26
        '
        Me.txtLngth26.Location = New System.Drawing.Point(185, 307)
        Me.txtLngth26.Name = "txtLngth26"
        Me.txtLngth26.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth26.TabIndex = 406
        '
        'txtCol26
        '
        Me.txtCol26.Location = New System.Drawing.Point(154, 307)
        Me.txtCol26.Name = "txtCol26"
        Me.txtCol26.Size = New System.Drawing.Size(29, 20)
        Me.txtCol26.TabIndex = 405
        '
        'txtRow26
        '
        Me.txtRow26.Location = New System.Drawing.Point(123, 307)
        Me.txtRow26.Name = "txtRow26"
        Me.txtRow26.Size = New System.Drawing.Size(29, 20)
        Me.txtRow26.TabIndex = 404
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(78, 194)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(45, 13)
        Me.Label40.TabIndex = 403
        Me.Label40.Text = "Item 21:"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(78, 171)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(45, 13)
        Me.Label41.TabIndex = 402
        Me.Label41.Text = "Item 20:"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(78, 149)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(45, 13)
        Me.Label42.TabIndex = 401
        Me.Label42.Text = "Item 19:"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(78, 126)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(45, 13)
        Me.Label43.TabIndex = 400
        Me.Label43.Text = "Item 18:"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(78, 103)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(45, 13)
        Me.Label44.TabIndex = 399
        Me.Label44.Text = "Item 17:"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(78, 79)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(45, 13)
        Me.Label45.TabIndex = 398
        Me.Label45.Text = "Item 16:"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(78, 57)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(45, 13)
        Me.Label46.TabIndex = 397
        Me.Label46.Text = "Item 15:"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(78, 34)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(45, 13)
        Me.Label47.TabIndex = 396
        Me.Label47.Text = "Item 14:"
        '
        'cboSrc25
        '
        Me.cboSrc25.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc25.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc25.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc25.FormattingEnabled = True
        Me.cboSrc25.Location = New System.Drawing.Point(280, 284)
        Me.cboSrc25.Name = "cboSrc25"
        Me.cboSrc25.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc25.TabIndex = 395
        '
        'txtLngth25
        '
        Me.txtLngth25.Location = New System.Drawing.Point(185, 284)
        Me.txtLngth25.Name = "txtLngth25"
        Me.txtLngth25.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth25.TabIndex = 394
        '
        'txtCol25
        '
        Me.txtCol25.Location = New System.Drawing.Point(154, 284)
        Me.txtCol25.Name = "txtCol25"
        Me.txtCol25.Size = New System.Drawing.Size(29, 20)
        Me.txtCol25.TabIndex = 393
        '
        'txtRow25
        '
        Me.txtRow25.Location = New System.Drawing.Point(123, 284)
        Me.txtRow25.Name = "txtRow25"
        Me.txtRow25.Size = New System.Drawing.Size(29, 20)
        Me.txtRow25.TabIndex = 392
        '
        'cboSrc24
        '
        Me.cboSrc24.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc24.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc24.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc24.FormattingEnabled = True
        Me.cboSrc24.Location = New System.Drawing.Point(280, 261)
        Me.cboSrc24.Name = "cboSrc24"
        Me.cboSrc24.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc24.TabIndex = 391
        '
        'txtLngth24
        '
        Me.txtLngth24.Location = New System.Drawing.Point(185, 261)
        Me.txtLngth24.Name = "txtLngth24"
        Me.txtLngth24.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth24.TabIndex = 390
        '
        'txtCol24
        '
        Me.txtCol24.Location = New System.Drawing.Point(154, 261)
        Me.txtCol24.Name = "txtCol24"
        Me.txtCol24.Size = New System.Drawing.Size(29, 20)
        Me.txtCol24.TabIndex = 389
        '
        'txtRow24
        '
        Me.txtRow24.Location = New System.Drawing.Point(123, 261)
        Me.txtRow24.Name = "txtRow24"
        Me.txtRow24.Size = New System.Drawing.Size(29, 20)
        Me.txtRow24.TabIndex = 388
        '
        'cboSrc23
        '
        Me.cboSrc23.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc23.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc23.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc23.FormattingEnabled = True
        Me.cboSrc23.Location = New System.Drawing.Point(280, 238)
        Me.cboSrc23.Name = "cboSrc23"
        Me.cboSrc23.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc23.TabIndex = 387
        '
        'txtLngth23
        '
        Me.txtLngth23.Location = New System.Drawing.Point(185, 238)
        Me.txtLngth23.Name = "txtLngth23"
        Me.txtLngth23.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth23.TabIndex = 386
        '
        'txtCol23
        '
        Me.txtCol23.Location = New System.Drawing.Point(154, 238)
        Me.txtCol23.Name = "txtCol23"
        Me.txtCol23.Size = New System.Drawing.Size(29, 20)
        Me.txtCol23.TabIndex = 385
        '
        'txtRow23
        '
        Me.txtRow23.Location = New System.Drawing.Point(123, 238)
        Me.txtRow23.Name = "txtRow23"
        Me.txtRow23.Size = New System.Drawing.Size(29, 20)
        Me.txtRow23.TabIndex = 384
        '
        'cboSrc22
        '
        Me.cboSrc22.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc22.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc22.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc22.FormattingEnabled = True
        Me.cboSrc22.Location = New System.Drawing.Point(280, 215)
        Me.cboSrc22.Name = "cboSrc22"
        Me.cboSrc22.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc22.TabIndex = 383
        '
        'txtLngth22
        '
        Me.txtLngth22.Location = New System.Drawing.Point(185, 215)
        Me.txtLngth22.Name = "txtLngth22"
        Me.txtLngth22.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth22.TabIndex = 382
        '
        'txtCol22
        '
        Me.txtCol22.Location = New System.Drawing.Point(154, 215)
        Me.txtCol22.Name = "txtCol22"
        Me.txtCol22.Size = New System.Drawing.Size(29, 20)
        Me.txtCol22.TabIndex = 381
        '
        'txtRow22
        '
        Me.txtRow22.Location = New System.Drawing.Point(123, 215)
        Me.txtRow22.Name = "txtRow22"
        Me.txtRow22.Size = New System.Drawing.Size(29, 20)
        Me.txtRow22.TabIndex = 380
        '
        'cboSrc21
        '
        Me.cboSrc21.AutoCompleteCustomSource.AddRange(New String() {"Column A", "Column B", "Column C", "Column D", "Column E", "Column F", "Column G", "Column H", "Column I", "Column J", "Column K", "Column L", "Column M", "Column N", "Column O", "Column P", "Column Q", "Column R", "Column S", "Column T", "Column U", "Column V", "Column W", "Column X", "Column Y", "Column Z"})
        Me.cboSrc21.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc21.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc21.FormattingEnabled = True
        Me.cboSrc21.Location = New System.Drawing.Point(280, 192)
        Me.cboSrc21.Name = "cboSrc21"
        Me.cboSrc21.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc21.TabIndex = 379
        '
        'txtLngth21
        '
        Me.txtLngth21.Location = New System.Drawing.Point(185, 192)
        Me.txtLngth21.Name = "txtLngth21"
        Me.txtLngth21.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth21.TabIndex = 378
        '
        'txtCol21
        '
        Me.txtCol21.Location = New System.Drawing.Point(154, 192)
        Me.txtCol21.Name = "txtCol21"
        Me.txtCol21.Size = New System.Drawing.Size(29, 20)
        Me.txtCol21.TabIndex = 377
        '
        'txtRow21
        '
        Me.txtRow21.Location = New System.Drawing.Point(123, 192)
        Me.txtRow21.Name = "txtRow21"
        Me.txtRow21.Size = New System.Drawing.Size(29, 20)
        Me.txtRow21.TabIndex = 376
        '
        'cboSrc20
        '
        Me.cboSrc20.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc20.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc20.FormattingEnabled = True
        Me.cboSrc20.Location = New System.Drawing.Point(280, 169)
        Me.cboSrc20.Name = "cboSrc20"
        Me.cboSrc20.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc20.TabIndex = 375
        '
        'txtLngth20
        '
        Me.txtLngth20.Location = New System.Drawing.Point(185, 169)
        Me.txtLngth20.Name = "txtLngth20"
        Me.txtLngth20.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth20.TabIndex = 374
        '
        'txtCol20
        '
        Me.txtCol20.Location = New System.Drawing.Point(154, 169)
        Me.txtCol20.Name = "txtCol20"
        Me.txtCol20.Size = New System.Drawing.Size(29, 20)
        Me.txtCol20.TabIndex = 373
        '
        'txtRow20
        '
        Me.txtRow20.Location = New System.Drawing.Point(123, 169)
        Me.txtRow20.Name = "txtRow20"
        Me.txtRow20.Size = New System.Drawing.Size(29, 20)
        Me.txtRow20.TabIndex = 372
        '
        'cboSrc19
        '
        Me.cboSrc19.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc19.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc19.FormattingEnabled = True
        Me.cboSrc19.Location = New System.Drawing.Point(280, 146)
        Me.cboSrc19.Name = "cboSrc19"
        Me.cboSrc19.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc19.TabIndex = 371
        '
        'txtLngth19
        '
        Me.txtLngth19.Location = New System.Drawing.Point(185, 146)
        Me.txtLngth19.Name = "txtLngth19"
        Me.txtLngth19.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth19.TabIndex = 370
        '
        'txtCol19
        '
        Me.txtCol19.Location = New System.Drawing.Point(154, 146)
        Me.txtCol19.Name = "txtCol19"
        Me.txtCol19.Size = New System.Drawing.Size(29, 20)
        Me.txtCol19.TabIndex = 369
        '
        'txtRow19
        '
        Me.txtRow19.Location = New System.Drawing.Point(123, 146)
        Me.txtRow19.Name = "txtRow19"
        Me.txtRow19.Size = New System.Drawing.Size(29, 20)
        Me.txtRow19.TabIndex = 368
        '
        'cboSrc18
        '
        Me.cboSrc18.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc18.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc18.FormattingEnabled = True
        Me.cboSrc18.Location = New System.Drawing.Point(280, 123)
        Me.cboSrc18.Name = "cboSrc18"
        Me.cboSrc18.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc18.TabIndex = 367
        '
        'txtLngth18
        '
        Me.txtLngth18.Location = New System.Drawing.Point(185, 123)
        Me.txtLngth18.Name = "txtLngth18"
        Me.txtLngth18.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth18.TabIndex = 366
        '
        'txtCol18
        '
        Me.txtCol18.Location = New System.Drawing.Point(154, 123)
        Me.txtCol18.Name = "txtCol18"
        Me.txtCol18.Size = New System.Drawing.Size(29, 20)
        Me.txtCol18.TabIndex = 365
        '
        'txtRow18
        '
        Me.txtRow18.Location = New System.Drawing.Point(123, 123)
        Me.txtRow18.Name = "txtRow18"
        Me.txtRow18.Size = New System.Drawing.Size(29, 20)
        Me.txtRow18.TabIndex = 364
        '
        'cboSrc17
        '
        Me.cboSrc17.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc17.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc17.FormattingEnabled = True
        Me.cboSrc17.Location = New System.Drawing.Point(280, 100)
        Me.cboSrc17.Name = "cboSrc17"
        Me.cboSrc17.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc17.TabIndex = 363
        '
        'txtLngth17
        '
        Me.txtLngth17.Location = New System.Drawing.Point(185, 100)
        Me.txtLngth17.Name = "txtLngth17"
        Me.txtLngth17.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth17.TabIndex = 362
        '
        'txtCol17
        '
        Me.txtCol17.Location = New System.Drawing.Point(154, 100)
        Me.txtCol17.Name = "txtCol17"
        Me.txtCol17.Size = New System.Drawing.Size(29, 20)
        Me.txtCol17.TabIndex = 361
        '
        'txtRow17
        '
        Me.txtRow17.Location = New System.Drawing.Point(123, 100)
        Me.txtRow17.Name = "txtRow17"
        Me.txtRow17.Size = New System.Drawing.Size(29, 20)
        Me.txtRow17.TabIndex = 360
        '
        'cboSrc16
        '
        Me.cboSrc16.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc16.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc16.FormattingEnabled = True
        Me.cboSrc16.Location = New System.Drawing.Point(280, 77)
        Me.cboSrc16.Name = "cboSrc16"
        Me.cboSrc16.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc16.TabIndex = 359
        '
        'txtLngth16
        '
        Me.txtLngth16.Location = New System.Drawing.Point(185, 77)
        Me.txtLngth16.Name = "txtLngth16"
        Me.txtLngth16.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth16.TabIndex = 358
        '
        'txtCol16
        '
        Me.txtCol16.Location = New System.Drawing.Point(154, 77)
        Me.txtCol16.Name = "txtCol16"
        Me.txtCol16.Size = New System.Drawing.Size(29, 20)
        Me.txtCol16.TabIndex = 357
        '
        'txtRow16
        '
        Me.txtRow16.Location = New System.Drawing.Point(123, 77)
        Me.txtRow16.Name = "txtRow16"
        Me.txtRow16.Size = New System.Drawing.Size(29, 20)
        Me.txtRow16.TabIndex = 356
        '
        'cboSrc15
        '
        Me.cboSrc15.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc15.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc15.FormattingEnabled = True
        Me.cboSrc15.Location = New System.Drawing.Point(280, 54)
        Me.cboSrc15.Name = "cboSrc15"
        Me.cboSrc15.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc15.TabIndex = 355
        '
        'txtLngth15
        '
        Me.txtLngth15.Location = New System.Drawing.Point(185, 54)
        Me.txtLngth15.Name = "txtLngth15"
        Me.txtLngth15.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth15.TabIndex = 354
        '
        'txtCol15
        '
        Me.txtCol15.Location = New System.Drawing.Point(154, 54)
        Me.txtCol15.Name = "txtCol15"
        Me.txtCol15.Size = New System.Drawing.Size(29, 20)
        Me.txtCol15.TabIndex = 353
        '
        'txtRow15
        '
        Me.txtRow15.Location = New System.Drawing.Point(123, 54)
        Me.txtRow15.Name = "txtRow15"
        Me.txtRow15.Size = New System.Drawing.Size(29, 20)
        Me.txtRow15.TabIndex = 352
        '
        'cboSrc14
        '
        Me.cboSrc14.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboSrc14.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSrc14.FormattingEnabled = True
        Me.cboSrc14.Location = New System.Drawing.Point(280, 31)
        Me.cboSrc14.Name = "cboSrc14"
        Me.cboSrc14.Size = New System.Drawing.Size(121, 21)
        Me.cboSrc14.TabIndex = 351
        '
        'txtLngth14
        '
        Me.txtLngth14.Location = New System.Drawing.Point(185, 31)
        Me.txtLngth14.Name = "txtLngth14"
        Me.txtLngth14.Size = New System.Drawing.Size(29, 20)
        Me.txtLngth14.TabIndex = 350
        '
        'txtCol14
        '
        Me.txtCol14.Location = New System.Drawing.Point(154, 31)
        Me.txtCol14.Name = "txtCol14"
        Me.txtCol14.Size = New System.Drawing.Size(29, 20)
        Me.txtCol14.TabIndex = 349
        '
        'txtRow14
        '
        Me.txtRow14.Location = New System.Drawing.Point(123, 31)
        Me.txtRow14.Name = "txtRow14"
        Me.txtRow14.Size = New System.Drawing.Size(29, 20)
        Me.txtRow14.TabIndex = 348
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(297, 12)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(79, 13)
        Me.Label48.TabIndex = 347
        Me.Label48.Text = "Source Column"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(124, 16)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(93, 13)
        Me.Label49.TabIndex = 346
        Me.Label49.Text = "Row / Col / Lngth"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(133, 3)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(70, 13)
        Me.Label50.TabIndex = 345
        Me.Label50.Text = "Data Position"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(13, 11)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(76, 13)
        Me.Label51.TabIndex = 344
        Me.Label51.Text = "Data To Input:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(222, 457)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(189, 13)
        Me.Label14.TabIndex = 277
        Me.Label14.Text = "How Many Times To Submit Enter Key"
        '
        'txtTimesEnter
        '
        Me.txtTimesEnter.Location = New System.Drawing.Point(413, 454)
        Me.txtTimesEnter.Name = "txtTimesEnter"
        Me.txtTimesEnter.Size = New System.Drawing.Size(15, 20)
        Me.txtTimesEnter.TabIndex = 278
        Me.txtTimesEnter.TabStop = False
        Me.txtTimesEnter.Text = "1"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(230, 484)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(177, 13)
        Me.Label12.TabIndex = 274
        Me.Label12.Text = "How Many Times To Submit PF Key"
        '
        'txtTimesToSubmit
        '
        Me.txtTimesToSubmit.Location = New System.Drawing.Point(413, 481)
        Me.txtTimesToSubmit.Name = "txtTimesToSubmit"
        Me.txtTimesToSubmit.Size = New System.Drawing.Size(15, 20)
        Me.txtTimesToSubmit.TabIndex = 276
        Me.txtTimesToSubmit.TabStop = False
        Me.txtTimesToSubmit.Text = "1"
        '
        'cboPFKey
        '
        Me.cboPFKey.FormattingEnabled = True
        Me.cboPFKey.Items.AddRange(New Object() {"NONE", "PF1", "PF2", "PF3", "PF4", "PF5", "PF6", "PF7", "PF8", "PF9", "PF10", "PF11", "PF12", "PF13", "PF14", "PF15", "PF16", "PF17", "PF18", "PF19", "PF20", "PF21", "PF22", "PF23", "PF24"})
        Me.cboPFKey.Location = New System.Drawing.Point(144, 480)
        Me.cboPFKey.Name = "cboPFKey"
        Me.cboPFKey.Size = New System.Drawing.Size(76, 21)
        Me.cboPFKey.TabIndex = 275
        Me.cboPFKey.TabStop = False
        '
        'cboSubmitType
        '
        Me.cboSubmitType.FormattingEnabled = True
        Me.cboSubmitType.Items.AddRange(New Object() {"Submit", "PF Key"})
        Me.cboSubmitType.Location = New System.Drawing.Point(144, 457)
        Me.cboSubmitType.Name = "cboSubmitType"
        Me.cboSubmitType.Size = New System.Drawing.Size(76, 21)
        Me.cboSubmitType.TabIndex = 273
        Me.cboSubmitType.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(49, 460)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(69, 13)
        Me.Label11.TabIndex = 272
        Me.Label11.Text = "Submit Type:"
        '
        'frmFileSelction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(463, 505)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.txtTimesEnter)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtTimesToSubmit)
        Me.Controls.Add(Me.cboPFKey)
        Me.Controls.Add(Me.cboSubmitType)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtScreen)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.txtSubWindow)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.cboLoanNumber)
        Me.Controls.Add(Me.btnLoad)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtFileLoc)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.Label15)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmFileSelction"
        Me.Text = "Generic Script"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnBrowse As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtFileLoc As System.Windows.Forms.RichTextBox
    Friend WithEvents txtScreen As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnLoad As System.Windows.Forms.Button
    Friend WithEvents cboLoanNumber As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents sdlgFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnHelp As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtSrow1 As System.Windows.Forms.TextBox
    Friend WithEvents txtSCol1 As System.Windows.Forms.TextBox
    Friend WithEvents txtSLngth1 As System.Windows.Forms.TextBox
    Friend WithEvents cboSSrc1 As System.Windows.Forms.ComboBox
    Friend WithEvents txtSrow2 As System.Windows.Forms.TextBox
    Friend WithEvents txtSCol2 As System.Windows.Forms.TextBox
    Friend WithEvents txtSLngth2 As System.Windows.Forms.TextBox
    Friend WithEvents cboSSrc2 As System.Windows.Forms.ComboBox
    Friend WithEvents cboSPFKey As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtSubWindow As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents cboSrc13 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth13 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol13 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow13 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents cboSrc12 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth12 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol12 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow12 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc11 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth11 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol11 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow11 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc10 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth10 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol10 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow10 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc9 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth9 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol9 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow9 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc8 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth8 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol8 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow8 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc7 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth7 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol7 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow7 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc6 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth6 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol6 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow6 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc5 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth5 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol5 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow5 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc4 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth4 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol4 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow4 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc3 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth3 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol3 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow3 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc2 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth2 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol2 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow2 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc1 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth1 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol1 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow1 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents cboSrc26 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth26 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol26 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow26 As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents cboSrc25 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth25 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol25 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow25 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc24 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth24 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol24 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow24 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc23 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth23 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol23 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow23 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc22 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth22 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol22 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow22 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc21 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth21 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol21 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow21 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc20 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth20 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol20 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow20 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc19 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth19 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol19 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow19 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc18 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth18 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol18 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow18 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc17 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth17 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol17 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow17 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc16 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth16 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol16 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow16 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc15 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth15 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol15 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow15 As System.Windows.Forms.TextBox
    Friend WithEvents cboSrc14 As System.Windows.Forms.ComboBox
    Friend WithEvents txtLngth14 As System.Windows.Forms.TextBox
    Friend WithEvents txtCol14 As System.Windows.Forms.TextBox
    Friend WithEvents txtRow14 As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtTimesEnter As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtTimesToSubmit As System.Windows.Forms.TextBox
    Friend WithEvents cboPFKey As System.Windows.Forms.ComboBox
    Friend WithEvents cboSubmitType As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label

End Class
