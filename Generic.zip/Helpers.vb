﻿Public Class Helpers
    Public Shared XLApp As Object
    Public Shared objExcel As Object
    Public Shared objExcelWrkBk As Object
    Public Shared objXlSht As Object
    Public Shared objExcel2 As Object
    Public Shared objExcelWrkBk2 As Object
    Public Shared objXlSht2 As Object
    Public Shared objRange As Object
    Public Shared objRange2 As Object

    Public Shared Function SelectFile(ByVal Filter As String, ByVal Title As String) As String
        Dim fdlg As OpenFileDialog = New OpenFileDialog()
        fdlg.Title = Title
        fdlg.InitialDirectory = My.Application.Info.DirectoryPath
        'fdlg.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fdlg.Filter = Filter
        fdlg.FilterIndex = 2
        fdlg.RestoreDirectory = True
        SelectFile = ""
        fdlg.ShowDialog()
        If Len(fdlg.FileName) = 0 Then
            MsgBox("File not selected. Script execution canceled.", vbOKOnly + vbCritical + vbSystemModal, Title)
        Else
            SelectFile = fdlg.FileName
        End If

        Return SelectFile
    End Function

    Public Shared Sub WrkConnXL(ByVal XLFile As String, ByRef XLSheet As Short)
        'XLApp = CreateObject("Excel.Application")
        objExcel = GetObject("", "Excel.Application")
        objExcelWrkBk = objExcel.Workbooks.Open(XLFile)
        objXlSht = objExcelWrkBk.sheets(XLSheet)
    End Sub

    Public Shared Sub XLConnClose()
        On Error Resume Next
        'objExcelWrkBk.save()
        objXlSht.Application.Quit()
        objXlSht = Nothing
        objExcel.Application.Quit()
        objExcelWrkBk = Nothing
        objExcel = Nothing
    End Sub
End Class
